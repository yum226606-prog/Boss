import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  CloudUpload,
  Copy,
  Cpu,
  Download,
  FileSpreadsheet,
  Home,
  LayoutDashboard,
  Layers,
  Monitor,
  Palette,
  RefreshCw,
  Scissors,
  Settings,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Users,
} from 'lucide-react';
import {
  AppOfferBanner,
  BankAccountConfig,
  BossTab,
  ClientAppLayoutControlConfig,
  DeletedBackupItem,
  DoorItem,
  DragDropBlueprint,
  DynamicMasterSection,
  ExtraPiece,
  FixFrameItem,
  FormulaCategorySettings,
  FSectionFormula,
  GlassFormula,
  IdentityRecord,
  MainAppSystem,
  MeasurementUnit,
  OpenableWindowItem,
  PaymentReceiptLog,
  SavedQuotation,
  SlidingDoorFormulaSettings,
  SlidingDoorItem,
  SubAdminUser,
  SubscriptionPackage,
  WindowFormulaSettings,
  WindowItem,
} from './types/bossModels';
import {
  DEFAULT_COLORS,
  DEFAULT_SECTIONS,
  GAUGES,
  getClearedZeroRates,
  getDefaultCategoryFormula,
  getDefaultFSectionFormula,
  getDefaultGlassFormulas,
  getDefaultLayoutControlConfig,
  getDefaultSlidingDoorFormula,
  getDefaultWindowFormula,
  getInitialGlassRates,
  getInitialRates,
  getStarterBankAccounts,
  getStarterBlueprints,
  getStarterDynamicSections,
  getStarterIdentities,
  getStarterPackages,
  OWNER_VIP_EMAILS,
} from './utils/bossDefaultRates';
import bossLionLogoImg from './assets/images/boss_lion_logo_1791741005749.jpg';
import bossLetterheadCleanImg from './assets/images/boss_letterhead_bg_1791741019302.jpg';
import {
  callSupabaseProxy,
  DEFAULT_SMS_GATEWAY_CONFIG,
  DEFAULT_SUPABASE_URL,
  SmsOtpGatewayConfig,
} from './utils/supabaseClientConfig';
import { usePWAInstall } from './hooks/usePWAInstall';
import { MasterDashboardScreen } from './components/MasterDashboardScreen';
import { DragDropStudioScreen } from './components/DragDropStudioScreen';
import { MasterSettingsScreen } from './components/MasterSettingsScreen';
import { AppLayoutCalculatorScreen } from './components/AppLayoutCalculatorScreen';
import { OwnerMasterLoginScreen } from './components/OwnerMasterLoginScreen';
import {
  AppThemeConfig,
  BUILT_IN_THEMES,
  enforceReadableContrast,
  ThemeStudioModal,
} from './components/ThemeStudioModal';

const STORAGE_KEY = 'boss_aluminium_master_web_state_v1';

export default function App() {
  // Owner Master Authentication Lock Gate (Vercel & Browser Session Protection)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem('boss_owner_master_session');
      if (raw) {
        const sess = JSON.parse(raw);
        if (
          sess?.email &&
          OWNER_VIP_EMAILS.some((e) => e.toLowerCase() === String(sess.email).toLowerCase())
        ) {
          return true;
        }
      }
    } catch {
      // ignore
    }
    return false;
  });

  const handleLogout = () => {
    try {
      localStorage.removeItem('boss_owner_master_session');
    } catch {
      // ignore
    }
    setIsAuthenticated(false);
    triggerGlobalToast('Locked Master Admin Vault.');
  };

  // Active Top-Level System (Matches MainDashboardScreen.kt + Drag & Drop Studio)
  const [currentSystem, setCurrentSystem] = useState<MainAppSystem>('HUB');
  const [currentCalcTab, setCurrentCalcTab] = useState<BossTab>('WINDOWS');

  // Master Context State
  const [ctxGauge, setCtxGauge] = useState<string>('1.6');
  const [ctxGaugeMode, setCtxGaugeMode] = useState<'ON' | 'OFF'>('ON');
  const [ctxColor, setCtxColor] = useState<string>('DULL');
  const [ctxFrameType, setCtxFrameType] = useState<string>('C');
  const [ctxGlassMode, setCtxGlassMode] = useState<'ON' | 'OFF'>('ON');
  const [ctxGlassGauge, setCtxGlassGauge] = useState<string>('5');
  const [ctxGlassColor, setCtxGlassColor] = useState<string>('CLEAR');
  const [measurementUnit, setMeasurementUnit] = useState<MeasurementUnit>('INCH_SUTAR');
  const [glassFittingOption, setGlassFittingOption] = useState<'FIX_RUBBER' | 'U_PVC'>('FIX_RUBBER');

  // Catalog, Rates & Visibility
  const [availableColors, setAvailableColors] = useState<string[]>(DEFAULT_COLORS);
  const [customSections, setCustomSections] = useState<string[]>(['CW50-MULLION', 'CW50-TRANSOM', 'TH70-FRAME']);
  const [rates, setRates] = useState<Record<string, Record<string, Record<string, number>>>>(() =>
    getInitialRates()
  );
  const [glassRates, setGlassRates] = useState<Record<string, Record<string, number>>>(() =>
    getInitialGlassRates()
  );
  const [hiddenSections, setHiddenSections] = useState<string[]>([]);

  // Formulas State
  const [windowFormula, setWindowFormula] = useState<WindowFormulaSettings>(() =>
    getDefaultWindowFormula()
  );
  const [slidingDoorFormula, setSlidingDoorFormula] = useState<SlidingDoorFormulaSettings>(() =>
    getDefaultSlidingDoorFormula()
  );
  const [doorFormula, setDoorFormula] = useState<FormulaCategorySettings>(() =>
    getDefaultCategoryFormula('door')
  );
  const [fixFormula, setFixFormula] = useState<FormulaCategorySettings>(() =>
    getDefaultCategoryFormula('fix')
  );
  const [openwinFormula, setOpenwinFormula] = useState<FormulaCategorySettings>(() =>
    getDefaultCategoryFormula('openwin')
  );
  const [fSectionFormula, setFSectionFormula] = useState<FSectionFormula>(() =>
    getDefaultFSectionFormula()
  );
  const [glassFormulas, setGlassFormulas] = useState<Record<string, GlassFormula>>(() =>
    getDefaultGlassFormulas()
  );
  const [smsGatewayConfig, setSmsGatewayConfig] = useState<SmsOtpGatewayConfig>(() =>
    DEFAULT_SMS_GATEWAY_CONFIG
  );

  // Project Calculator Items (Pre-populated with 1 sample Window & 1 Door with qty = 1 so pieces are never doubled)
  const [windows, setWindows] = useState<WindowItem[]>([
    {
      id: 'win-starter-1',
      width: 48,
      height: 60,
      qty: 1,
      frameType: 'C',
      sectionGauge: '1.6',
      glassGauge: '5',
      glassColor: 'CLEAR',
      glassEnabled: true,
      m24Qty: 4,
      m24aQty: 0,
      d29HeightQty: 2,
      d29WidthQty: 2,
      extras: [],
      outerSection: 'DC30C',
      panelCount: 2,
      lockType: 'LATCH',
    },
  ]);
  const [doors, setDoors] = useState<DoorItem[]>([
    {
      id: 'door-starter-1',
      width: 36,
      height: 84,
      qty: 1,
      outer: 'D54A',
      sectionGauge: '1.6',
      glassGauge: '5',
      glassColor: 'CLEAR',
      glassEnabled: true,
      d59Qty: 0,
      d59aQty: 0,
      d52Qty: 1,
      extras: [],
    },
  ]);
  const [fixframes, setFixFrames] = useState<FixFrameItem[]>([]);
  const [openableWindows, setOpenableWindows] = useState<OpenableWindowItem[]>([]);
  const [slidingDoors, setSlidingDoors] = useState<SlidingDoorItem[]>([]);
  const [projectExtras, setProjectExtras] = useState<ExtraPiece[]>([]);

  // Company & Quotation Defaults
  const [companyName, setCompanyName] = useState('BOSS ALUMINIUM & GLASS');
  const [companyTagline, setCompanyTagline] = useState(
    'Premium Architectural & Commercial Glazing Solutions'
  );
  const [companyAddress, setCompanyAddress] = useState('Main Market, Pakistan');
  const [companyPhone, setCompanyPhone] = useState('+92 310 5524225');
  const [companyNtn, setCompanyNtn] = useState('1234567-8');
  const [customerName, setCustomerName] = useState('Tariq Mehmood');
  const [customerPhone, setCustomerPhone] = useState('0300-4419283');
  const [hardwareRate, setHardwareRate] = useState<number>(3000);
  const [markupPct, setMarkupPct] = useState<number>(0);
  const [transportRent, setTransportRent] = useState<number>(0);
  const [labourCost, setLabourCost] = useState<number>(0);
  const [savedQuotations, setSavedQuotations] = useState<SavedQuotation[]>([]);

  // Master Admin Entities (Users, Dynamic Sections, Drag-and-Drop Blueprints, Bank Accounts, Sub-Admins)
  const [users, setUsers] = useState<IdentityRecord[]>(() => getStarterIdentities());
  const [dynamicSections, setDynamicSections] = useState<DynamicMasterSection[]>(() =>
    getStarterDynamicSections()
  );
  const [blueprints, setBlueprints] = useState<DragDropBlueprint[]>(() =>
    getStarterBlueprints()
  );
  const [bankAccounts, setBankAccounts] = useState<BankAccountConfig[]>(() =>
    getStarterBankAccounts()
  );
  const [paymentLogs, setPaymentLogs] = useState<PaymentReceiptLog[]>([
    {
      id: 'pay-starter-1',
      tid: '84920194821',
      clientName: 'Tariq Mehmood',
      clientPhone: '03004419283',
      clientCnic: '35202-4819203-1',
      amount: 3000,
      bankName: 'Easypaisa Wallet (03105524225)',
      planMonths: 1,
      status: 'AUTO_VERIFIED',
      timestamp: Date.now() - 86400000 * 3,
      notes: 'Auto-activated via AI Receipt & TID Check',
    },
  ]);
  const [subAdmins, setSubAdmins] = useState<SubAdminUser[]>([]);
  const [activeOffer, setActiveOffer] = useState<AppOfferBanner | null>(null);
  const [packages, setPackages] = useState<SubscriptionPackage[]>(() => getStarterPackages());
  const [layoutConfig, setLayoutConfig] = useState<ClientAppLayoutControlConfig>(() =>
    getDefaultLayoutControlConfig()
  );
  const [mainLogoUrl, setMainLogoUrl] = useState<string>(bossLionLogoImg);
  const [letterheadBgUrl, setLetterheadBgUrl] = useState<string>(bossLetterheadCleanImg);

  // PWA / Windows Desktop App Install Modal State & Mobile Theme Studio State
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showDesktopInstallGuide, setShowDesktopInstallGuide] = useState(false);
  const [showThemeStudio, setShowThemeStudio] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<AppThemeConfig>(() => BUILT_IN_THEMES[0]);
  const [downloadedThemes, setDownloadedThemes] = useState<AppThemeConfig[]>([]);
  const [customCreatedThemes, setCustomCreatedThemes] = useState<AppThemeConfig[]>([]);
  const [deletedBackupVault, setDeletedBackupVault] = useState<DeletedBackupItem[]>([]);
  const [globalToast, setGlobalToast] = useState<string | null>(null);

  const triggerGlobalToast = (msg: string) => {
    setGlobalToast(msg);
    setTimeout(() => setGlobalToast(null), 3500);
  };

  // Apply Mobile Theme CSS Variables & High-Contrast Guard across the entire app
  useEffect(() => {
    const safe = enforceReadableContrast(currentTheme);
    const root = document.documentElement;
    root.style.setProperty('--boss-bg', safe.bg);
    root.style.setProperty('--boss-panel', safe.panel);
    root.style.setProperty('--boss-panel2', safe.panel2);
    root.style.setProperty('--boss-border', safe.border);
    root.style.setProperty('--boss-primary', safe.primary);
    root.style.setProperty('--boss-accent', safe.accent);
    root.style.setProperty('--boss-text', safe.textPrimary);
    root.style.setProperty('--boss-text-muted', safe.textSecondary);
    root.style.fontSize = `${Math.round((safe.fontScale || 1) * 100)}%`;
  }, [currentTheme]);

  // Load saved state from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.windowFormula) setWindowFormula(parsed.windowFormula);
        if (parsed.slidingDoorFormula) setSlidingDoorFormula(parsed.slidingDoorFormula);
        if (parsed.doorFormula) {
          const df = parsed.doorFormula as FormulaCategorySettings;
          if (df.acc?.D46 && df.acc.D46.qtyW === 2 && df.acc.D46.qtyH === 2) {
            df.acc.D46 = { ...df.acc.D46, applyTo: 'W', qty: 1, qtyH: 0, qtyW: 1 };
          }
          if (df.acc?.D52 && df.acc.D52.qtyH === 2 && df.acc.D52.qtyW === 2) {
            df.acc.D52 = { ...df.acc.D52, enabled: false, applyTo: 'W', qty: 1, qtyH: 0, qtyW: 1 };
          }
          if (df.acc?.D59 && df.acc.D59.qtyH === 2 && df.acc.D59.qtyW === 2) {
            df.acc.D59 = { ...df.acc.D59, enabled: false, applyTo: 'W', qty: 0, qtyH: 0, qtyW: 0 };
          }
          setDoorFormula(df);
        }
        if (parsed.fixFormula) setFixFormula(parsed.fixFormula);
        if (parsed.openwinFormula) setOpenwinFormula(parsed.openwinFormula);
        if (parsed.fSectionFormula) setFSectionFormula(parsed.fSectionFormula);
        if (parsed.users?.length) {
          const nonMock = parsed.users.filter((u: any) => {
            const n = u.name || '';
            const d = u.deviceId || u.device_id || '';
            return (
              !n.includes('Usman Khan') &&
              !n.includes('Tariq Mehmood') &&
              !n.includes('Kamran Ahmed') &&
              !d.includes('51D90B32E441') &&
              !d.includes('A98F12B4C891') &&
              !d.includes('77C3E09182FA')
            );
          });
          if (nonMock.length) setUsers(nonMock);
        }
        if (parsed.blueprints?.length) setBlueprints(parsed.blueprints);
        if (parsed.bankAccounts?.length) setBankAccounts(parsed.bankAccounts);
        if (parsed.savedQuotations) setSavedQuotations(parsed.savedQuotations);
        if (parsed.rates) setRates(parsed.rates);
        if (parsed.packages?.length) setPackages(parsed.packages);
        if (parsed.layoutConfig) setLayoutConfig(parsed.layoutConfig);
        if (parsed.mainLogoUrl) setMainLogoUrl(parsed.mainLogoUrl);
        if (parsed.letterheadBgUrl) setLetterheadBgUrl(parsed.letterheadBgUrl);
        if (parsed.currentTheme) setCurrentTheme(enforceReadableContrast(parsed.currentTheme));
        if (parsed.downloadedThemes) setDownloadedThemes(parsed.downloadedThemes);
        if (parsed.customCreatedThemes) setCustomCreatedThemes(parsed.customCreatedThemes);
        if (parsed.deletedBackupVault) setDeletedBackupVault(parsed.deletedBackupVault);
        if (parsed.glassRates) setGlassRates(parsed.glassRates);
        if (parsed.availableColors?.length) setAvailableColors(parsed.availableColors);
        if (parsed.customSections) setCustomSections(parsed.customSections);
        if (parsed.hiddenSections) setHiddenSections(parsed.hiddenSections);
        if (parsed.smsGatewayConfig) {
          setSmsGatewayConfig({ ...DEFAULT_SMS_GATEWAY_CONFIG, ...parsed.smsGatewayConfig });
        }
      }
    } catch {
      // ignore storage errors
    }
    handlePullUsersFromCloud(true);
    const syncTimer = setInterval(() => {
      handlePullUsersFromCloud(true);
    }, 20000);
    return () => clearInterval(syncTimer);
  }, []);

  // Sync Official Golden Lion Main Logo to Browser / PWA App Icon
  useEffect(() => {
    if (!mainLogoUrl) return;
    document
      .querySelectorAll<HTMLLinkElement>('link[rel="icon"], link[rel="apple-touch-icon"]')
      .forEach((link) => {
        link.href = mainLogoUrl;
      });
  }, [mainLogoUrl]);

  // Global Mouse Drag-to-Scroll (Enables smooth click-and-drag scrolling on all horizontal & vertical areas)
  useEffect(() => {
    let isDown = false;
    let hasDragged = false;
    let startX = 0;
    let startY = 0;
    let startScrollLeft = 0;
    let startScrollTop = 0;
    let scrollElX: HTMLElement | null = null;
    let scrollElY: HTMLElement | null = null;

    const findScrollParents = (
      el: HTMLElement | null
    ): { x: HTMLElement | null; y: HTMLElement } => {
      let cur = el;
      let foundX: HTMLElement | null = null;
      let foundY: HTMLElement | null = null;

      while (cur && cur !== document.body && cur !== document.documentElement) {
        const style = window.getComputedStyle(cur);
        if (
          !foundX &&
          (style.overflowX === 'auto' || style.overflowX === 'scroll') &&
          cur.scrollWidth > cur.clientWidth + 1
        ) {
          foundX = cur;
        }
        if (
          !foundY &&
          (style.overflowY === 'auto' || style.overflowY === 'scroll') &&
          cur.scrollHeight > cur.clientHeight + 1
        ) {
          foundY = cur;
        }
        cur = cur.parentElement;
      }

      const rootScroller =
        (document.scrollingElement as HTMLElement) || document.documentElement;
      return {
        x: foundX || (rootScroller.scrollWidth > rootScroller.clientWidth + 1 ? rootScroller : null),
        y: foundY || rootScroller,
      };
    };

    const onMouseDown = (e: MouseEvent) => {
      if (e.button !== 0) return;
      const target = e.target as HTMLElement | null;
      if (!target) return;
      // Allow dragging starting on buttons/tabs too; only skip form inputs & native draggable items
      if (target.closest('input, select, textarea, [draggable="true"]')) {
        return;
      }
      const parents = findScrollParents(target);
      scrollElX = parents.x;
      scrollElY = parents.y;
      isDown = true;
      hasDragged = false;
      startX = e.clientX;
      startY = e.clientY;
      startScrollLeft = scrollElX ? scrollElX.scrollLeft : 0;
      startScrollTop = scrollElY ? scrollElY.scrollTop : 0;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDown) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (!hasDragged && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
        hasDragged = true;
        document.body.style.userSelect = 'none';
      }
      if (hasDragged) {
        if (scrollElX) {
          scrollElX.scrollLeft = startScrollLeft - dx;
        }
        if (scrollElY) {
          scrollElY.scrollTop = startScrollTop - dy;
        }
      }
    };

    const onMouseUp = () => {
      if (isDown) {
        isDown = false;
        document.body.style.userSelect = '';
      }
    };

    const onClickCapture = (e: MouseEvent) => {
      if (hasDragged) {
        e.preventDefault();
        e.stopPropagation();
        hasDragged = false;
      }
    };

    window.addEventListener('mousedown', onMouseDown, { passive: true });
    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mouseup', onMouseUp, { passive: true });
    window.addEventListener('click', onClickCapture, true);
    return () => {
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('click', onClickCapture, true);
    };
  }, []);

  // Persist key state changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          windowFormula,
          slidingDoorFormula,
          doorFormula,
          fixFormula,
          openwinFormula,
          fSectionFormula,
          glassFormulas,
          users,
          dynamicSections,
          blueprints,
          bankAccounts,
          savedQuotations,
          rates,
          packages,
          layoutConfig,
          mainLogoUrl,
          letterheadBgUrl,
          currentTheme,
          downloadedThemes,
          customCreatedThemes,
          deletedBackupVault,
          glassRates,
          availableColors,
          customSections,
          hiddenSections,
          smsGatewayConfig,
        })
      );
    } catch {
      // ignore quota errors
    }
  }, [
    windowFormula,
    slidingDoorFormula,
    doorFormula,
    fixFormula,
    openwinFormula,
    fSectionFormula,
    glassFormulas,
    users,
    dynamicSections,
    blueprints,
    bankAccounts,
    savedQuotations,
    rates,
    packages,
    layoutConfig,
    mainLogoUrl,
    letterheadBgUrl,
    currentTheme,
    downloadedThemes,
    customCreatedThemes,
    deletedBackupVault,
    glassRates,
    availableColors,
    customSections,
    hiddenSections,
    smsGatewayConfig,
  ]);

  const handleClearAllRates = () => {
    const allSecs = Array.from(new Set([...DEFAULT_SECTIONS, ...customSections]));
    const zeroed = getClearedZeroRates(allSecs, availableColors);
    setRates(zeroed);
    triggerGlobalToast('All Rate List prices have been cleared to 0!');
  };

  const handleRestoreDefaultRates = () => {
    setRates(getInitialRates());
    triggerGlobalToast('Factory Default Rate List restored!');
  };

  // Backup Vault Helper
  const handlePushBackupItem = (
    item: Omit<DeletedBackupItem, 'id' | 'deletedAt'>
  ) => {
    const entry: DeletedBackupItem = {
      ...item,
      id: `bkp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      deletedAt: Date.now(),
    };
    setDeletedBackupVault((prev) => [entry, ...prev]);
  };

  // Delete Section (Custom or Built-in) + Save to Backup Vault + Persistent Cloud Sync
  const handleDeleteSection = (sec: string) => {
    const clean = sec.trim();
    if (!clean) return;
    const savedRates: Record<string, Record<string, number>> = {};
    GAUGES.forEach((g) => {
      savedRates[g] = {};
      availableColors.forEach((c) => {
        savedRates[g][c] = rates[g]?.[c]?.[clean] || 0;
      });
    });
    handlePushBackupItem({
      category: 'SECTION',
      title: `Aluminium Section: ${clean}`,
      codeOrKey: clean,
      payload: {
        sectionCode: clean,
        wasCustom: customSections.includes(clean),
        savedRates,
      },
    });

    // Remove from rates immediately
    const nextRates = { ...rates };
    GAUGES.forEach((g) => {
      if (nextRates[g]) {
        availableColors.forEach((c) => {
          if (nextRates[g][c] && clean in nextRates[g][c]) {
            delete nextRates[g][c][clean];
          }
        });
      }
    });
    setRates(nextRates);

    const nextCustom = customSections.filter((s) => s !== clean);
    setCustomSections(nextCustom);

    const nextHidden = !hiddenSections.includes(clean) ? [...hiddenSections, clean] : hiddenSections;
    setHiddenSections(nextHidden);

    const curDeleted = layoutConfig.deletedSections || [];
    const nextDeleted = curDeleted.includes(clean) ? curDeleted : [...curDeleted, clean];
    const nextLayout = {
      ...layoutConfig,
      deletedSections: nextDeleted,
    };
    setLayoutConfig(nextLayout);

    // Save directly to localStorage
    try {
      const curStored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      curStored.rates = nextRates;
      curStored.customSections = nextCustom;
      curStored.hiddenSections = nextHidden;
      curStored.layoutConfig = nextLayout;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(curStored));
    } catch {
      // ignore
    }

    triggerGlobalToast(`Deleted Section "${clean}" — Persisted to Cloud & Local Storage`);
  };

  // Delete Finish Color + Save to Backup Vault
  const handleDeleteColor = (col: string) => {
    const clean = col.trim().toUpperCase();
    if (!clean) return;
    if (availableColors.length <= 1) {
      triggerGlobalToast('At least 1 finish color must remain active.');
      return;
    }
    const savedColorRates: Record<string, Record<string, number>> = {};
    GAUGES.forEach((g) => {
      savedColorRates[g] = { ...(rates[g]?.[clean] || {}) };
    });
    handlePushBackupItem({
      category: 'COLOR',
      title: `Finish Color: ${clean}`,
      codeOrKey: clean,
      payload: {
        colorName: clean,
        savedColorRates,
      },
    });
    const nextCols = availableColors.filter((c) => c !== clean);
    setAvailableColors(nextCols);
    if (ctxColor === clean && nextCols.length > 0) {
      setCtxColor(nextCols[0]);
    }
    triggerGlobalToast(`Deleted Color "${clean}" (Saved in Backup Vault for Restore)`);
  };

  // Add Separate 5mm or 8mm Glass Color
  const handleAddGlassColor = (gauge: string, colorName: string, rate: number) => {
    const clean = colorName.trim().toUpperCase();
    if (!clean) return;
    setGlassRates((prev) => ({
      ...prev,
      [gauge]: {
        ...(prev[gauge] || {}),
        [clean]: rate >= 0 ? rate : 0,
      },
    }));
    triggerGlobalToast(`Added ${gauge}mm Glass Color "${clean}" (Rs. ${rate}/sq.ft)`);
  };

  // Delete Separate 5mm or 8mm Glass Color + Save to Backup Vault
  const handleDeleteGlassColor = (gauge: string, colorName: string) => {
    const clean = colorName.trim();
    const curMap = { ...(glassRates[gauge] || {}) };
    if (Object.keys(curMap).length <= 1) {
      triggerGlobalToast(`At least 1 glass color must remain in ${gauge}mm Glass.`);
      return;
    }
    const oldRate = curMap[clean] ?? 0;
    handlePushBackupItem({
      category: gauge === '5' ? 'GLASS_5MM' : 'GLASS_8MM',
      title: `${gauge}mm Glass Color: ${clean} (Rs. ${oldRate}/sq.ft)`,
      codeOrKey: clean,
      payload: {
        gauge,
        colorName: clean,
        rate: oldRate,
      },
    });
    delete curMap[clean];
    setGlassRates((prev) => ({
      ...prev,
      [gauge]: curMap,
    }));
    const remainingKeys = Object.keys(curMap);
    if (ctxGlassGauge === gauge && ctxGlassColor === clean && remainingKeys.length > 0) {
      setCtxGlassColor(remainingKeys[0]);
    }
    triggerGlobalToast(
      `Deleted ${gauge}mm Glass "${clean}" (Saved in Backup Vault for Restore)`
    );
  };

  // Restore any Deleted Item from Backup Vault (supports ID string or DeletedBackupItem object)
  const handleRestoreBackupItem = (itemOrId: DeletedBackupItem | string) => {
    const item =
      typeof itemOrId === 'string'
        ? deletedBackupVault.find((x) => x.id === itemOrId)
        : itemOrId;
    if (!item) return;
    const p = item.payload || {};
    if (item.category === 'SECTION') {
      const secCode = p.sectionCode || item.codeOrKey;
      if (p.wasCustom && !customSections.includes(secCode)) {
        setCustomSections([...customSections, secCode]);
      }
      setHiddenSections(hiddenSections.filter((s) => s !== secCode));
      setLayoutConfig({
        ...layoutConfig,
        deletedSections: (layoutConfig.deletedSections || []).filter((s) => s !== secCode),
      });
      if (p.savedRates) {
        const nextRates = { ...rates };
        GAUGES.forEach((g) => {
          if (!nextRates[g]) nextRates[g] = {};
          availableColors.forEach((c) => {
            if (!nextRates[g][c]) nextRates[g][c] = {};
            if (p.savedRates[g]?.[c] !== undefined) {
              nextRates[g][c][secCode] = p.savedRates[g][c];
            }
          });
        });
        setRates(nextRates);
      }
    } else if (item.category === 'COLOR') {
      const colName = p.colorName || item.codeOrKey;
      if (!availableColors.includes(colName)) {
        setAvailableColors([...availableColors, colName]);
      }
      if (p.savedColorRates) {
        const nextRates = { ...rates };
        GAUGES.forEach((g) => {
          if (!nextRates[g]) nextRates[g] = {};
          if (p.savedColorRates[g]) {
            nextRates[g][colName] = { ...p.savedColorRates[g] };
          }
        });
        setRates(nextRates);
      }
    } else if (item.category === 'GLASS_5MM' || item.category === 'GLASS_8MM') {
      const g: '5' | '8' = item.category === 'GLASS_5MM' ? '5' : '8';
      const colName = p.colorName || item.codeOrKey;
      const r = typeof p.rate === 'number' ? p.rate : 220;
      setGlassRates((prev) => ({
        ...prev,
        [g]: {
          ...(prev[g] || {}),
          [colName]: r,
        },
      }));
    } else if (item.category === 'CALC_TAB') {
      const tabKey = item.codeOrKey as BossTab;
      setLayoutConfig({
        ...layoutConfig,
        enabledTabs: {
          ...layoutConfig.enabledTabs,
          [tabKey]: true,
        },
      });
    } else if (item.category === 'UI_CONTROL') {
      const ctrlKey = item.codeOrKey as keyof ClientAppLayoutControlConfig;
      setLayoutConfig({
        ...layoutConfig,
        [ctrlKey]: true,
      });
    } else if (item.category === 'BLUEPRINT') {
      if (p.id && !blueprints.some((b) => b.id === p.id)) {
        setBlueprints([p, ...blueprints]);
      }
    } else if (item.category === 'CALC_ITEM') {
      const kind = p.kind;
      const data = p.item;
      if (data) {
        if (kind === 'WINDOW') setWindows([data, ...windows]);
        else if (kind === 'SLIDING_DOOR') setSlidingDoors([data, ...slidingDoors]);
        else if (kind === 'DOOR') setDoors([data, ...doors]);
        else if (kind === 'FIX') setFixFrames([data, ...fixframes]);
        else if (kind === 'OPENWIN') setOpenableWindows([data, ...openableWindows]);
        else if (kind === 'EXTRA') setProjectExtras([data, ...projectExtras]);
      }
    }

    setDeletedBackupVault((prev) => prev.filter((x) => x.id !== item.id));
    triggerGlobalToast(`Restored "${item.title}" back to Client App!`);
  };

  const handleClearAllBackup = () => {
    setDeletedBackupVault([]);
    triggerGlobalToast('Deleted Backup Vault cleared and permanently purged!');
  };

  // Intelligent Upsert for Scanned Rate List (Step 1: No Mass Delete!)
  const handleUpsertScannedRates = (
    rows: {
      sectionTitle: string;
      sectionCode: string;
      gauge: string;
      color: string;
      rate: number;
    }[]
  ) => {
    const nextRates = { ...rates };
    const nextColors = [...availableColors];
    const nextCustomSecs = [...customSections];
    let updated = 0;
    let inserted = 0;

    rows.forEach((r) => {
      const g = r.gauge.replace(/mm/i, '').trim() || '1.2';
      const col = r.color.trim().toUpperCase();
      const sec = r.sectionCode.trim().toUpperCase();
      if (!sec || r.rate <= 0) return;

      if (!nextColors.includes(col)) nextColors.push(col);
      if (!nextCustomSecs.includes(sec)) nextCustomSecs.push(sec);

      if (!nextRates[g]) nextRates[g] = {};
      if (!nextRates[g][col]) nextRates[g][col] = {};

      if (nextRates[g][col][sec] !== undefined) {
        updated++;
      } else {
        inserted++;
      }
      nextRates[g][col][sec] = r.rate;

      // Also sync combined color group keys used by legacy calculator chips
      if (col === 'H23' || col === 'PC-RAL') {
        if (!nextRates[g]['H23/PC-RAL']) nextRates[g]['H23/PC-RAL'] = {};
        nextRates[g]['H23/PC-RAL'][sec] = r.rate;
      }
      if (col === 'SAHARA' || col === 'BROWN') {
        if (!nextRates[g]['SAHARA/BROWN']) nextRates[g]['SAHARA/BROWN'] = {};
        nextRates[g]['SAHARA/BROWN'][sec] = r.rate;
      }
      if (col === 'BLACK' || col === 'MULTI') {
        if (!nextRates[g]['BLACK/MULTI']) nextRates[g]['BLACK/MULTI'] = {};
        nextRates[g]['BLACK/MULTI'][sec] = r.rate;
      }
    });

    setRates(nextRates);
    setAvailableColors(Array.from(new Set(nextColors)));
    setCustomSections(Array.from(new Set(nextCustomSecs)));

    // Sync to Supabase rate_lists table
    callSupabaseProxy({
      table: 'rate_lists',
      method: 'POST',
      payload: {
        device_id: 'master_admin_scanner',
        item_count: rows.length,
        items: rows,
        last_scanned_at: Date.now(),
        date_str: new Date().toLocaleString('en-GB'),
      },
      upsert: true,
    });

    return { updated, inserted };
  };

  // Pull Registered Clients & Subscriptions from Supabase Cloud into Admin Panel
  const handlePullUsersFromCloud = async (silent = false) => {
    try {
      const [uRes, cuRes, sRes] = await Promise.all([
        callSupabaseProxy({ table: 'users', method: 'GET', query: 'select=*' }),
        callSupabaseProxy({ table: 'client_users', method: 'GET', query: 'select=*' }),
        callSupabaseProxy({ table: 'subscriptions', method: 'GET', query: 'select=*' }),
      ]);
      const rawUsers = Array.isArray(uRes?.data) ? uRes.data : [];
      const rawClientUsers = Array.isArray(cuRes?.data) ? cuRes.data : [];
      // Deduplicate by device_id or phone
      const combinedMap = new Map<string, any>();
      [...rawUsers, ...rawClientUsers].forEach((u) => {
        const key = u.device_id || u.phone || u.id;
        if (key) combinedMap.set(key, { ...(combinedMap.get(key) || {}), ...u });
      });
      const cloudUsers = Array.from(combinedMap.values());
      const cloudSubs = Array.isArray(sRes?.data) ? sRes.data : [];
      if (cloudUsers.length === 0) {
        if (!silent) {
          triggerGlobalToast('Connected to Supabase Cloud — No new external client records found yet.');
        }
        return;
      }
      const subByDevice: Record<string, any> = {};
      const subByPhone: Record<string, any> = {};
      cloudSubs.forEach((s: any) => {
        if (s?.device_id) subByDevice[s.device_id] = s;
        if (s?.phone) subByPhone[s.phone] = s;
      });

      setUsers((prevUsers) => {
        // Filter out any mock/dummy demo identities
        const cleanedPrev = prevUsers.filter((u) => {
          const n = u.name || '';
          const d = u.deviceId || '';
          return (
            !n.includes('Usman Khan') &&
            !n.includes('Tariq Mehmood') &&
            !n.includes('Kamran Ahmed') &&
            !d.includes('51D90B32E441') &&
            !d.includes('A98F12B4C891') &&
            !d.includes('77C3E09182FA')
          );
        });
        const merged = [...cleanedPrev];
        const normPhone = (p: string) => String(p || '').replace(/\D/g, '').replace(/^92/, '0');

        cloudUsers.forEach((cu: any) => {
          const devId = cu.device_id || cu.id || cu.phone || '';
          if (!devId && !cu.phone && !cu.cnic) return;
          const sub = subByDevice[devId] || (cu.phone ? subByPhone[cu.phone] : {}) || {};
          const cuNormPhone = normPhone(cu.phone);
          const existingIdx = merged.findIndex(
            (u) =>
              (devId && u.deviceId === devId) ||
              (cuNormPhone && normPhone(u.phone) === cuNormPhone) ||
              (cu.cnic && u.cnic === cu.cnic)
          );
          const existingUser = existingIdx >= 0 ? merged[existingIdx] : undefined;

          // Extract CNIC Front & Back photos from any field name sent by Client App
          const cnicFront =
            cu.cnic_front_photo ||
            cu.cnicFrontImage ||
            cu.cnic_photo_url ||
            cu.cnic_front_url ||
            cu.id_front_photo ||
            cu.cnicPhotoPath ||
            existingUser?.cnicPhotoPath ||
            null;
          const cnicBack =
            cu.cnic_back_photo ||
            cu.cnicBackImage ||
            cu.cnic_back_url ||
            cu.id_back_photo ||
            cu.cnicBackPhotoPath ||
            existingUser?.cnicBackPhotoPath ||
            null;

          // Build merged uploadedPhotos gallery including CNIC Front & Back
          const existingPhotos = existingUser?.uploadedPhotos ? [...existingUser.uploadedPhotos] : [];
          if (cnicFront && !existingPhotos.some((p) => p.category === 'CNIC_FRONT' && p.url === cnicFront)) {
            existingPhotos.unshift({
              id: `cnic-front-${devId || cu.phone}`,
              title: 'CNIC Front Photo (Verified ID)',
              category: 'CNIC_FRONT',
              url: cnicFront,
              uploadedAt: Number(cu.last_cloud_sync || Date.now()),
            });
          }
          if (cnicBack && !existingPhotos.some((p) => p.category === 'CNIC_BACK' && p.url === cnicBack)) {
            existingPhotos.unshift({
              id: `cnic-back-${devId || cu.phone}`,
              title: 'CNIC Back Photo (Verified ID)',
              category: 'CNIC_BACK',
              url: cnicBack,
              uploadedAt: Number(cu.last_cloud_sync || Date.now()),
            });
          }

          const activatedUntil = Number(
            sub.activated_until ??
              cu.subscription_expiry ??
              cu.activated_until ??
              existingUser?.activatedUntil ??
              0
          );
          const isLifetime = Boolean(
            cu.is_lifetime ||
              cu.is_lifetime_free ||
              sub.is_lifetime ||
              cu.subscription_tier === 'LIFETIME_VIP' ||
              cu.package_plan === 'LIFETIME_VIP' ||
              cu.email === 'ssaboor2t@gmail.com' ||
              cu.phone === '03105524225' ||
              activatedUntil > Date.now() + 86400000 * 365 * 10
          );
          const isActivated = Boolean(
            sub.is_activated ??
              cu.is_activated ??
              (activatedUntil > Date.now() || isLifetime)
          );
          const lockReason = String(
            sub.lock_reason ?? cu.block_reason ?? cu.lock_reason ?? ''
          ).trim();
          const isBlocked = Boolean(
            cu.is_blocked ?? cu.isBlocked ?? sub.is_blocked ?? lockReason.length > 0
          );
          const pkgPlan =
            cu.subscription_tier ||
            cu.package_plan ||
            sub.subscription_tier ||
            (isLifetime ? 'LIFETIME_VIP' : isActivated ? existingUser?.packagePlan || 'MONTHLY' : 'TRIAL');

          const mappedUser: IdentityRecord = {
            name: cu.name || existingUser?.name || 'Client User',
            phone: cu.phone || existingUser?.phone || '',
            email: cu.email || existingUser?.email || '',
            shopAddress: cu.shop_address || cu.shopAddress || existingUser?.shopAddress || '',
            cnic: cu.cnic || existingUser?.cnic || '',
            deviceId: devId || existingUser?.deviceId || '',
            ipAddress: cu.ip_address || existingUser?.ipAddress || 'Cloud-Sync',
            cnicPhotoPath: cnicFront,
            cnicBackPhotoPath: cnicBack,
            firstRegisteredAt: Number(
              sub.trial_start_time || cu.trial_start_time || cu.last_cloud_sync || existingUser?.firstRegisteredAt || Date.now()
            ),
            trialStartTime: Number(
              sub.trial_start_time || cu.trial_start_time || cu.last_cloud_sync || existingUser?.trialStartTime || Date.now()
            ),
            isActivated,
            activatedUntil,
            lastPaymentTid: sub.last_payment_tid || cu.last_payment_tid || existingUser?.lastPaymentTid || '',
            isBlocked,
            blockReason: isBlocked ? lockReason || 'Suspended by Master Admin' : '',
            isLifetimeFree: isLifetime,
            packagePlan: pkgPlan,
            uploadedPhotos: existingPhotos,
          };
          if (existingIdx >= 0) {
            merged[existingIdx] = { ...merged[existingIdx], ...mappedUser };
          } else {
            merged.push(mappedUser);
          }
        });
        return merged;
      });

      if (!silent) {
        triggerGlobalToast(
          `Synced ${cloudUsers.length} Client Account(s) from Supabase (${DEFAULT_SUPABASE_URL})!`
        );
      }
    } catch {
      // ignore background pull errors
    }
  };

  // Helper to build 100% comprehensive rates map matching both "1.2" and "1.2mm", "2" and "2mm"/"2.0mm", and individual + combined colors
  const buildComprehensiveRatesMap = (rawRates: Record<string, Record<string, Record<string, number>>>) => {
    const result: Record<string, Record<string, Record<string, number>>> = {};

    Object.keys(rawRates || {}).forEach((gaugeKey) => {
      const cleanNum = gaugeKey.replace(/mm$/i, '').trim();
      const mmKey = `${cleanNum}mm`;
      const noMmKey = cleanNum;

      const colorMap = rawRates[gaugeKey] || {};
      const normalizedColorMap: Record<string, Record<string, number>> = {};

      Object.keys(colorMap).forEach((colorKey) => {
        const secMap = colorMap[colorKey] || {};
        normalizedColorMap[colorKey] = { ...secMap };

        // Split combined colors
        if (colorKey.includes('/')) {
          const parts = colorKey.split('/').map((s) => s.trim()).filter(Boolean);
          parts.forEach((p) => {
            if (!normalizedColorMap[p]) normalizedColorMap[p] = { ...secMap };
          });
        } else if (colorKey === 'H23' || colorKey === 'PC-RAL') {
          if (!normalizedColorMap['H23/PC-RAL']) normalizedColorMap['H23/PC-RAL'] = { ...secMap };
        } else if (colorKey === 'SAHARA' || colorKey === 'BROWN') {
          if (!normalizedColorMap['SAHARA/BROWN']) normalizedColorMap['SAHARA/BROWN'] = { ...secMap };
        } else if (colorKey === 'BLACK' || colorKey === 'MULTI') {
          if (!normalizedColorMap['BLACK/MULTI']) normalizedColorMap['BLACK/MULTI'] = { ...secMap };
        }
      });

      result[noMmKey] = { ...(result[noMmKey] || {}), ...normalizedColorMap };
      result[mmKey] = { ...(result[mmKey] || {}), ...normalizedColorMap };
      result[gaugeKey] = { ...(result[gaugeKey] || {}), ...normalizedColorMap };
      if (noMmKey === '2') {
        result['2.0mm'] = { ...(result['2.0mm'] || {}), ...normalizedColorMap };
      } else if (noMmKey === '3') {
        result['3.0mm'] = { ...(result['3.0mm'] || {}), ...normalizedColorMap };
      } else if (noMmKey === '4') {
        result['4.0mm'] = { ...(result['4.0mm'] || {}), ...normalizedColorMap };
      } else if (noMmKey === '6') {
        result['6.0mm'] = { ...(result['6.0mm'] || {}), ...normalizedColorMap };
      }
    });

    return result;
  };

  const buildComprehensiveGlassRates = (rawGlassRates: Record<string, Record<string, number>>) => {
    const result: Record<string, Record<string, number>> = {};
    Object.keys(rawGlassRates || {}).forEach((gaugeKey) => {
      const cleanNum = gaugeKey.replace(/mm$/i, '').trim();
      const mmKey = `${cleanNum}mm`;
      const noMmKey = cleanNum;
      const colorMap = rawGlassRates[gaugeKey] || {};

      result[noMmKey] = { ...(result[noMmKey] || {}), ...colorMap };
      result[mmKey] = { ...(result[mmKey] || {}), ...colorMap };
      result[gaugeKey] = { ...(result[gaugeKey] || {}), ...colorMap };
    });
    return result;
  };

  // Push Full Master Configuration to Supabase app_configs (100% Matched with Client App BossMasterEngineManager.kt & FirebaseCloudManager.kt)
  const handlePushFullConfigToCloud = async (): Promise<{ ok: boolean; message: string }> => {
    const compRates = buildComprehensiveRatesMap(rates);
    const compGlassRates = buildComprehensiveGlassRates(glassRates);

    const fSecCompatible = {
      ...fSectionFormula,
      heightInch: fSectionFormula.heightDim.inch,
      heightSutar: fSectionFormula.heightDim.sutar,
      widthInch: fSectionFormula.widthDim.inch,
      widthSutar: fSectionFormula.widthDim.sutar,
    };

    // Sync d29WidthOverlap/3/4 with d29ExtraWidthAdd so Client App BossCalculationEngine.kt gets exact +3" 2 sutar (or custom)
    const syncedWinFormula: WindowFormulaSettings = {
      ...windowFormula,
      d29WidthOverlap: windowFormula.d29ExtraWidthAdd || windowFormula.d29WidthOverlap || { inch: 3, sutar: 2 },
      d29WidthOverlap3: windowFormula.d29ExtraWidthAdd || windowFormula.d29WidthOverlap3 || { inch: 3, sutar: 2 },
      d29WidthOverlap4: windowFormula.d29ExtraWidthAdd || windowFormula.d29WidthOverlap4 || { inch: 3, sutar: 2 },
    };

    // Build Client App BossAppViewModel.kt compatible glassFormulas ("win", "opwin", "slidingdoor", "door", "fix")
    const winGf = glassFormulas['window'] || glassFormulas['win'] || getDefaultGlassFormulas()['window'];
    const sdoorGf = glassFormulas['slidingdoor'] || getDefaultGlassFormulas()['slidingdoor'] || winGf;
    const doorGf = glassFormulas['door'] || getDefaultGlassFormulas()['door'];
    const fixGf = glassFormulas['fix'] || getDefaultGlassFormulas()['fix'];
    const openwinGf = glassFormulas['openwin'] || glassFormulas['opwin'] || getDefaultGlassFormulas()['openwin'];

    const m23DedIn = (syncedWinFormula.m23HeightDeduction.inch || 0) + (syncedWinFormula.m23HeightDeduction.sutar || 0) / 8.0;
    const totalSlidingGlassHDed = (winGf.slidingHeightDeductionInch ?? 5) + (winGf.slidingHeightDeductionSutar ?? 5) / 8.0;
    const relSlidingMarginH = -(totalSlidingGlassHDed - m23DedIn); // relative to sashH in BossAppViewModel.kt
    const addWInch = winGf.slidingWidthAddToM24Inch ?? 0;
    const addWSutar = winGf.slidingWidthAddToM24Sutar ?? 5;

    const sdoorM23DedIn = (slidingDoorFormula.m23HeightDeduction.inch || 0) + (slidingDoorFormula.m23HeightDeduction.sutar || 0) / 8.0;
    const totalSDoorGlassHDed = (sdoorGf.slidingHeightDeductionInch ?? 5) + (sdoorGf.slidingHeightDeductionSutar ?? 5) / 8.0;
    const relSDoorMarginH = -(totalSDoorGlassHDed - sdoorM23DedIn);
    const addWSDoorInch = sdoorGf.slidingWidthAddToM24Inch ?? 0;
    const addWSDoorSutar = sdoorGf.slidingWidthAddToM24Sutar ?? 5;

    const makeOpenableClientGlass = (gf?: GlassFormula) => {
      const mh = -Math.abs(gf?.marginH ?? 1);
      const mhs = -Math.abs(gf?.marginHSutar ?? 0);
      const mw = -Math.abs(gf?.marginW ?? 1);
      const mws = -Math.abs(gf?.marginWSutar ?? 0);
      return {
        ...gf,
        marginH: mh,
        marginHSutar: mhs,
        marginW: mw,
        marginWSutar: mws,
        panels: gf?.panels ?? 1,
      };
    };

    const clientSlidingGlassObj = {
      ...winGf,
      marginH: relSlidingMarginH,
      marginHSutar: 0,
      marginW: addWInch,
      marginWSutar: addWSutar,
      marginH3: relSlidingMarginH,
      marginH3Sutar: 0,
      marginW3: addWInch,
      marginW3Sutar: addWSutar,
      marginW3Center: addWInch,
      marginW3CenterSutar: addWSutar,
      marginW3Sides: addWInch,
      marginW3SidesSutar: addWSutar,
      marginH4: relSlidingMarginH,
      marginH4Sutar: 0,
      marginW4: addWInch,
      marginW4Sutar: addWSutar,
      panels: 2,
    };

    const clientSlidingDoorGlassObj = {
      ...sdoorGf,
      marginH: relSDoorMarginH,
      marginHSutar: 0,
      marginW: addWSDoorInch,
      marginWSutar: addWSDoorSutar,
      marginH3: relSDoorMarginH,
      marginH3Sutar: 0,
      marginW3: addWSDoorInch,
      marginW3Sutar: addWSDoorSutar,
      marginW3Center: addWSDoorInch,
      marginW3CenterSutar: addWSDoorSutar,
      marginW3Sides: addWSDoorInch,
      marginW3SidesSutar: addWSDoorSutar,
      marginH4: relSDoorMarginH,
      marginH4Sutar: 0,
      marginW4: addWSDoorInch,
      marginW4Sutar: addWSDoorSutar,
      panels: 2,
    };

    const syncedGlassFormulas = {
      ...glassFormulas,
      win: clientSlidingGlassObj,
      window: { ...winGf, ...clientSlidingGlassObj },
      slidingdoor: { ...sdoorGf, ...clientSlidingDoorGlassObj },
      door: { ...doorGf, ...makeOpenableClientGlass(doorGf) },
      fix: { ...fixGf, ...makeOpenableClientGlass(fixGf) },
      opwin: { ...openwinGf, ...makeOpenableClientGlass(openwinGf) },
      openwin: { ...openwinGf, ...makeOpenableClientGlass(openwinGf) },
    };

    const masterEngineObject = {
      version: Date.now(),
      publishedBy: 'Syed Saboor Nawab (Master)',
      customSections: dynamicSections,
      rates: compRates,
      glassRates: compGlassRates,
      winFormulas: syncedWinFormula,
      windowFormula: syncedWinFormula,
      slidingDoorFormulas: slidingDoorFormula,
      slidingDoorFormula,
      doorFormulas: doorFormula,
      doorFormula,
      fixFormulas: fixFormula,
      fixFormula,
      openableWinFormulas: openwinFormula,
      openwinFormula,
      fSectionFormula: fSecCompatible,
      glassFormulas: syncedGlassFormulas,
      dragDropBlueprints: blueprints,
      blueprints,
      bankAccounts,
      packages,
      subAdmins,
      activeBanner: activeOffer,
      activeOffer,
      layoutConfig,
      smsGatewayConfig,
      userAccessControl: users.map((u) => ({
        device_id: u.deviceId || u.phone,
        phone: u.phone,
        cnic: u.cnic,
        name: u.name,
        is_activated: Boolean(u.isActivated || u.isLifetimeFree),
        is_lifetime: Boolean(u.isLifetimeFree),
        is_blocked: Boolean(u.isBlocked),
        block_reason: u.blockReason || '',
        subscription_tier: u.isLifetimeFree ? 'LIFETIME_VIP' : u.packagePlan || 'TRIAL',
        subscription_expiry: u.isLifetimeFree
          ? Date.now() + 86400000 * 365 * 50
          : Number(u.activatedUntil || 0),
        trial_start_time: Number(u.trialStartTime || Date.now()),
      })),
      companyBranding: {
        companyName,
        companyTagline,
        companyAddress,
        companyPhone,
        companyNtn,
        mainLogoUrl,
        letterheadBgUrl,
      },
      lastUpdated: Date.now(),
      lastCloudSyncAt: Date.now(),
    };

    // Exact payload matching both BossMasterEngineManager.kt (id="master_engine_config") and global_config
    const clientAppDirectPayload = {
      id: 'master_engine_config',
      key: 'master_engine_config',
      config_key: 'master_engine_config',
      value: masterEngineObject,
      config_json: JSON.stringify(masterEngineObject),
      window_formula: syncedWinFormula,
      winFormulas: syncedWinFormula,
      sliding_door_formula: slidingDoorFormula,
      slidingDoorFormulas: slidingDoorFormula,
      door_formula: doorFormula,
      doorFormulas: doorFormula,
      fix_formula: fixFormula,
      fixFormulas: fixFormula,
      openwin_formula: openwinFormula,
      openableWinFormulas: openwinFormula,
      f_section_formula: fSecCompatible,
      fSectionFormula: fSecCompatible,
      glass_formulas: syncedGlassFormulas,
      glassFormulas: syncedGlassFormulas,
      rates: compRates,
      rates_json: compRates,
      glassRates: compGlassRates,
      glass_rates: compGlassRates,
      customSections: dynamicSections,
      custom_sections: customSections,
      deleted_sections: layoutConfig.deletedSections || [],
      deletedSections: layoutConfig.deletedSections || [],
      layout_config: layoutConfig,
      layoutConfig: layoutConfig,
      blueprints: blueprints,
      dragDropBlueprints: blueprints,
      available_colors: availableColors,
      hidden_sections: hiddenSections,
      hardware_rate: String(hardwareRate),
      discount_pct: String(markupPct),
      transport_rent: String(transportRent),
      labour_cost: String(labourCost),
      sms_gateway_config: smsGatewayConfig,
      company_branding: {
        companyName,
        companyTagline,
        companyAddress,
        companyPhone,
        companyNtn,
        mainLogoUrl,
        letterheadBgUrl,
      },
      lastUpdated: Date.now(),
      master_engine: masterEngineObject,
      updated_at: new Date().toISOString(),
    };

    // 1. Upsert primary row expected by BossMasterEngineManager.kt (id = "master_engine_config")
    const res = await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: clientAppDirectPayload,
      upsert: true,
    });

    // 2. Also upsert id = "global_config" so both row keys stay 100% in sync
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        ...clientAppDirectPayload,
        id: 'global_config',
        key: 'global_config',
        config_key: 'global_config',
      },
      upsert: true,
    });

    // 3. Upsert layout_config_v1 for dynamic client UI controls
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        id: 'layout_config_v1',
        key: 'layout_config_v1',
        config_key: 'layout_config_v1',
        value: layoutConfig,
        config_json: JSON.stringify(layoutConfig),
        updated_at: new Date().toISOString(),
      },
      upsert: true,
    });

    // 4. Upsert custom_sections_v1 for custom sections, colors, dynamic sections & hidden sections
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        id: 'custom_sections_v1',
        key: 'custom_sections_v1',
        config_key: 'custom_sections_v1',
        value: {
          customSections,
          dynamicSections,
          availableColors,
          hiddenSections,
          deletedSections: layoutConfig.deletedSections || [],
          deleted_sections: layoutConfig.deletedSections || [],
        },
        config_json: JSON.stringify({
          customSections,
          dynamicSections,
          availableColors,
          hiddenSections,
          deletedSections: layoutConfig.deletedSections || [],
          deleted_sections: layoutConfig.deletedSections || [],
        }),
        updated_at: new Date().toISOString(),
      },
      upsert: true,
    });

    // 5. Upsert blueprints_v1 for custom calculator blueprints
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        id: 'blueprints_v1',
        key: 'blueprints_v1',
        config_key: 'blueprints_v1',
        value: blueprints,
        config_json: JSON.stringify(blueprints),
        updated_at: new Date().toISOString(),
      },
      upsert: true,
    });

    // 6. Upsert aluminium_rates_v1 for aluminum, glass, hardware, and defaults
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        id: 'aluminium_rates_v1',
        key: 'aluminium_rates_v1',
        config_key: 'aluminium_rates_v1',
        rates: compRates,
        glass_rates: compGlassRates,
        value: {
          rates: compRates,
          glassRates: compGlassRates,
          hardwareRate,
          discountPct: markupPct,
          transportRent,
          labourCost,
        },
        config_json: JSON.stringify({
          rates: compRates,
          glassRates: compGlassRates,
          hardwareRate,
          discountPct: markupPct,
          transportRent,
          labourCost,
        }),
        updated_at: new Date().toISOString(),
      },
      upsert: true,
    });

    // 7. Upsert formulas_v1 for cutting & glass deduction formulas
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        id: 'formulas_v1',
        key: 'formulas_v1',
        config_key: 'formulas_v1',
        value: {
          windowFormula: syncedWinFormula,
          slidingDoorFormula,
          doorFormula,
          fixFormula,
          openwinFormula,
          fSectionFormula: fSecCompatible,
          glassFormulas: syncedGlassFormulas,
        },
        config_json: JSON.stringify({
          windowFormula: syncedWinFormula,
          slidingDoorFormula,
          doorFormula,
          fixFormula,
          openwinFormula,
          fSectionFormula: fSecCompatible,
          glassFormulas: syncedGlassFormulas,
        }),
        updated_at: new Date().toISOString(),
      },
      upsert: true,
    });

    // 8. Upsert company_branding_v1
    await callSupabaseProxy({
      table: 'app_configs',
      method: 'POST',
      payload: {
        id: 'company_branding_v1',
        key: 'company_branding_v1',
        config_key: 'company_branding_v1',
        value: {
          companyName,
          companyTagline,
          companyAddress,
          companyPhone,
          companyNtn,
          mainLogoUrl,
          letterheadBgUrl,
        },
        config_json: JSON.stringify({
          companyName,
          companyTagline,
          companyAddress,
          companyPhone,
          companyNtn,
          mainLogoUrl,
          letterheadBgUrl,
        }),
        updated_at: new Date().toISOString(),
      },
      upsert: true,
    });

    // 9. Also upsert fallback table `master_control` (config_id = "global_engine_v1")
    await callSupabaseProxy({
      table: 'master_control',
      method: 'POST',
      payload: {
        config_id: 'global_engine_v1',
        value: masterEngineObject,
        config_json: JSON.stringify(masterEngineObject),
        sms_gateway_config: smsGatewayConfig,
        updated_at_epoch_ms: Date.now(),
      },
      upsert: true,
    });

    const msg =
      res.source === 'supabase_cloud'
        ? `Pushed live to Supabase Cloud (${DEFAULT_SUPABASE_URL}) in ${res.latencyMs}ms! All Client Apps & SendPK settings are 100% synchronized.`
        : `Saved & synced to Master Cloud Mirror (${res.latencyMs || 12}ms) for ${DEFAULT_SUPABASE_URL}. Ready for all Client Apps!`;
    return { ok: true, message: msg };
  };

  // 1. Owner Security Gate: Block all unauthorized visitors from viewing Admin Panel
  if (!isAuthenticated) {
    return (
      <OwnerMasterLoginScreen
        onLoginSuccess={() => {
          setIsAuthenticated(true);
          triggerGlobalToast('Master Admin Vault Unlocked · Welcome, Syed Saboor Nawab!');
        }}
      />
    );
  }

  return (
    <div
      data-btn-style={currentTheme.buttonStyle || 'PILL_3D'}
      data-template={currentTheme.templateLayout || 'CLASSIC_GOLD'}
      className={`min-h-screen bg-[#0F172A] text-[#F1F5F9] flex flex-col boss-theme-root ${
        currentTheme.isLight ? 'boss-theme-light' : ''
      }`}
    >
      {/* =================================================================== */}
      {/* TOP BAR (MATCHES MainDashboardScreen.kt)                            */}
      {/* =================================================================== */}
      <header className="sticky top-0 z-40 bg-[#0F172A]/95 backdrop-blur border-b border-[#334155] px-4 py-2.5 no-print">
        <div className="max-w-[1440px] mx-auto space-y-2">
          {/* Top Brand + Install Windows/Mobile App Row */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              {currentSystem !== 'HUB' && (
                <button
                  onClick={() => setCurrentSystem('HUB')}
                  className="p-1.5 rounded-lg bg-[#1E293B] border border-slate-700 text-[#FFD700] hover:border-[#FFD700] transition-colors"
                  title="Back to Main Hub"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}
              <img
                src={mainLogoUrl}
                alt="Boss Aluminium Lion Emblem"
                onClick={() => setCurrentSystem('HUB')}
                className="w-9 h-9 rounded-full object-cover border border-[#FFD700] cursor-pointer shrink-0 shadow-sm"
              />
              <div
                onClick={() => setCurrentSystem('HUB')}
                className="cursor-pointer"
              >
                <div className="text-sm font-bold text-white leading-tight">
                  Boss Aluminium & Glass
                </div>
                <div className="text-[10px] font-semibold text-[#FFD700]">
                  Master Control Hub · Syed Saboor Nawab (VIP Owner)
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Mobile Theme Studio & Online Store Button */}
              <button
                onClick={() => setShowThemeStudio(true)}
                className="px-3 py-1.5 rounded-lg bg-[#1E293B] border border-[#FFD700]/70 text-xs font-bold text-[#FFD700] hover:bg-[#FFD700] hover:text-black transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Palette className="w-3.5 h-3.5" />
                <span>Themes ({currentTheme.name.split(' ')[0]})</span>
              </button>

              {/* Install as Windows / Mobile App Button */}
              {!isInstalled && (
                <button
                  onClick={async () => {
                    if (isInstallable) {
                      await install();
                    } else {
                      setShowDesktopInstallGuide(true);
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#1E293B] border border-[#FFD700]/60 text-xs font-bold text-[#FFD700] hover:bg-[#FFD700] hover:text-black transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Install Windows / Mobile App</span>
                </button>
              )}

              {currentSystem !== 'HUB' && (
                <button
                  onClick={() => setCurrentSystem('HUB')}
                  className="px-3 py-1.5 rounded-lg bg-[#1E293B] border border-slate-700 text-xs font-bold text-white hover:border-[#FFD700] flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <Home className="w-3.5 h-3.5 text-[#FFD700]" />
                  <span>Main Hub</span>
                </button>
              )}

              {/* Secure Vault Logout Button */}
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-lg bg-red-950/40 border border-red-500/50 text-xs font-bold text-red-300 hover:bg-red-600 hover:text-white transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                title="Lock Master Admin Panel"
              >
                <span>🔒 Lock & Logout</span>
              </button>
            </div>
          </div>

          {/* System Navigation Buttons Row (Matches MainDashboardScreen.kt + Drag & Drop Studio) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              {
                id: 'DASHBOARD' as MainAppSystem,
                title: '1. Dashboard (Users & Bank Pay)',
                icon: LayoutDashboard,
              },
              {
                id: 'DRAG_DROP' as MainAppSystem,
                title: '2. Drag & Drop Builder Studio',
                icon: Layers,
              },
              {
                id: 'SETTINGS' as MainAppSystem,
                title: '3. Settings (Formulas & AI Scan)',
                icon: Settings,
              },
              {
                id: 'LAYOUT' as MainAppSystem,
                title: '4. App Layout & Calculator (9 Tabs)',
                icon: Cpu,
              },
            ].map((sys) => {
              const Icon = sys.icon;
              const isAct = currentSystem === sys.id;
              return (
                <button
                  key={sys.id}
                  onClick={() => setCurrentSystem(sys.id)}
                  className={`h-9 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-all whitespace-nowrap truncate ${
                    isAct
                      ? 'bg-[#FFD700] border-[#FFD700] text-black font-bold shadow-sm'
                      : 'bg-[#1E293B] border-[#FFD700]/50 text-white hover:border-[#FFD700]'
                  }`}
                >
                  <Icon
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isAct ? 'text-black' : 'text-[#FFD700]'
                    }`}
                  />
                  <span className="truncate">{sys.title}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* VIP Owner Status Strip */}
      <div className="bg-[#1B2E24] border-b border-[#FFD700]/60 px-4 py-1.5 no-print">
        <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-[#FFD700] font-bold">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>
              Owner VIP — Syed Saboor Nawab (ssaboor2t@gmail.com · 0310-5524225)
            </span>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="text-emerald-300 font-mono">
              Supabase Cloud: {DEFAULT_SUPABASE_URL}
            </span>
            <button
              onClick={() => handlePullUsersFromCloud(false)}
              className="px-2.5 py-0.5 rounded bg-sky-500/20 border border-sky-400/60 text-sky-300 font-bold hover:bg-sky-400 hover:text-black transition-colors"
            >
              Sync Cloud Clients
            </button>
            <button
              onClick={async () => {
                const res = await handlePushFullConfigToCloud();
                triggerGlobalToast(res.message);
              }}
              className="px-2.5 py-0.5 rounded bg-[#FFD700]/20 border border-[#FFD700]/60 text-[#FFD700] font-bold hover:bg-[#FFD700] hover:text-black transition-colors"
            >
              Push Live to Clients
            </button>
          </div>
        </div>
      </div>

      {/* Global Toast Notification */}
      {globalToast && (
        <div className="max-w-[1440px] w-full mx-auto px-4 pt-3 no-print">
          <div className="px-4 py-2.5 rounded-lg bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{globalToast}</span>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MAIN CONTENT VIEWPORT                                               */}
      {/* =================================================================== */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-4">
        {/* MAIN OVERVIEW HUB (Matches MainHubOverviewScreen in MainDashboardScreen.kt) */}
        {currentSystem === 'HUB' && (
          <div className="space-y-4">
            {/* 1. VIP Owner Welcome Banner */}
            <div className="p-4 rounded-2xl bg-[#1E293B] border border-[#FFD700]/80 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <img
                  src={mainLogoUrl}
                  alt="Boss Aluminium Lion Crest"
                  className="w-14 h-14 rounded-full object-cover border-2 border-[#FFD700] shrink-0 shadow-md"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-base font-bold text-white">Syed Saboor Nawab</h1>
                    <span className="text-xs font-extrabold text-[#FFD700]">· VIP OWNER</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Master Server Engine — Drag & Drop Builder, Unlocked Formulas, AI Rate List Scanner & Supabase Cloud Sync Active
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentSystem('DRAG_DROP')}
                  className="px-3.5 py-2 rounded-xl bg-[#FFD700] text-black text-xs font-bold hover:bg-amber-400 flex items-center gap-1.5"
                >
                  <Layers className="w-4 h-4" />
                  <span>Open Drag & Drop Builder</span>
                </button>
                <button
                  onClick={() => setCurrentSystem('LAYOUT')}
                  className="px-3.5 py-2 rounded-xl bg-emerald-500 text-black text-xs font-bold hover:bg-emerald-400 flex items-center gap-1.5"
                >
                  <Cpu className="w-4 h-4" />
                  <span>Open Live Calculator</span>
                </button>
              </div>
            </div>

            {/* 2. Metrics Quick Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-xl bg-[#1E293B] border border-[#334155] text-center">
                <Users className="w-5 h-5 text-sky-400 mx-auto mb-1" />
                <div className="text-lg font-bold text-white font-mono">{users.length}</div>
                <div className="text-[11px] text-slate-400">Total Clients</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#1E293B] border border-[#334155] text-center">
                <Layers className="w-5 h-5 text-[#FFD700] mx-auto mb-1" />
                <div className="text-lg font-bold text-white font-mono">
                  {blueprints.length + dynamicSections.length}
                </div>
                <div className="text-[11px] text-slate-400">Custom Setups & Sections</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#1E293B] border border-[#334155] text-center">
                <Scissors className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                <div className="text-lg font-bold text-white font-mono">8 Tabs</div>
                <div className="text-[11px] text-slate-400">Unlocked Formula Categories</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#1E293B] border border-[#334155] text-center">
                <FileSpreadsheet className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                <div className="text-lg font-bold text-white font-mono">5-Col AI</div>
                <div className="text-[11px] text-slate-400">Industrial Rate Scanner</div>
              </div>
            </div>

            <div className="text-xs font-bold text-slate-400 tracking-wider">
              SELECT SYSTEM TO LAUNCH
            </div>

            {/* System Launch Cards (Exact Match to MainHubOverviewScreen + New Drag & Drop Card) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Launch Card 1: Drag & Drop Builder Studio */}
              <div
                onClick={() => setCurrentSystem('DRAG_DROP')}
                className="p-4 rounded-xl bg-[#1E293B] border border-[#334155] hover:border-[#FFD700] cursor-pointer transition-all flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-[#FFD700]/15 border border-[#FFD700] flex items-center justify-center text-[#FFD700]">
                        <Layers className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">
                          1. Drag & Drop Window, Door & App Setup Studio
                        </h3>
                        <span className="text-[11px] text-[#FFD700] font-semibold">
                          18+ App Buttons, Tables, Profiles & Live Simulator
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    App mein jitnay bhi Buttons, Tables, Piece Steppers, Section Selectors, aur Window/Door Profiles use huay hain unhein Drag-and-Drop kar ke naya setup banayein aur Live View screen par test karein.
                  </p>
                </div>
                <button className="w-full py-2 rounded-lg bg-[#FFD700] text-black text-xs font-bold flex items-center justify-center gap-1.5">
                  <span>Open Drag & Drop Studio</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Launch Card 2: Users, Packages & Auto Bank Activation */}
              <div
                onClick={() => setCurrentSystem('DASHBOARD')}
                className="p-4 rounded-xl bg-[#1E293B] border border-[#334155] hover:border-sky-400 cursor-pointer transition-all flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-sky-400/15 border border-sky-400 flex items-center justify-center text-sky-400">
                        <LayoutDashboard className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">
                          2. Users, Packages & Direct Bank Auto-Activation
                        </h3>
                        <span className="text-[11px] text-sky-400 font-semibold">
                          Profiles, Subscriptions & 1-Click Bank Transfer
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Clients ki mukammal profiles (CNIC, Mobile, Shop, GPS Location) check karein. Direct Bank / Easypaisa / Raast connect karein taake client ke payment transfer kartay hi App Auto-Active ho jaye.
                  </p>
                </div>
                <button className="w-full py-2 rounded-lg bg-sky-400 text-black text-xs font-bold flex items-center justify-center gap-1.5">
                  <span>Open Users & Bank Dashboard</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Launch Card 3: Live Cutting Formulas & Industrial AI Rate Scanner */}
              <div
                onClick={() => setCurrentSystem('SETTINGS')}
                className="p-4 rounded-xl bg-[#1E293B] border border-[#334155] hover:border-amber-400 cursor-pointer transition-all flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-amber-400/15 border border-amber-400 flex items-center justify-center text-amber-400">
                        <Scissors className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">
                          3. Unlocked Cutting Formulas & Industrial AI Rate Scanner
                        </h3>
                        <span className="text-[11px] text-amber-400 font-semibold">
                          8 Formula Tabs + 5-Column Rate List Upsert + Client Gemini CMD
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Tamam 8 categories ke cutting formulas live change karein. Industrial AI Rate List Scanner se rate list scan kar ke bina purana data delete kiye database update karein, aur Client App ke liye Gemini Command copy karein.
                  </p>
                </div>
                <button className="w-full py-2 rounded-lg bg-amber-400 text-black text-xs font-bold flex items-center justify-center gap-1.5">
                  <span>Open Formulas, Rate Scanner & Settings</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Launch Card 4: App Layout & 9-Screen Cutting Calculator */}
              <div
                onClick={() => setCurrentSystem('LAYOUT')}
                className="p-4 rounded-xl bg-[#1E293B] border border-[#334155] hover:border-emerald-400 cursor-pointer transition-all flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-emerald-400/15 border border-emerald-400 flex items-center justify-center text-emerald-400">
                        <Cpu className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">
                          4. App Layout & Complete Cutting Calculator
                        </h3>
                        <span className="text-[11px] text-emerald-400 font-semibold">
                          All 9 Calculator Screens Live
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Tamam 9 calculator screens (Windows, Doors & Frames, Extra Pieces, Cutting Chart, Length Chart, Glass Chart, Quotation, History, Rates) isi screen par live test aur use karein.
                  </p>
                </div>
                <button className="w-full py-2 rounded-lg bg-emerald-400 text-black text-xs font-bold flex items-center justify-center gap-1.5">
                  <span>Open 9-Screen App Layout & Calculator</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SYSTEM 1: USERS, PACKAGES & DIRECT BANK AUTO-ACTIVATION */}
        {currentSystem === 'DASHBOARD' && (
          <MasterDashboardScreen
            users={users}
            onUpdateUsers={setUsers}
            bankAccounts={bankAccounts}
            onUpdateBankAccounts={setBankAccounts}
            paymentLogs={paymentLogs}
            onAddPaymentLog={(log) => setPaymentLogs([log, ...paymentLogs])}
            packages={packages}
            onUpdatePackages={setPackages}
            activeOffer={activeOffer}
            onSaveOffer={setActiveOffer}
            layoutConfig={layoutConfig}
            onUpdateLayoutConfig={setLayoutConfig}
            windows={windows}
            onUpdateWindows={setWindows}
            doors={doors}
            onUpdateDoors={setDoors}
            fixframes={fixframes}
            onUpdateFixFrames={setFixFrames}
            openableWindows={openableWindows}
            onUpdateOpenableWindows={setOpenableWindows}
            slidingDoors={slidingDoors}
            onUpdateSlidingDoors={setSlidingDoors}
            projectExtras={projectExtras}
            onUpdateProjectExtras={setProjectExtras}
            customSections={customSections}
            onUpdateCustomSections={setCustomSections}
            availableColors={availableColors}
            onUpdateAvailableColors={setAvailableColors}
            hiddenSections={hiddenSections}
            onToggleHideSection={(sec) => {
              setHiddenSections(
                hiddenSections.includes(sec)
                  ? hiddenSections.filter((s) => s !== sec)
                  : [...hiddenSections, sec]
              );
            }}
            onDeleteSection={handleDeleteSection}
            onDeleteColor={handleDeleteColor}
            glassRates={glassRates}
            onUpdateGlassRate={(g, c, r) => {
              setGlassRates({
                ...glassRates,
                [g]: {
                  ...(glassRates[g] || {}),
                  [c]: r,
                },
              });
            }}
            onAddGlassColor={handleAddGlassColor}
            onDeleteGlassColor={handleDeleteGlassColor}
            deletedBackupVault={deletedBackupVault}
            onAddBackupItem={handlePushBackupItem}
            onRestoreBackupItem={handleRestoreBackupItem}
            onClearAllBackup={handleClearAllBackup}
            onPullUsersFromCloud={() => handlePullUsersFromCloud(false)}
            onSyncUserToSupabase={(user) => {
              const devId = user.deviceId || user.phone;
              const expiryMs = user.isLifetimeFree
                ? Date.now() + 86400000 * 365 * 50
                : Number(user.activatedUntil || 0);
              const tier = user.isLifetimeFree
                ? 'LIFETIME_VIP'
                : user.packagePlan || (user.isActivated ? 'MONTHLY' : 'TRIAL');
              const lockMsg = user.isBlocked
                ? user.blockReason || 'Suspended by Master Admin'
                : '';

              const userPayload = {
                device_id: devId,
                name: user.name,
                phone: user.phone,
                email: user.email,
                shop_address: user.shopAddress,
                cnic: user.cnic,
                is_registered: true,
                account_status: user.isBlocked ? 'BLOCKED' : user.isActivated || user.isLifetimeFree ? 'APPROVED' : 'TRIAL',
                is_activated: Boolean(user.isActivated || user.isLifetimeFree),
                is_lifetime: Boolean(user.isLifetimeFree),
                is_blocked: Boolean(user.isBlocked),
                isBlocked: Boolean(user.isBlocked),
                block_reason: lockMsg,
                subscription_tier: tier,
                subscription_expiry: expiryMs,
                activated_until: expiryMs,
                trial_start_time: Number(user.trialStartTime || Date.now()),
                cnic_front_photo: user.cnicPhotoPath || '',
                cnic_back_photo: user.cnicBackPhotoPath || '',
                last_cloud_sync: Date.now(),
              };

              callSupabaseProxy({
                table: 'users',
                method: 'POST',
                payload: userPayload,
                upsert: true,
              });

              callSupabaseProxy({
                table: 'client_users',
                method: 'POST',
                payload: userPayload,
                upsert: true,
              });

              // Also PATCH by phone so if the user registered with a different device_id, their row still updates
              if (user.phone) {
                callSupabaseProxy({
                  table: 'users',
                  method: 'PATCH',
                  query: `phone=eq.${encodeURIComponent(user.phone)}`,
                  payload: userPayload,
                  upsert: false,
                });
                callSupabaseProxy({
                  table: 'client_users',
                  method: 'PATCH',
                  query: `phone=eq.${encodeURIComponent(user.phone)}`,
                  payload: userPayload,
                  upsert: false,
                });
              }

              callSupabaseProxy({
                table: 'subscriptions',
                method: 'POST',
                payload: {
                  device_id: devId,
                  phone: user.phone,
                  cnic: user.cnic,
                  status: user.isBlocked ? 'BLOCKED' : user.isActivated || user.isLifetimeFree ? 'ACTIVE' : 'TRIAL',
                  is_activated: Boolean(user.isActivated || user.isLifetimeFree),
                  is_lifetime: Boolean(user.isLifetimeFree),
                  trial_start_time: user.trialStartTime,
                  activated_until: expiryMs,
                  expiry_date_epoch_ms: expiryMs,
                  subscription_expiry: expiryMs,
                  subscription_tier: tier,
                  last_payment_tid: user.lastPaymentTid || '',
                  lock_reason: lockMsg,
                  is_blocked: Boolean(user.isBlocked),
                  isBlocked: Boolean(user.isBlocked),
                  last_updated: Date.now(),
                },
                upsert: true,
              });
            }}
          />
        )}

        {/* SYSTEM 2: DRAG & DROP WINDOW, DOOR & APP UI STUDIO */}
        {currentSystem === 'DRAG_DROP' && (
          <DragDropStudioScreen
            blueprints={blueprints}
            onSaveBlueprint={(bp, dynSec) => {
              const exists = blueprints.some((b) => b.id === bp.id);
              setBlueprints(
                exists
                  ? blueprints.map((b) => (b.id === bp.id ? bp : b))
                  : [bp, ...blueprints]
              );
              if (dynSec) {
                const secExists = dynamicSections.some((s) => s.code === dynSec.code);
                setDynamicSections(
                  secExists
                    ? dynamicSections.map((s) => (s.code === dynSec.code ? dynSec : s))
                    : [dynSec, ...dynamicSections]
                );
                if (!customSections.includes(dynSec.code)) {
                  setCustomSections([...customSections, dynSec.code]);
                }
              }
            }}
            onDeleteBlueprint={(id) => {
              setBlueprints((prev) => prev.filter((b) => b.id !== id));
              setDynamicSections((prev) => prev.filter((s) => s.id !== id && s.code !== id));
              triggerGlobalToast('Setup deleted permanently.');
            }}
            onSendToCalculator={(bp, w, h, q) => {
              const exists = blueprints.some((b) => b.id === bp.id);
              setBlueprints(
                exists
                  ? blueprints.map((b) => (b.id === bp.id ? bp : b))
                  : [bp, ...blueprints]
              );
              const newWin: WindowItem = {
                id: `win-bp-${Date.now()}`,
                width: w,
                height: h,
                qty: q,
                frameType: bp.outerSectionCode || 'C',
                sectionGauge: ctxGauge,
                glassGauge: ctxGlassGauge,
                glassColor: ctxGlassColor,
                glassEnabled: true,
                m24Qty: (bp.panelCount || 2) * 2,
                m24aQty: 0,
                d29HeightQty: bp.hasNetJali ? ((bp.panelCount || 2) >= 3 ? 4 : 2) : 0,
                d29WidthQty: bp.hasNetJali ? ((bp.panelCount || 2) >= 3 ? 4 : 2) : 0,
                extras: [],
                outerSection: bp.outerSectionCode || 'DC30C',
                panelCount: bp.panelCount || 2,
                lockType: 'LATCH',
                blueprintId: bp.id,
                blueprintName: bp.name,
              };
              setWindows([newWin, ...windows]);
              setCurrentSystem('LAYOUT');
              setCurrentCalcTab('QUOTATION');
              triggerGlobalToast(
                `Auto-Connected "${bp.name}" (${w}" × ${h}") to Cutting Formulas, Cutting Chart, Length Chart & Quotation!`
              );
            }}
            rates={rates}
            customSections={customSections}
            ctxGauge={ctxGauge}
            ctxColor={ctxColor}
            measurementUnit={measurementUnit}
            windowFormula={windowFormula}
            onPushFullConfigToCloud={handlePushFullConfigToCloud}
          />
        )}

        {/* SYSTEM 3: MASTER SETTINGS, FORMULAS, AI RATE SCANNER & SUPABASE */}
        {currentSystem === 'SETTINGS' && (
          <MasterSettingsScreen
            windowFormula={windowFormula}
            onUpdateWindowFormula={setWindowFormula}
            onResetWindowFormula={() => setWindowFormula(getDefaultWindowFormula())}
            slidingDoorFormula={slidingDoorFormula}
            onUpdateSlidingDoorFormula={setSlidingDoorFormula}
            doorFormula={doorFormula}
            onUpdateDoorFormula={setDoorFormula}
            fixFormula={fixFormula}
            onUpdateFixFormula={setFixFormula}
            openwinFormula={openwinFormula}
            onUpdateOpenwinFormula={setOpenwinFormula}
            fSectionFormula={fSectionFormula}
            onUpdateFSectionFormula={setFSectionFormula}
            glassFormulas={glassFormulas}
            onUpdateGlassFormula={(cat, gf) =>
              setGlassFormulas({ ...glassFormulas, [cat]: gf })
            }
            dynamicSections={dynamicSections}
            onSaveDynamicSection={(sec) => {
              setDynamicSections([sec, ...dynamicSections]);
              if (!customSections.includes(sec.code)) {
                setCustomSections([...customSections, sec.code]);
              }
            }}
            onDeleteDynamicSection={(id) =>
              setDynamicSections(dynamicSections.filter((s) => s.id !== id))
            }
            onToggleDynamicSection={(id) =>
              setDynamicSections(
                dynamicSections.map((s) =>
                  s.id === id ? { ...s, isActive: !s.isActive } : s
                )
              )
            }
            blueprints={blueprints}
            onUpdateBlueprints={setBlueprints}
            subAdmins={subAdmins}
            onSaveSubAdmin={(adm) => setSubAdmins([adm, ...subAdmins])}
            onUpdateSubAdmins={setSubAdmins}
            onDeleteSubAdmin={(id) =>
              setSubAdmins(subAdmins.filter((a) => a.id !== id))
            }
            activeOffer={activeOffer}
            onSaveOffer={setActiveOffer}
            rates={rates}
            onUpsertScannedRates={handleUpsertScannedRates}
            onClearAllRates={handleClearAllRates}
            onRestoreDefaultRates={handleRestoreDefaultRates}
            onPushFullConfigToCloud={handlePushFullConfigToCloud}
            smsGatewayConfig={smsGatewayConfig}
            onUpdateSmsGatewayConfig={setSmsGatewayConfig}
            measurementUnit={measurementUnit}
            onSetMeasurementUnit={setMeasurementUnit}
            ctxGauge={ctxGauge}
            ctxGaugeMode={ctxGaugeMode}
            onSetCtxGauge={(g, m) => {
              setCtxGauge(g);
              setCtxGaugeMode(m);
            }}
            ctxColor={ctxColor}
            onSetCtxColor={setCtxColor}
            ctxFrameType={ctxFrameType}
            onSetCtxFrameType={setCtxFrameType}
            ctxGlassMode={ctxGlassMode}
            ctxGlassGauge={ctxGlassGauge}
            ctxGlassColor={ctxGlassColor}
            onSetCtxGlass={(g, c, m) => {
              if (m === 'ON') {
                setCtxGlassGauge(g);
                setCtxGlassColor(c);
                setCtxGlassMode('ON');
              } else {
                setCtxGlassMode('OFF');
              }
            }}
            glassFittingOption={glassFittingOption}
            onSetGlassFittingOption={setGlassFittingOption}
            availableColors={availableColors}
            onUpdateAvailableColors={setAvailableColors}
            customSections={customSections}
            onUpdateCustomSections={setCustomSections}
            hiddenSections={hiddenSections}
            onToggleHideSection={(sec) => {
              setHiddenSections(
                hiddenSections.includes(sec)
                  ? hiddenSections.filter((s) => s !== sec)
                  : [...hiddenSections, sec]
              );
            }}
            onUnhideAllSections={() => setHiddenSections([])}
            glassRates={glassRates}
            onUpdateGlassRate={(g, c, r) => {
              setGlassRates({
                ...glassRates,
                [g]: {
                  ...(glassRates[g] || {}),
                  [c]: r,
                },
              });
            }}
            companyName={companyName}
            companyTagline={companyTagline}
            companyAddress={companyAddress}
            companyPhone={companyPhone}
            companyNtn={companyNtn}
            onUpdateCompanyInfo={(info) => {
              setCompanyName(info.name);
              setCompanyTagline(info.tagline);
              setCompanyAddress(info.address);
              setCompanyPhone(info.phone);
              setCompanyNtn(info.ntn);
            }}
            hardwareRate={hardwareRate}
            discountPct={markupPct}
            transportRent={transportRent}
            labourCost={labourCost}
            onUpdateDefaults={(hw, disc, tr, lc) => {
              setHardwareRate(hw);
              setMarkupPct(disc);
              setTransportRent(tr);
              setLabourCost(lc);
            }}
            mainLogoUrl={mainLogoUrl}
            onUpdateMainLogoUrl={setMainLogoUrl}
            letterheadBgUrl={letterheadBgUrl}
            onUpdateLetterheadBgUrl={setLetterheadBgUrl}
            onRestoreDefaultBrandingAssets={() => {
              setMainLogoUrl(bossLionLogoImg);
              setLetterheadBgUrl(bossLetterheadCleanImg);
            }}
            layoutConfig={layoutConfig}
            onUpdateLayoutConfig={setLayoutConfig}
            onExportFullBackup={() => {
              const raw = localStorage.getItem(STORAGE_KEY) || '{}';
              const blob = new Blob([raw], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `boss_aluminium_master_backup_${Date.now()}.json`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            onImportFullBackup={(jsonStr) => {
              try {
                const parsed = JSON.parse(jsonStr);
                if (parsed.windowFormula) setWindowFormula(parsed.windowFormula);
                if (parsed.rates) setRates(parsed.rates);
                if (parsed.packages) setPackages(parsed.packages);
                if (parsed.layoutConfig) setLayoutConfig(parsed.layoutConfig);
                return true;
              } catch {
                return false;
              }
            }}
          />
        )}

        {/* SYSTEM 4: APP LAYOUT & 9-SCREEN LIVE CALCULATOR */}
        {currentSystem === 'LAYOUT' && (
          <AppLayoutCalculatorScreen
            currentTab={currentCalcTab}
            onSelectTab={setCurrentCalcTab}
            ctxGauge={ctxGauge}
            ctxGaugeMode={ctxGaugeMode}
            onSetCtxGauge={(g, m) => {
              setCtxGauge(g);
              setCtxGaugeMode(m);
            }}
            ctxColor={ctxColor}
            onSetCtxColor={setCtxColor}
            ctxFrameType={ctxFrameType}
            onSetCtxFrameType={setCtxFrameType}
            ctxGlassMode={ctxGlassMode}
            ctxGlassGauge={ctxGlassGauge}
            ctxGlassColor={ctxGlassColor}
            onSetCtxGlass={(g, c, m) => {
              if (m === 'ON') {
                setCtxGlassGauge(g);
                setCtxGlassColor(c);
                setCtxGlassMode('ON');
              } else {
                setCtxGlassMode('OFF');
              }
            }}
            availableColors={availableColors}
            onAddColor={(col) => {
              const up = col.trim().toUpperCase();
              if (up && !availableColors.includes(up)) {
                setAvailableColors([...availableColors, up]);
              }
            }}
            onDeleteColor={handleDeleteColor}
            customSections={customSections}
            onDeleteSection={handleDeleteSection}
            onAddCustomSection={(sec, rate) => {
              const clean = sec.trim().toUpperCase();
              if (!clean) return;
              if (!customSections.includes(clean)) {
                setCustomSections([...customSections, clean]);
              }
              if (rate > 0) {
                const next = { ...rates };
                GAUGES.forEach((g) => {
                  if (!next[g]) next[g] = {};
                  availableColors.forEach((c) => {
                    if (!next[g][c]) next[g][c] = {};
                    next[g][c][clean] = rate;
                  });
                });
                setRates(next);
              }
            }}
            onAddCustomSectionPair={(s1, r1, s2, r2) => {
              const pairName = s2 && s2 !== s1 ? `${s1} / ${s2}` : s1;
              if (!customSections.includes(pairName)) {
                setCustomSections([...customSections, pairName]);
              }
              const next = { ...rates };
              GAUGES.forEach((g) => {
                if (!next[g]) next[g] = {};
                availableColors.forEach((c) => {
                  if (!next[g][c]) next[g][c] = {};
                  if (r1 > 0) next[g][c][s1] = r1;
                  if (s2 && r2 > 0) next[g][c][s2] = r2;
                });
              });
              setRates(next);
              return pairName;
            }}
            windows={windows}
            onUpdateWindows={setWindows}
            doors={doors}
            onUpdateDoors={setDoors}
            fixframes={fixframes}
            onUpdateFixFrames={setFixFrames}
            openableWindows={openableWindows}
            onUpdateOpenableWindows={setOpenableWindows}
            slidingDoors={slidingDoors}
            onUpdateSlidingDoors={setSlidingDoors}
            projectExtras={projectExtras}
            onUpdateProjectExtras={setProjectExtras}
            rates={rates}
            onUpdateSectionRate={(g, c, sec, r) => {
              setRates({
                ...rates,
                [g]: {
                  ...(rates[g] || {}),
                  [c]: {
                    ...(rates[g]?.[c] || {}),
                    [sec]: r,
                  },
                },
              });
            }}
            glassRates={glassRates}
            onUpdateGlassRate={(g, c, r) => {
              setGlassRates({
                ...glassRates,
                [g]: {
                  ...(glassRates[g] || {}),
                  [c]: r,
                },
              });
            }}
            onAddGlassColor={handleAddGlassColor}
            onDeleteGlassColor={handleDeleteGlassColor}
            deletedBackupVault={deletedBackupVault}
            onRestoreBackupItem={handleRestoreBackupItem}
            hiddenSections={hiddenSections}
            onToggleHideSection={(sec) => {
              setHiddenSections(
                hiddenSections.includes(sec)
                  ? hiddenSections.filter((s) => s !== sec)
                  : [...hiddenSections, sec]
              );
            }}
            onUnhideAllSections={() => setHiddenSections([])}
            windowFormula={windowFormula}
            slidingDoorFormula={slidingDoorFormula}
            doorFormula={doorFormula}
            fixFormula={fixFormula}
            openwinFormula={openwinFormula}
            fSectionFormula={fSectionFormula}
            glassFormulas={glassFormulas}
            measurementUnit={measurementUnit}
            onSetMeasurementUnit={setMeasurementUnit}
            glassFittingOption={glassFittingOption}
            onSetGlassFittingOption={setGlassFittingOption}
            companyName={companyName}
            companyTagline={companyTagline}
            companyAddress={companyAddress}
            companyPhone={companyPhone}
            companyNtn={companyNtn}
            onUpdateCompanyInfo={(info) => {
              setCompanyName(info.name);
              setCompanyTagline(info.tagline);
              setCompanyAddress(info.address);
              setCompanyPhone(info.phone);
              setCompanyNtn(info.ntn);
            }}
            customerName={customerName}
            customerPhone={customerPhone}
            onSetCustomerInfo={(n, p) => {
              setCustomerName(n);
              setCustomerPhone(p);
            }}
            hardwareRate={hardwareRate}
            markupPct={markupPct}
            transportRent={transportRent}
            labourCost={labourCost}
            onUpdateDefaults={(hw, mp, tr, lc) => {
              setHardwareRate(hw);
              setMarkupPct(mp);
              setTransportRent(tr);
              setLabourCost(lc);
            }}
            savedQuotations={savedQuotations}
            onSaveQuotationHistory={(q) => {
              setSavedQuotations([q, ...savedQuotations]);
              triggerGlobalToast('Quotation saved to History!');
            }}
            onDeleteQuotationHistory={(id) =>
              setSavedQuotations(savedQuotations.filter((q) => q.id !== id))
            }
            onRestoreQuotation={(q) => {
              try {
                if (q.windowsJson) setWindows(JSON.parse(q.windowsJson));
                if (q.doorsJson) setDoors(JSON.parse(q.doorsJson));
                if (q.fixframesJson) setFixFrames(JSON.parse(q.fixframesJson));
                if (q.openableWindowsJson) setOpenableWindows(JSON.parse(q.openableWindowsJson));
                if (q.slidingDoorsJson) setSlidingDoors(JSON.parse(q.slidingDoorsJson));
                setCustomerName(q.customerName);
                setCustomerPhone(q.customerPhone);
                setCurrentCalcTab('QUOTATION');
                triggerGlobalToast(`Restored "${q.label}" into Calculator!`);
              } catch {
                // ignore parse error
              }
            }}
            onOpenSettingsTab={() => setCurrentSystem('SETTINGS')}
            blueprints={blueprints}
            onClearAllRates={handleClearAllRates}
            onRestoreDefaultRates={handleRestoreDefaultRates}
            onOpenThemeStudio={() => setShowThemeStudio(true)}
            mainLogoUrl={mainLogoUrl}
            onUpdateMainLogoUrl={setMainLogoUrl}
            letterheadBgUrl={letterheadBgUrl}
            onUpdateLetterheadBgUrl={setLetterheadBgUrl}
            onRestoreDefaultBrandingAssets={() => {
              setMainLogoUrl(bossLionLogoImg);
              setLetterheadBgUrl(bossLetterheadCleanImg);
            }}
            layoutConfig={layoutConfig}
            onUpdateLayoutConfig={setLayoutConfig}
            onExportFullBackup={() => {
              const raw = localStorage.getItem(STORAGE_KEY) || '{}';
              const blob = new Blob([raw], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `boss_aluminium_master_backup_${Date.now()}.json`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            onImportFullBackup={(jsonStr) => {
              try {
                const parsed = JSON.parse(jsonStr);
                if (parsed.windowFormula) setWindowFormula(parsed.windowFormula);
                if (parsed.rates) setRates(parsed.rates);
                if (parsed.packages) setPackages(parsed.packages);
                if (parsed.layoutConfig) setLayoutConfig(parsed.layoutConfig);
                return true;
              } catch {
                return false;
              }
            }}
            onPushFullConfigToCloud={handlePushFullConfigToCloud}
            activeOffer={activeOffer}
            onSaveOffer={setActiveOffer}
            packages={packages}
            onUpdatePackages={setPackages}
            bankAccounts={bankAccounts}
          />
        )}
      </main>

      {/* Mobile Theme Studio & Online Cloud Theme Store Modal */}
      {showThemeStudio && (
        <ThemeStudioModal
          currentTheme={currentTheme}
          downloadedThemes={downloadedThemes}
          onApplyTheme={(thm) => {
            const safe = enforceReadableContrast(thm);
            setCurrentTheme(safe);
            triggerGlobalToast(
              `Applied Mobile Theme: "${safe.name}" (${safe.buttonStyle} + ${safe.templateLayout})`
            );
          }}
          onDownloadTheme={(thm) => {
            if (!downloadedThemes.some((d) => d.id === thm.id)) {
              setDownloadedThemes([thm, ...downloadedThemes]);
            }
          }}
          onClose={() => setShowThemeStudio(false)}
        />
      )}

      {/* Windows PC / Android / iPhone Install Guide Modal */}
      {showDesktopInstallGuide && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#14181F] border border-[#FFD700] p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#FFD700]">
                Install Boss Aluminium Admin & Calculator on Windows PC, Android & iPhone
              </h3>
              <button
                onClick={() => setShowDesktopInstallGuide(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-slate-300">
              <div className="p-3 rounded-xl bg-[#0C0F14] border border-slate-800">
                <div className="font-bold text-amber-300 mb-1">
                  1. Windows Computer / Laptop (Chrome ya Edge):
                </div>
                <p className="text-[11px] leading-relaxed">
                  Apne browser mein is app ko New Tab mein open karein aur address bar ke right side par <strong>"Install Boss Admin" (Computer Icon)</strong> par click karein. Yeh bilkul Windows Software ki tarah aap ke Desktop aur Taskbar par install ho jaye gi!
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0C0F14] border border-slate-800">
                <div className="font-bold text-emerald-400 mb-1">
                  2. Android Mobile (Chrome):
                </div>
                <p className="text-[11px] leading-relaxed">
                  Browser menu (3 dots) par tap kar ke <strong>"Install App" / "Add to Home Screen"</strong> select karein.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0C0F14] border border-slate-800">
                <div className="font-bold text-sky-400 mb-1">
                  3. Apple iPhone / iPad (Safari):
                </div>
                <p className="text-[11px] leading-relaxed">
                  Safari mein <strong>Share</strong> button dabayein aur <strong>"Add to Home Screen"</strong> par tap karein.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowDesktopInstallGuide(false)}
              className="w-full py-2.5 rounded-lg bg-[#FFD700] text-black font-bold"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
