import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  CloudUpload,
  Copy,
  Database,
  Download,
  FileSpreadsheet,
  Image as ImageIcon,
  Megaphone,
  Plus,
  RefreshCw,
  Scissors,
  Settings,
  ShieldAlert,
  Sliders,
  Sparkles,
  Table,
  Trash2,
  Unlock,
  Upload,
  UserCheck,
  X,
  Search,
  Eye,
  Printer,
} from 'lucide-react';
import {
  AppOfferBanner,
  ClientAppLayoutControlConfig,
  DeductionDim,
  DragDropBlueprint,
  DynamicMasterSection,
  FormulaCategorySettings,
  FSectionFormula,
  GlassFormula,
  MeasurementUnit,
  SlidingDoorFormulaSettings,
  SubAdminPermissions,
  SubAdminUser,
  WindowFormulaSettings,
} from '../types/bossModels';
import {
  callSupabaseProxy,
  DEFAULT_PUBLISHABLE_KEY,
  DEFAULT_SMS_GATEWAY_CONFIG,
  DEFAULT_SUPABASE_URL,
  SmsOtpGatewayConfig,
} from '../utils/supabaseClientConfig';
import {
  DEFAULT_GLASS_COLORS_5MM,
  DEFAULT_GLASS_COLORS_8MM,
  DEFAULT_SECTIONS,
  GAUGES,
  SECTION_LABELS,
} from '../utils/bossDefaultRates';

interface ScannedRateRow {
  sectionTitle: string;
  sectionCode: string;
  gauge: string;
  color: string;
  rate: number;
}

interface MasterSettingsScreenProps {
  windowFormula: WindowFormulaSettings;
  onUpdateWindowFormula: (wf: WindowFormulaSettings) => void;
  onResetWindowFormula: () => void;
  slidingDoorFormula: SlidingDoorFormulaSettings;
  onUpdateSlidingDoorFormula: (sdf: SlidingDoorFormulaSettings) => void;
  doorFormula: FormulaCategorySettings;
  onUpdateDoorFormula: (df: FormulaCategorySettings) => void;
  fixFormula: FormulaCategorySettings;
  onUpdateFixFormula: (ff: FormulaCategorySettings) => void;
  openwinFormula: FormulaCategorySettings;
  onUpdateOpenwinFormula: (of: FormulaCategorySettings) => void;
  fSectionFormula: FSectionFormula;
  onUpdateFSectionFormula: (f: FSectionFormula) => void;
  glassFormulas: Record<string, GlassFormula>;
  onUpdateGlassFormula: (cat: string, gf: GlassFormula) => void;
  dynamicSections: DynamicMasterSection[];
  onSaveDynamicSection: (sec: DynamicMasterSection) => void;
  onDeleteDynamicSection: (id: string) => void;
  onToggleDynamicSection: (id: string) => void;
  blueprints: DragDropBlueprint[];
  onUpdateBlueprints: (bps: DragDropBlueprint[]) => void;
  subAdmins: SubAdminUser[];
  onSaveSubAdmin: (admin: SubAdminUser) => void;
  onUpdateSubAdmins: (admins: SubAdminUser[]) => void;
  onDeleteSubAdmin: (id: string) => void;
  activeOffer: AppOfferBanner | null;
  onSaveOffer: (offer: AppOfferBanner | null) => void;
  rates: Record<string, Record<string, Record<string, number>>>;
  onUpsertScannedRates: (rows: ScannedRateRow[]) => { updated: number; inserted: number };
  onClearAllRates: () => void;
  onRestoreDefaultRates: () => void;
  onPushFullConfigToCloud: () => Promise<{ ok: boolean; message: string }>;
  smsGatewayConfig?: SmsOtpGatewayConfig;
  onUpdateSmsGatewayConfig?: (cfg: SmsOtpGatewayConfig) => void;
  // All Remaining App Layout Settings Props
  measurementUnit: MeasurementUnit;
  onSetMeasurementUnit: (u: MeasurementUnit) => void;
  ctxGauge: string;
  ctxGaugeMode: 'ON' | 'OFF';
  onSetCtxGauge: (g: string, mode: 'ON' | 'OFF') => void;
  ctxColor: string;
  onSetCtxColor: (c: string) => void;
  ctxFrameType: string;
  onSetCtxFrameType: (ft: string) => void;
  ctxGlassMode: 'ON' | 'OFF';
  ctxGlassGauge: string;
  ctxGlassColor: string;
  onSetCtxGlass: (g: string, c: string, mode: 'ON' | 'OFF') => void;
  glassFittingOption: 'FIX_RUBBER' | 'U_PVC';
  onSetGlassFittingOption: (opt: 'FIX_RUBBER' | 'U_PVC') => void;
  availableColors: string[];
  onUpdateAvailableColors: (cols: string[]) => void;
  customSections: string[];
  onUpdateCustomSections: (secs: string[]) => void;
  hiddenSections: string[];
  onToggleHideSection: (sec: string) => void;
  onUnhideAllSections: () => void;
  glassRates: Record<string, Record<string, number>>;
  onUpdateGlassRate: (gauge: string, color: string, rate: number) => void;
  companyName: string;
  companyTagline: string;
  companyAddress: string;
  companyPhone: string;
  companyNtn: string;
  onUpdateCompanyInfo: (info: {
    name: string;
    tagline: string;
    address: string;
    phone: string;
    ntn: string;
  }) => void;
  hardwareRate: number;
  discountPct: number;
  transportRent: number;
  labourCost: number;
  onUpdateDefaults: (hw: number, disc: number, tr: number, lc: number) => void;
  mainLogoUrl: string;
  onUpdateMainLogoUrl: (url: string) => void;
  letterheadBgUrl: string;
  onUpdateLetterheadBgUrl: (url: string) => void;
  onRestoreDefaultBrandingAssets: () => void;
  layoutConfig: ClientAppLayoutControlConfig;
  onUpdateLayoutConfig: (cfg: ClientAppLayoutControlConfig) => void;
  onExportFullBackup: () => void;
  onImportFullBackup: (jsonStr: string) => boolean;
}

const ALL_PERMISSION_DEFINITIONS: {
  key: keyof Omit<SubAdminPermissions, 'customPermissions'>;
  title: string;
  desc: string;
}[] = [
  {
    key: 'canViewOtherUsersData',
    title: '1. View All Clients Data & Profiles',
    desc: 'Allow viewing registered client names, mobile numbers, CNIC, shop address & device IDs',
  },
  {
    key: 'canViewUploadedUserPhotos',
    title: '2. View & Manage User Uploaded Photos (CNIC & Receipts)',
    desc: 'Access client uploaded CNIC front/back photos, shop photos & payment screenshots',
  },
  {
    key: 'canViewEditFormulas',
    title: '3. View & Edit Cutting Formulas (All 8 Tabs)',
    desc: 'Allow changing Sliding Window, Door, Fix, Openable, F-Section & Glass deductions',
  },
  {
    key: 'canUseDragDropStudio',
    title: '4. Use Drag & Drop Window/Door Builder Studio',
    desc: 'Allow creating and modifying custom Drag & Drop blueprints and setups',
  },
  {
    key: 'canEditAppLayoutElements',
    title: '5. Edit / Remove App Layout & Client App UI Elements',
    desc: 'Allow hiding, renaming or removing tabs, selectors, sections, colors & calculator items',
  },
  {
    key: 'canCreateNewSections',
    title: '6. Create & Edit Custom Aluminium Sections',
    desc: 'Allow adding new section codes and parametric formulas to the master engine',
  },
  {
    key: 'canEditGlobalRates',
    title: '7. Edit Global Aluminium & Glass Rate Lists',
    desc: 'Allow updating per-foot section prices, glass sq.ft rates, or clearing rate data',
  },
  {
    key: 'canScanRateListsAI',
    title: '8. Run Multi-Photo AI Rate List Scanner',
    desc: 'Allow uploading rate list photos/PDFs and running 5-column database upsert',
  },
  {
    key: 'canControlUserTrials',
    title: '9. Control Client 2-Day Free Trials & Block/Unblock',
    desc: 'Allow extending +7 days trial, unbinding devices, or blocking/unblocking users',
  },
  {
    key: 'canControlUserPayments',
    title: '10. Verify Bank Payments & Unlock Client Apps',
    desc: 'Allow approving TID receipts, bank accounts, and unlocking active client subscriptions',
  },
  {
    key: 'canManageSubscriptionPackages',
    title: '11. Add & Edit Subscription Packages (3k, 8k, 16k, 31k, 60k)',
    desc: 'Allow creating new subscription plans or editing existing package prices/durations',
  },
  {
    key: 'canMarkLifetimeFree',
    title: '12. Grant or Revoke Lifetime Free VIP Status',
    desc: 'Allow marking a client account as Lifetime Free VIP (Rs. 60,000 forever license)',
  },
  {
    key: 'canViewClientLocations',
    title: '13. View Live Client GPS Map Locations',
    desc: 'Allow opening exact Google Maps GPS coordinates of registered client shops',
  },
  {
    key: 'canManageRequests',
    title: '14. Manage Client Support & Unlock Requests',
    desc: 'Allow resolving support tickets and generating device-bound activation codes',
  },
  {
    key: 'canManageOffers',
    title: '15. Publish Broadcast Announcements & Offer Banners',
    desc: 'Allow pushing live notice banners to all connected Client Apps',
  },
  {
    key: 'canEditBrandingAndLetterhead',
    title: '16. Edit Main Lion Logo, Letterhead & Company Info',
    desc: 'Allow changing the main logo, quotation letterhead background & company details',
  },
];

export const MasterSettingsScreen: React.FC<MasterSettingsScreenProps> = ({
  windowFormula,
  onUpdateWindowFormula,
  onResetWindowFormula,
  slidingDoorFormula,
  onUpdateSlidingDoorFormula,
  doorFormula,
  onUpdateDoorFormula,
  fixFormula,
  onUpdateFixFormula,
  openwinFormula,
  onUpdateOpenwinFormula,
  fSectionFormula,
  onUpdateFSectionFormula,
  glassFormulas,
  onUpdateGlassFormula,
  dynamicSections = [],
  onDeleteDynamicSection,
  blueprints = [],
  onUpdateBlueprints,
  subAdmins = [],
  onSaveSubAdmin,
  onUpdateSubAdmins = () => {},
  onDeleteSubAdmin,
  activeOffer,
  onSaveOffer,
  rates = {},
  onUpsertScannedRates,
  onClearAllRates,
  onRestoreDefaultRates,
  onPushFullConfigToCloud,
  smsGatewayConfig = DEFAULT_SMS_GATEWAY_CONFIG,
  onUpdateSmsGatewayConfig = () => {},
  measurementUnit = 'INCH_SUTAR',
  onSetMeasurementUnit = () => {},
  ctxGauge = '1.6',
  ctxGaugeMode = 'ON',
  onSetCtxGauge = () => {},
  ctxColor = 'DULL',
  onSetCtxColor = () => {},
  ctxFrameType = 'C',
  onSetCtxFrameType = () => {},
  ctxGlassMode = 'ON',
  ctxGlassGauge = '5',
  ctxGlassColor = 'CLEAR',
  onSetCtxGlass = () => {},
  glassFittingOption = 'FIX_RUBBER',
  onSetGlassFittingOption = () => {},
  availableColors = [],
  onUpdateAvailableColors = () => {},
  customSections = [],
  onUpdateCustomSections = () => {},
  hiddenSections = [],
  onToggleHideSection = () => {},
  onUnhideAllSections = () => {},
  glassRates = {},
  onUpdateGlassRate = () => {},
  companyName = 'BOSS ALUMINIUM & GLASS',
  companyTagline = '',
  companyAddress = '',
  companyPhone = '',
  companyNtn = '',
  onUpdateCompanyInfo = () => {},
  hardwareRate = 3000,
  discountPct = 0,
  transportRent = 0,
  labourCost = 0,
  onUpdateDefaults = () => {},
  mainLogoUrl = '',
  onUpdateMainLogoUrl = () => {},
  letterheadBgUrl = '',
  onUpdateLetterheadBgUrl = () => {},
  onRestoreDefaultBrandingAssets = () => {},
  layoutConfig,
  onUpdateLayoutConfig = () => {},
  onExportFullBackup = () => {},
  onImportFullBackup = () => false,
}) => {
  const [selectedSubTab, setSelectedSubTab] = useState<number>(0);
  const [formulaSubTab, setFormulaSubTab] = useState<
    'WINDOW' | 'SLIDING_DOOR' | 'DOOR' | 'FIX' | 'OPENWIN' | 'FSECTION' | 'GLASS' | 'DYNAMIC'
  >('WINDOW');
  const [winPanelTab, setWinPanelTab] = useState<2 | 3 | 4>(2);
  const [toast, setToast] = useState<string | null>(null);
  const [isPushing, setIsPushing] = useState(false);

  // Industrial Rate List Scanner State (Supports Multi-Image / Multi-PDF Batch!)
  const [scanFiles, setScanFiles] = useState<
    { name: string; mimeType: string; imageBase64: string; previewUrl?: string }[]
  >([]);
  const [rawRateText, setRawRateText] = useState<string>('');
  const [isScanningRates, setIsScanningRates] = useState<boolean>(false);
  const [scannedRows, setScannedRows] = useState<ScannedRateRow[]>([]);
  const [fiveColumnOutput, setFiveColumnOutput] = useState<string>('');
  const [scanError, setScanError] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);
  const [showSavedRatesModal, setShowSavedRatesModal] = useState<boolean>(false);
  const [savedRatesGauge, setSavedRatesGauge] = useState<string>('1.6');
  const [savedRatesColor, setSavedRatesColor] = useState<string>('DULL');
  const [savedRatesSearch, setSavedRatesSearch] = useState<string>('');

  // Manual section input toggle state per formula item: { [`${bp.id}-${it.id}`]: boolean }
  const [customSecInputMode, setCustomSecInputMode] = useState<Record<string, boolean>>({});

  // Dynamic aggregation of all sections across DEFAULT_SECTIONS, customSections, dynamicSections, and rates
  const allRateListSections = useMemo(() => {
    const set = new Set<string>();

    (DEFAULT_SECTIONS || []).forEach((s) => s && set.add(s.trim().toUpperCase()));
    (customSections || []).forEach((s) => s && set.add(s.trim().toUpperCase()));
    (dynamicSections || []).forEach((d) => d?.code && set.add(d.code.trim().toUpperCase()));

    if (rates && typeof rates === 'object') {
      Object.values(rates).forEach((gaugeObj) => {
        if (gaugeObj && typeof gaugeObj === 'object') {
          Object.values(gaugeObj).forEach((colorObj) => {
            if (colorObj && typeof colorObj === 'object') {
              Object.keys(colorObj).forEach((sec) => {
                if (sec && sec.trim()) set.add(sec.trim().toUpperCase());
              });
            }
          });
        }
      });
    }

    (blueprints || []).forEach((bp) => {
      bp.items?.forEach((it) => {
        if (it.sectionCode && it.sectionCode.trim()) {
          set.add(it.sectionCode.trim().toUpperCase());
        }
      });
    });

    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rates, customSections, dynamicSections, blueprints]);

  // Sub-Admin Form State with All 16 Permissions + Custom Permissions (All ON/OFF Switches!)
  const [adminName, setAdminName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPhone, setAdminPhone] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [newCustomPermName, setNewCustomPermName] = useState('');
  const [draftPermissions, setDraftPermissions] = useState<SubAdminPermissions>({
    canViewOtherUsersData: true,
    canViewUploadedUserPhotos: true,
    canViewEditFormulas: false,
    canUseDragDropStudio: true,
    canEditAppLayoutElements: false,
    canCreateNewSections: false,
    canEditGlobalRates: false,
    canScanRateListsAI: true,
    canControlUserTrials: true,
    canControlUserPayments: true,
    canManageSubscriptionPackages: false,
    canMarkLifetimeFree: false,
    canViewClientLocations: true,
    canManageRequests: true,
    canManageOffers: false,
    canEditBrandingAndLetterhead: false,
    customPermissions: {},
  });

  // App Layout General Settings State
  const [newColorName, setNewColorName] = useState('');
  const [newSectionCode, setNewSectionCode] = useState('');
  const [sdPanelTab, setSdPanelTab] = useState<2 | 3 | 4>(2);
  const [newFormulaSecInput, setNewFormulaSecInput] = useState('D54A');
  const [newFormulaQtyH, setNewFormulaQtyH] = useState<number>(2);
  const [newFormulaQtyW, setNewFormulaQtyW] = useState<number>(1);

  // Broadcast Form State
  const [offerBadge, setOfferBadge] = useState(activeOffer?.badgeText || 'Special Offer');
  const [offerTitle, setOfferTitle] = useState(activeOffer?.title || '');
  const [offerMsg, setOfferMsg] = useState(activeOffer?.message || '');

  // Supabase Config State
  const [supabaseUrl, setSupabaseUrl] = useState(DEFAULT_SUPABASE_URL);
  const [supabaseStatus, setSupabaseStatus] = useState<string | null>(null);
  const [testSmsPhone, setTestSmsPhone] = useState('03105524225');
  const [testSmsStatus, setTestSmsStatus] = useState<string | null>(null);
  const [isSendingTestSms, setIsSendingTestSms] = useState(false);
  const [cloudOtpLogs, setCloudOtpLogs] = useState<any[]>([]);
  const [isLoadingOtpLogs, setIsLoadingOtpLogs] = useState(false);

  const handleFetchCloudOtpLogs = async () => {
    setIsLoadingOtpLogs(true);
    try {
      const res = await callSupabaseProxy({
        table: 'otp_verifications',
        method: 'GET',
        query: 'select=*&order=created_at.desc&limit=15',
      });
      if (Array.isArray(res?.data)) {
        setCloudOtpLogs(res.data);
      } else if (Array.isArray(res?.mirrorData)) {
        setCloudOtpLogs(res.mirrorData);
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingOtpLogs(false);
    }
  };

  const showNotice = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  // Reusable Sleek ON / OFF Toggle Switch (No Checkboxes!)
  const renderOnOffSwitch = (
    checked: boolean,
    onChange: (next: boolean) => void,
    labelOn = 'ON',
    labelOff = 'OFF'
  ) => (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`relative inline-flex items-center h-6 w-14 rounded-full transition-colors px-1 shrink-0 ${
        checked
          ? 'bg-emerald-500 text-black justify-end'
          : 'bg-slate-800 border border-slate-600 text-slate-400 justify-start'
      }`}
    >
      <span className="text-[9px] font-black tracking-wider px-1">
        {checked ? labelOn : labelOff}
      </span>
      <span
        className={`w-4 h-4 rounded-full transition-transform ${
          checked ? 'bg-black' : 'bg-slate-400'
        }`}
      />
    </button>
  );

  const handleFileSelectForRateScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const selectedArray = Array.from(fileList);

    const readPromises = selectedArray.map(
      (file) =>
        new Promise<{ name: string; mimeType: string; imageBase64: string; previewUrl?: string }>(
          (resolve) => {
            const reader = new FileReader();
            reader.onload = () => {
              const res = String(reader.result || '');
              const base64 = res.includes(',') ? res.split(',')[1] : res;
              resolve({
                name: file.name,
                mimeType: file.type || 'image/jpeg',
                imageBase64: base64,
                previewUrl: file.type.startsWith('image/') ? res : undefined,
              });
            };
            reader.readAsDataURL(file);
          }
        )
    );

    const loaded = await Promise.all(readPromises);
    setScanFiles((prev) => [...prev, ...loaded]);
    showNotice(`${loaded.length} photo(s)/PDF(s) added for batch scanning!`);
    e.target.value = '';
  };

  const handleRunIndustrialRateScan = async () => {
    setIsScanningRates(true);
    setScanError(null);
    try {
      const resp = await fetch('/api/scan-rate-list', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          files: scanFiles.map((f) => ({
            imageBase64: f.imageBase64,
            mimeType: f.mimeType,
            name: f.name,
          })),
          rawTextInput: rawRateText,
        }),
      });
      const data = await resp.json();
      if (!resp.ok || data.error) {
        setScanError(data.error || 'Failed to scan rate list.');
      } else {
        setScannedRows(data.rows || []);
        setFiveColumnOutput(data.formattedFiveColumnText || '');
        showNotice(
          `Scanned ${scanFiles.length || 1} sheet(s) & extracted ${
            data.rowCount || 0
          } standardized 5-column rate entries!`
        );
      }
    } catch (err: any) {
      setScanError(err?.message || 'Network error while scanning rate list.');
    } finally {
      setIsScanningRates(false);
    }
  };

  const handleImageUploadToDataUrl = (
    e: React.ChangeEvent<HTMLInputElement>,
    cb: (dataUrl: string) => void,
    label: string
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const res = String(reader.result || '');
      if (res) {
        cb(res);
        showNotice(`${label} updated!`);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const renderDimInputs = (
    label: string,
    dim: DeductionDim,
    onChange: (next: DeductionDim) => void
  ) => (
    <div className="p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800 space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold text-slate-300">{label}</span>
        <span className="text-[11px] font-mono text-[#F5B738]">
          = {dim.inch}" {dim.sutar} sutar ({(dim.inch + dim.sutar / 8).toFixed(3)}")
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="block text-[10px] text-slate-400">Inches</label>
          <input
            type="number"
            step="0.5"
            value={dim.inch}
            onChange={(e) => onChange({ ...dim, inch: parseFloat(e.target.value) || 0 })}
            className="w-full px-2.5 py-1 rounded bg-[#14181F] border border-slate-700 text-xs font-mono text-white"
          />
        </div>
        <div>
          <label className="block text-[10px] text-slate-400">Sutar (0 - 7)</label>
          <input
            type="number"
            step="0.5"
            value={dim.sutar}
            onChange={(e) => onChange({ ...dim, sutar: parseFloat(e.target.value) || 0 })}
            className="w-full px-2.5 py-1 rounded bg-[#14181F] border border-slate-700 text-xs font-mono text-white"
          />
        </div>
      </div>
    </div>
  );

  const renderOpenableCategoryEditor = (
    catKey: 'door' | 'fix' | 'openwin' | 'window' | 'sliding_door',
    title: string,
    settings: FormulaCategorySettings,
    onUpdate: (next: FormulaCategorySettings) => void,
    defaultSecs: string[] = ['D54A', 'D51A', 'D45A', 'D42', 'D50', 'D46', 'D52', 'D41', 'D59', 'D59A']
  ) => {
    const safeSettings: FormulaCategorySettings = {
      formulas: settings?.formulas || {},
      acc: settings?.acc || {},
      outerQtyH: settings?.outerQtyH ?? 2,
      outerQtyW: settings?.outerQtyW ?? (catKey === 'door' ? 1 : 2),
      outerDeductH: settings?.outerDeductH || { inch: 0, sutar: 0 },
      outerDeductW: settings?.outerDeductW || { inch: 0, sutar: 0 },
    };

    const allSecs = Array.from(
      new Set([...defaultSecs, ...Object.keys(safeSettings.acc)])
    );

    const catalogChoices = Array.from(
      new Set([
        'D54A',
        'D54F',
        'D51A',
        'D51',
        'D51F',
        'D45A',
        'D45',
        'D42',
        'D42F',
        'D50',
        'D46',
        'D52',
        'D41',
        'D59',
        'D59A',
        'DC30C',
        'DC26C',
        'DC30F',
        'DC26F',
        'M30',
        'M26',
        'M30F',
        'M26F',
        'M23',
        'M28',
        'M24',
        'M24A',
        'D29',
        'D31',
        ...DEFAULT_SECTIONS,
        ...customSections,
      ])
    );

    return (
      <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-bold text-[#F5B738]">{title}</h4>
            <p className="text-xs text-slate-400">
              Har section ka alag Height & Width Formula aur Pieces Count (1 Pc, 2 Pcs, 3 Pcs, 4 Pcs...) set karein ya naya section formula box add karein.
            </p>
          </div>
        </div>

        {/* Default Outer Frame Pieces & Formula Box (for Door, Fix, OpenWin) */}
        {(catKey === 'door' || catKey === 'fix' || catKey === 'openwin') && (
          <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-[#F5B738]/60 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <span className="text-xs font-bold text-[#F5B738]">
                Default Outer Frame Formula & Piece Count (e.g. Door = 2H + 1W, Fix/Window = 2H + 2W)
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">
                  Outer Height Pieces (1, 2, 3...)
                </label>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4].map((n) => (
                    <button
                      key={n}
                      onClick={() => onUpdate({ ...safeSettings, outerQtyH: n })}
                      className={`px-2 py-1 rounded text-[11px] font-bold ${
                        safeSettings.outerQtyH === n
                          ? 'bg-[#F5B738] text-black'
                          : 'bg-[#1C222B] text-slate-300'
                      }`}
                    >
                      {n} Pc
                    </button>
                  ))}
                  <input
                    type="number"
                    value={safeSettings.outerQtyH}
                    onChange={(e) =>
                      onUpdate({
                        ...safeSettings,
                        outerQtyH: Math.max(0, parseInt(e.target.value, 10) || 0),
                      })
                    }
                    className="w-14 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">
                  Outer Width Pieces (1, 2, 3...)
                </label>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4].map((n) => (
                    <button
                      key={n}
                      onClick={() => onUpdate({ ...safeSettings, outerQtyW: n })}
                      className={`px-2 py-1 rounded text-[11px] font-bold ${
                        safeSettings.outerQtyW === n
                          ? 'bg-[#F5B738] text-black'
                          : 'bg-[#1C222B] text-slate-300'
                      }`}
                    >
                      {n} Pc
                    </button>
                  ))}
                  <input
                    type="number"
                    value={safeSettings.outerQtyW}
                    onChange={(e) =>
                      onUpdate({
                        ...safeSettings,
                        outerQtyW: Math.max(0, parseInt(e.target.value, 10) || 0),
                      })
                    }
                    className="w-14 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">
                  Outer H Deduct (Inch / Sutar)
                </label>
                <div className="flex gap-1">
                  <input
                    type="number"
                    value={safeSettings.outerDeductH?.inch ?? 0}
                    onChange={(e) =>
                      onUpdate({
                        ...safeSettings,
                        outerDeductH: {
                          inch: parseFloat(e.target.value) || 0,
                          sutar: safeSettings.outerDeductH?.sutar ?? 0,
                        },
                      })
                    }
                    placeholder="in"
                    className="w-1/2 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                  <input
                    type="number"
                    value={safeSettings.outerDeductH?.sutar ?? 0}
                    onChange={(e) =>
                      onUpdate({
                        ...safeSettings,
                        outerDeductH: {
                          inch: safeSettings.outerDeductH?.inch ?? 0,
                          sutar: parseFloat(e.target.value) || 0,
                        },
                      })
                    }
                    placeholder="sut"
                    className="w-1/2 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">
                  Outer W Deduct (Inch / Sutar)
                </label>
                <div className="flex gap-1">
                  <input
                    type="number"
                    value={safeSettings.outerDeductW?.inch ?? 0}
                    onChange={(e) =>
                      onUpdate({
                        ...safeSettings,
                        outerDeductW: {
                          inch: parseFloat(e.target.value) || 0,
                          sutar: safeSettings.outerDeductW?.sutar ?? 0,
                        },
                      })
                    }
                    placeholder="in"
                    className="w-1/2 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                  <input
                    type="number"
                    value={safeSettings.outerDeductW?.sutar ?? 0}
                    onChange={(e) =>
                      onUpdate({
                        ...safeSettings,
                        outerDeductW: {
                          inch: safeSettings.outerDeductW?.inch ?? 0,
                          sutar: parseFloat(e.target.value) || 0,
                        },
                      })
                    }
                    placeholder="sut"
                    className="w-1/2 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* + Add New Section Height & Width Formula Box Creator */}
        <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-emerald-500/50 space-y-2.5 text-xs">
          <div className="font-bold text-emerald-400">
            + Add New Section Height & Width Formula Box (1 Pc, 2 Pcs, 3 Pcs...)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 items-end">
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">
                Select or Type Section Code
              </label>
              <div className="flex gap-1">
                <select
                  value={newFormulaSecInput}
                  onChange={(e) => setNewFormulaSecInput(e.target.value)}
                  className="w-1/2 px-2 py-1.5 rounded bg-[#14181F] border border-slate-700 text-amber-300 font-bold"
                >
                  {catalogChoices.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={newFormulaSecInput}
                  onChange={(e) => setNewFormulaSecInput(e.target.value.toUpperCase())}
                  placeholder="Code"
                  className="w-1/2 px-2 py-1.5 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                />
              </div>
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">
                Height Pieces (0, 1, 2, 3...)
              </label>
              <input
                type="number"
                value={newFormulaQtyH}
                onChange={(e) => setNewFormulaQtyH(Math.max(0, parseInt(e.target.value, 10) || 0))}
                className="w-full px-2.5 py-1.5 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">
                Width Pieces (0, 1, 2, 3...)
              </label>
              <input
                type="number"
                value={newFormulaQtyW}
                onChange={(e) => setNewFormulaQtyW(Math.max(0, parseInt(e.target.value, 10) || 0))}
                className="w-full px-2.5 py-1.5 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
              />
            </div>
            <button
              onClick={() => {
                const sec = newFormulaSecInput.trim().toUpperCase();
                if (!sec) return;
                onUpdate({
                  ...safeSettings,
                  acc: {
                    ...safeSettings.acc,
                    [sec]: {
                      enabled: true,
                      which: sec,
                      applyTo:
                        newFormulaQtyH > 0 && newFormulaQtyW > 0
                          ? 'both'
                          : newFormulaQtyH > 0
                          ? 'H'
                          : 'W',
                      qty: Math.max(1, newFormulaQtyH || newFormulaQtyW),
                      qtyH: newFormulaQtyH,
                      qtyW: newFormulaQtyW,
                      hOp: 'MINUS',
                      wOp: 'MINUS',
                      wDivisor: 1,
                    },
                  },
                  formulas: {
                    ...safeSettings.formulas,
                    [sec]: safeSettings.formulas[sec] || {
                      h: { inch: 0, sutar: 0 },
                      w: { inch: 0, sutar: 0 },
                    },
                  },
                });
                showNotice(`Added Height & Width Formula Box for "${sec}"!`);
              }}
              className="py-1.5 px-3 rounded-lg bg-emerald-500 text-black font-bold hover:bg-emerald-400"
            >
              + Add Formula Box
            </button>
          </div>
        </div>

        {/* Grid of Section-Wise Height & Width Formula Boxes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {allSecs.map((sec) => {
            const defaultEnabled =
              catKey === 'door'
                ? ['D41', 'D50', 'D46'].includes(sec)
                : catKey === 'fix'
                ? sec === 'D41'
                : catKey === 'openwin'
                ? ['D41', 'D50'].includes(sec)
                : false;
            const acc = safeSettings.acc[sec] || {
              enabled: defaultEnabled,
              which: sec,
              applyTo: sec === 'D46' || sec === 'D52' || sec === 'D59' || sec === 'D59A' ? 'W' : 'both',
              qty: sec === 'D46' || sec === 'D52' ? 1 : 2,
              qtyH: sec === 'D46' || sec === 'D52' || sec === 'D59' || sec === 'D59A' ? 0 : 2,
              qtyW:
                sec === 'D46' ||
                sec === 'D52' ||
                (catKey === 'door' && (sec === 'D50' || sec === 'D54A' || sec === 'D51A' || sec === 'D45A' || sec === 'D42'))
                  ? 1
                  : 2,
              hOp: 'MINUS',
              wOp: 'MINUS',
              wDivisor: 1,
            };
            const form = safeSettings.formulas[sec] || {
              h: { inch: 0, sutar: 0 },
              w: { inch: 0, sutar: 0 },
            };

            return (
              <div
                key={sec}
                className={`p-3.5 rounded-xl border space-y-2.5 ${
                  acc.enabled
                    ? 'bg-[#0C0F14] border-[#F5B738]/50'
                    : 'bg-[#0C0F14]/60 border-slate-800 opacity-75'
                }`}
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2.5">
                    {renderOnOffSwitch(acc.enabled, (next) =>
                      onUpdate({
                        ...safeSettings,
                        acc: {
                          ...safeSettings.acc,
                          [sec]: { ...acc, enabled: next },
                        },
                      })
                    )}
                    <span className="text-xs font-bold text-[#F5B738] font-mono">
                      {sec} Formula Box
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {(['H', 'W', 'both'] as const).map((ap) => (
                      <button
                        key={ap}
                        onClick={() =>
                          onUpdate({
                            ...safeSettings,
                            acc: { ...safeSettings.acc, [sec]: { ...acc, applyTo: ap } },
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          acc.applyTo === ap
                            ? 'bg-[#F5B738] text-black'
                            : 'bg-[#1C222B] text-slate-400'
                        }`}
                      >
                        {ap === 'both' ? 'H + W' : ap === 'H' ? 'Height Only' : 'Width Only'}
                      </button>
                    ))}
                    {!defaultSecs.includes(sec) && (
                      <button
                        onClick={() => {
                          const nextAcc = { ...safeSettings.acc };
                          const nextForm = { ...safeSettings.formulas };
                          delete nextAcc[sec];
                          delete nextForm[sec];
                          onUpdate({
                            ...safeSettings,
                            acc: nextAcc,
                            formulas: nextForm,
                          });
                          showNotice(`Removed "${sec}" formula box`);
                        }}
                        className="ml-1 p-1 rounded bg-rose-950/80 text-rose-400 hover:text-rose-200"
                        title="Remove Section Formula Box"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Separate Height Pieces & Width Pieces (Quick 0, 1, 2, 3, 4 Buttons + Input) */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] text-slate-300 font-semibold">
                        Height Pieces (H Qty)
                      </label>
                      <div className="flex gap-0.5">
                        {[0, 1, 2, 3, 4].map((n) => (
                          <button
                            key={n}
                            onClick={() =>
                              onUpdate({
                                ...safeSettings,
                                acc: { ...safeSettings.acc, [sec]: { ...acc, qtyH: n } },
                              })
                            }
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                              acc.qtyH === n
                                ? 'bg-[#F5B738] text-black'
                                : 'bg-[#0C0F14] text-slate-400'
                            }`}
                          >
                            {n}
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="number"
                      value={acc.qtyH}
                      onChange={(e) =>
                        onUpdate({
                          ...safeSettings,
                          acc: {
                            ...safeSettings.acc,
                            [sec]: { ...acc, qtyH: parseInt(e.target.value, 10) || 0 },
                          },
                        })
                      }
                      className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                    />
                  </div>

                  <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] text-slate-300 font-semibold">
                        Width Pieces (W Qty)
                      </label>
                      <div className="flex gap-0.5">
                        {[0, 1, 2, 3, 4].map((n) => (
                          <button
                            key={n}
                            onClick={() =>
                              onUpdate({
                                ...safeSettings,
                                acc: { ...safeSettings.acc, [sec]: { ...acc, qtyW: n } },
                              })
                            }
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                              acc.qtyW === n
                                ? 'bg-[#F5B738] text-black'
                                : 'bg-[#0C0F14] text-slate-400'
                            }`}
                          >
                            {n}
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="number"
                      value={acc.qtyW}
                      onChange={(e) =>
                        onUpdate({
                          ...safeSettings,
                          acc: {
                            ...safeSettings.acc,
                            [sec]: { ...acc, qtyW: parseInt(e.target.value, 10) || 0 },
                          },
                        })
                      }
                      className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                    />
                  </div>
                </div>

                {/* Separate Height Formula (H - / H + Inch.Sutar) & Width Formula (W - / W + Inch.Sutar & /1 /2 /3 /4) */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-amber-300 font-semibold">
                        Height Formula (Inch.Sutar)
                      </span>
                      <button
                        onClick={() =>
                          onUpdate({
                            ...safeSettings,
                            acc: {
                              ...safeSettings.acc,
                              [sec]: {
                                ...acc,
                                hOp: acc.hOp === 'PLUS' ? 'MINUS' : 'PLUS',
                              },
                            },
                          })
                        }
                        className="px-1.5 py-0.5 rounded bg-[#0C0F14] border border-slate-700 text-[9px] font-mono text-[#F5B738]"
                      >
                        {acc.hOp === 'PLUS' ? 'H + (Add)' : 'H - (Deduct)'}
                      </button>
                    </div>
                    <div className="flex gap-1">
                      <input
                        type="number"
                        value={form.h.inch}
                        onChange={(e) =>
                          onUpdate({
                            ...safeSettings,
                            formulas: {
                              ...safeSettings.formulas,
                              [sec]: {
                                ...form,
                                h: { ...form.h, inch: parseFloat(e.target.value) || 0 },
                              },
                            },
                          })
                        }
                        placeholder="Inch"
                        className="w-1/2 px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                      <input
                        type="number"
                        value={form.h.sutar}
                        onChange={(e) =>
                          onUpdate({
                            ...safeSettings,
                            formulas: {
                              ...safeSettings.formulas,
                              [sec]: {
                                ...form,
                                h: { ...form.h, sutar: parseFloat(e.target.value) || 0 },
                              },
                            },
                          })
                        }
                        placeholder="Sutar"
                        className="w-1/2 px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>

                  <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-sky-300 font-semibold">
                        Width Formula (Inch.Sutar)
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() =>
                            onUpdate({
                              ...safeSettings,
                              acc: {
                                ...safeSettings.acc,
                                [sec]: {
                                  ...acc,
                                  wOp: acc.wOp === 'PLUS' ? 'MINUS' : 'PLUS',
                                },
                              },
                            })
                          }
                          className="px-1.5 py-0.5 rounded bg-[#0C0F14] border border-slate-700 text-[9px] font-mono text-sky-300"
                        >
                          {acc.wOp === 'PLUS' ? 'W+' : 'W-'}
                        </button>
                        <select
                          value={acc.wDivisor || 1}
                          onChange={(e) =>
                            onUpdate({
                              ...safeSettings,
                              acc: {
                                ...safeSettings.acc,
                                [sec]: {
                                  ...acc,
                                  wDivisor: (parseInt(e.target.value, 10) || 1) as any,
                                },
                              },
                            })
                          }
                          className="px-1 py-0.5 rounded bg-[#0C0F14] border border-slate-700 text-[9px] font-mono text-amber-300"
                        >
                          <option value={1}>÷1</option>
                          <option value={2}>÷2</option>
                          <option value={3}>÷3</option>
                          <option value={4}>÷4</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <input
                        type="number"
                        value={form.w.inch}
                        onChange={(e) =>
                          onUpdate({
                            ...safeSettings,
                            formulas: {
                              ...safeSettings.formulas,
                              [sec]: {
                                ...form,
                                w: { ...form.w, inch: parseFloat(e.target.value) || 0 },
                              },
                            },
                          })
                        }
                        placeholder="Inch"
                        className="w-1/2 px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                      <input
                        type="number"
                        value={form.w.sutar}
                        onChange={(e) =>
                          onUpdate({
                            ...safeSettings,
                            formulas: {
                              ...safeSettings.formulas,
                              [sec]: {
                                ...form,
                                w: { ...form.w, sutar: parseFloat(e.target.value) || 0 },
                              },
                            },
                          })
                        }
                        placeholder="Sutar"
                        className="w-1/2 px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Ready-to-copy One-Shot Gemini Master Command for Client App Chat (Dynamic Cloud SendPK + D31 Serialization Fix)
  const clientAppGeminiMasterCommand = `FINAL CLOUD SENDPK & FORMULA SYNC COMMAND FOR CLIENT APP (TAAKE SENDPK PURCHASE KARNE PAR APP DOBARA INSTALL NA KARNI PARAY):
Supabase URL="${DEFAULT_SUPABASE_URL}" aur Publishable Key="${DEFAULT_PUBLISHABLE_KEY}" Admin Panel ke sath 100% connected hai. Ab Client App mein sirf yeh 3 choti cheezain update kar dein taake jab bhi main future mein SendPK purchase kar ke Admin Panel Settings mein API Key daloon, Client App bina dobara install kiye khud-ba-khud Cloud se SendPK chala le:

1. DYNAMIC CLOUD SENDPK & RESEND KEYS (FirebaseCloudManager.kt & BossMasterEngineManager.kt):
   - In BossMasterEngineManager.kt, when parsing "app_configs" (key = "master_engine_config" or "global_config"), also parse "smsGatewayConfig" / "sms_gateway_config" (sendpkEnabled, sendpkApiKey, sendpkUsername, sendpkPassword, sendpkSenderMask, smsComPkApiKey, smsComPkSenderMask, resendApiKey, otpFromEmail, otpMessageTemplate, allowFallbackOtpWhenUnconfigured) and save them to SharedPreferences ("boss_supabase_master_prefs").
   - In FirebaseCloudManager.kt (sendPakistanLocalSmsOtp & sendEmailOtp), read the cloud-synced SendPK API Key / Username / Password / Sender Mask and Resend API Key from SharedPreferences ("boss_supabase_master_prefs") first before falling back to BuildConfig.SENDPK_API_KEY, so whenever the Owner updates SendPK credentials in the Admin Panel after purchasing a package, all installed Client Apps immediately use the new SendPK credentials without rebuilding or reinstalling the APK!

2. FALLBACK OTP DISPLAY WHEN SENDPK IS NOT YET PURCHASED (UserProfileOnboardingDialog.kt):
   - In UserProfileOnboardingDialog.kt, if SendPK / Email API is not yet purchased/enabled (i.e. localSmsProvider == null or sendpkEnabled == false), show the generated 6-digit verification code on screen (or allow 1-tap Auto-Fill) so new clients can complete registration smoothly before SendPK is purchased; and as soon as SendPK is enabled from Admin Panel, automatically hide the on-screen code and require SMS inbox verification.

3. SYNC 4-PALAY D31 DEDUCTION & DOOR/FIX/OPENWIN DEFAULTS (BossSerializationHelper.kt & BossAluminiumModels.kt):
   - In BossSerializationHelper.kt (serializeWindowFormulas, deserializeWindowFormulas, serializeSlidingDoorFormulas, deserializeSlidingDoorFormulas), include "d31HeightDeduction4" so 4-Palay D31 interlock deduction syncs from Admin Cloud.
   - In BossAluminiumModels.kt (FormulaCategorySettings.defaultAccessories), set D59 and D52 enabled = false by default in the acc map (since D59, D59A, and D52 are controlled by the per-card D59/D59A/D52 piece counters) and set D46 qtyW = 1.`;

  return (
    <div className="space-y-4">
      {toast && (
        <div className="px-4 py-2.5 rounded-lg bg-emerald-950/90 border border-emerald-500/60 text-emerald-200 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toast}</span>
        </div>
      )}

      {/* Top Master Banner */}
      <div className="p-4 rounded-xl bg-[#14181F] border border-[#F5B738]/70 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-[#F5B738]">
            Master Settings, Unlocked Cutting Formulas, AI Rate Scanner & Sub-Admin Switches
          </h2>
          <p className="text-xs text-slate-400">
            Yahan tamam 8 Cutting Formulas, AI Rate List Scanner, Sub-Admin ON/OFF Switches, Broadcast Banners, aur Supabase Cloud Connection mojood hain (App Layout ki tamam settings App Layout ke andar move kar di gayi hain).
          </p>
        </div>
        <button
          onClick={async () => {
            setIsPushing(true);
            const res = await onPushFullConfigToCloud();
            setIsPushing(false);
            showNotice(res.message);
          }}
          disabled={isPushing}
          className="px-4 py-2 rounded-lg bg-emerald-500 text-black text-xs font-bold hover:bg-emerald-400 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <CloudUpload className="w-4 h-4" />
          <span>{isPushing ? 'Pushing Live...' : 'Push All Settings, Formulas & Rates Live'}</span>
        </button>
      </div>

      {/* Sub-Navigation Pills (App Sections & Blocks removed; App Layout Settings moved inside App Layout Calculator!) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { idx: 0, label: '1. Cutting Formulas (Unlocked)', icon: Scissors },
          { idx: 1, label: '2. AI Rate List Scanner (Multi-Pic)', icon: FileSpreadsheet },
          { idx: 3, label: '3. Sub-Admins & All Permissions (ON/OFF Switch)', icon: UserCheck },
          { idx: 4, label: '4. Broadcasts & Banners', icon: Megaphone },
          { idx: 5, label: '5. Supabase Cloud Sync & Rates Push (Live DB)', icon: Database },
        ].map((t) => {
          const Icon = t.icon;
          const isSel = selectedSubTab === t.idx;
          return (
            <button
              key={t.idx}
              onClick={() => setSelectedSubTab(t.idx)}
              className={`px-3.5 py-2 rounded-lg border text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
                isSel
                  ? 'bg-[#F5B738] border-[#F5B738] text-black'
                  : 'bg-[#14181F] border-[#2B3441] text-slate-200 hover:border-slate-600'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* =================================================================== */}
      {/* SUB-TAB 0: ALL 8 CUTTING FORMULA CATEGORIES (UNLOCKED IN ADMIN!)    */}
      {/* =================================================================== */}
      {selectedSubTab === 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {[
              { id: 'WINDOW', label: '1. Sliding Windows' },
              { id: 'SLIDING_DOOR', label: '2. Sliding Doors (M30/M26)' },
              { id: 'DOOR', label: '3. Openable Doors' },
              { id: 'FIX', label: '4. Fix Frames' },
              { id: 'OPENWIN', label: '5. Openable Windows' },
              { id: 'FSECTION', label: '6. F-Sections (+2" 3s)' },
              { id: 'GLASS', label: '7. Glass Cutting Margins' },
              { id: 'DYNAMIC', label: '8. Drag & Drop Auto-Formulas' },
            ].map((ft) => (
              <button
                key={ft.id}
                onClick={() => setFormulaSubTab(ft.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  formulaSubTab === ft.id
                    ? 'bg-amber-500/20 border border-[#F5B738] text-[#F5B738] font-bold'
                    : 'bg-[#14181F] border border-[#2B3441] text-slate-300 hover:text-white'
                }`}
              >
                {ft.label}
              </button>
            ))}
          </div>

          {/* 1. SLIDING WINDOWS FORMULAS (100% UNLOCKED) */}
          {formulaSubTab === 'WINDOW' && (
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-[#F5B738]">
                      Sliding Window Cutting Formulas (Master Admin Unlocked)
                    </h3>
                    <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                      <Unlock className="w-3 h-3" /> All Deductions Editable
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Jo deduction aap yahan change karein gay, woh App Layout Calculator aur Client App dono mein foran apply ho gi.
                  </p>
                </div>
                <button
                  onClick={() => {
                    onResetWindowFormula();
                    showNotice('Sliding Window formulas reset to factory defaults');
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-slate-700 text-xs text-amber-300 hover:border-amber-400 flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Defaults</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {renderDimInputs(
                  '1. M23 & M28 Sash Height Deduction (H - x)',
                  windowFormula.m23HeightDeduction,
                  (next) =>
                    onUpdateWindowFormula({
                      ...windowFormula,
                      m23HeightDeduction: next,
                      d29HeightDeduction: next,
                    })
                )}
                {renderDimInputs(
                  '2. D29 Jali Extra Width Addition (M24 + x)',
                  windowFormula.d29ExtraWidthAdd || { inch: 3, sutar: 2 },
                  (next) =>
                    onUpdateWindowFormula({
                      ...windowFormula,
                      d29ExtraWidthAdd: next,
                    })
                )}
                {renderDimInputs(
                  '3. Push Handle Deduction on D29 Jali',
                  windowFormula.d29PushHandleDeduction,
                  (next) =>
                    onUpdateWindowFormula({
                      ...windowFormula,
                      d29PushHandleDeduction: next,
                    })
                )}
              </div>

              {/* 2-Palay / 3-Palay / 4-Palay M24 Width Deductions (ALL 3 PALAY BOXES SHOWN TOGETHER!) */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
                {/* 2-PALAY SLIDING WINDOW FORMULA BOX */}
                <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-[#F5B738]/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#F5B738]">
                      2-Palay Window Formula Box
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">4 M24 Pcs</span>
                  </div>
                  {renderDimInputs(
                    '2-Palay M24 Width Deduction: (W - x) / 2',
                    windowFormula.m24WidthDeduction,
                    (next) =>
                      onUpdateWindowFormula({
                        ...windowFormula,
                        m24WidthDeduction: next,
                      })
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M23 Height Pcs (2P)
                      </label>
                      <input
                        type="number"
                        value={windowFormula.m23Qty}
                        onChange={(e) =>
                          onUpdateWindowFormula({
                            ...windowFormula,
                            m23Qty: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M28 Height Pcs (2P)
                      </label>
                      <input
                        type="number"
                        value={windowFormula.m28Qty}
                        onChange={(e) =>
                          onUpdateWindowFormula({
                            ...windowFormula,
                            m28Qty: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* 3-PALAY SLIDING WINDOW FORMULA BOX */}
                <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-sky-500/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-sky-400">
                      3-Palay Window Formula Box
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">2 Center + 4 Sides</span>
                  </div>
                  {renderDimInputs(
                    '3-Palay Center M24 Deduction: (W - x) / 2 [2 Pcs]',
                    windowFormula.m24WidthCenterDeduction3,
                    (next) =>
                      onUpdateWindowFormula({
                        ...windowFormula,
                        m24WidthCenterDeduction3: next,
                      })
                  )}
                  {renderDimInputs(
                    '3-Palay Sides M24 Deduction: (W - x) / 4 [4 Pcs]',
                    windowFormula.m24WidthSidesDeduction3,
                    (next) =>
                      onUpdateWindowFormula({
                        ...windowFormula,
                        m24WidthSidesDeduction3: next,
                      })
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M23 Height Pcs (3P)
                      </label>
                      <input
                        type="number"
                        value={windowFormula.m23Qty3}
                        onChange={(e) =>
                          onUpdateWindowFormula({
                            ...windowFormula,
                            m23Qty3: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M28 Height Pcs (3P)
                      </label>
                      <input
                        type="number"
                        value={windowFormula.m28Qty3}
                        onChange={(e) =>
                          onUpdateWindowFormula({
                            ...windowFormula,
                            m28Qty3: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* 4-PALAY SLIDING WINDOW FORMULA BOX */}
                <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-emerald-500/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400">
                      4-Palay Window Formula Box
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">8 M24 + 1 D31</span>
                  </div>
                  {renderDimInputs(
                    '4-Palay M24 Width Deduction: (W - x) / 4 [8 Pcs]',
                    windowFormula.m24WidthDeduction4,
                    (next) =>
                      onUpdateWindowFormula({
                        ...windowFormula,
                        m24WidthDeduction4: next,
                      })
                  )}
                  {renderDimInputs(
                    '4-Palay D31 Interlock Height Deduction (H - x) [1 Pc]',
                    windowFormula.d31HeightDeduction4 || { inch: 2, sutar: 4 },
                    (next) =>
                      onUpdateWindowFormula({
                        ...windowFormula,
                        d31HeightDeduction4: next,
                      })
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M23 Height Pcs (4P)
                      </label>
                      <input
                        type="number"
                        value={windowFormula.m23Qty4}
                        onChange={(e) =>
                          onUpdateWindowFormula({
                            ...windowFormula,
                            m23Qty4: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M28 Height Pcs (4P)
                      </label>
                      <input
                        type="number"
                        value={windowFormula.m28Qty4}
                        onChange={(e) =>
                          onUpdateWindowFormula({
                            ...windowFormula,
                            m28Qty4: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Additional Section-Wise Height & Width Formula Boxes inside Sliding Windows */}
              {renderOpenableCategoryEditor(
                'window',
                'Sliding Window — Custom & Extra Section Height/Width Formula Boxes (1, 2, 3 Pcs...)',
                windowFormula.customSectionRules || { formulas: {}, acc: {} },
                (nextRules) =>
                  onUpdateWindowFormula({
                    ...windowFormula,
                    customSectionRules: nextRules,
                  }),
                ['DC30C', 'DC26C', 'D54A', 'D42', 'D41', 'D59']
              )}
            </div>
          )}

          {/* 2. SLIDING DOORS FORMULAS (WITH 2-PALAY, 3-PALAY, 4-PALAY & SECTION BOXES!) */}
          {formulaSubTab === 'SLIDING_DOOR' && (
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    Heavy Sliding Door (M30 / M26 & M30F / M26F) Cutting Formulas (2, 3, 4 Palay Unlocked)
                  </h3>
                  <p className="text-xs text-slate-400">
                    2-Palay, 3-Palay, aur 4-Palay ke tamam M23, M28, M24, D29 Jali, Push Handle, aur D31 formulas yahan se control karein.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {renderDimInputs(
                  '1. M23 & M28 Sash Height Deduction (H - x)',
                  slidingDoorFormula.m23HeightDeduction,
                  (next) =>
                    onUpdateSlidingDoorFormula({
                      ...slidingDoorFormula,
                      m23HeightDeduction: next,
                    })
                )}
                {renderDimInputs(
                  '2. D29 Jali Extra Width Addition (M24 + x)',
                  slidingDoorFormula.d29ExtraWidthAdd || { inch: 3, sutar: 2 },
                  (next) =>
                    onUpdateSlidingDoorFormula({
                      ...slidingDoorFormula,
                      d29ExtraWidthAdd: next,
                    })
                )}
                {renderDimInputs(
                  '3. Push Handle Deduction on D29 Jali',
                  slidingDoorFormula.d29PushHandleDeduction || { inch: 1, sutar: 2 },
                  (next) =>
                    onUpdateSlidingDoorFormula({
                      ...slidingDoorFormula,
                      d29PushHandleDeduction: next,
                    })
                )}
              </div>

              {/* 2-Palay / 3-Palay / 4-Palay M24 Width Deductions & Piece Counts for Sliding Doors (ALL 3 PALAY BOXES VISIBLE TOGETHER!) */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
                {/* 2-PALAY SLIDING DOOR FORMULA BOX */}
                <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-[#F5B738]/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#F5B738]">
                      2-Palay Sliding Door Formula Box
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">4 M24 Pcs</span>
                  </div>
                  {renderDimInputs(
                    '2-Palay M24 Width Deduction: (W - x) / 2 [4 Pcs]',
                    slidingDoorFormula.m24WidthDeduction,
                    (next) =>
                      onUpdateSlidingDoorFormula({
                        ...slidingDoorFormula,
                        m24WidthDeduction: next,
                      })
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M23 Height Pcs (2-Palay)
                      </label>
                      <input
                        type="number"
                        value={slidingDoorFormula.m23Qty}
                        onChange={(e) =>
                          onUpdateSlidingDoorFormula({
                            ...slidingDoorFormula,
                            m23Qty: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M28 Height Pcs (2-Palay)
                      </label>
                      <input
                        type="number"
                        value={slidingDoorFormula.m28Qty}
                        onChange={(e) =>
                          onUpdateSlidingDoorFormula({
                            ...slidingDoorFormula,
                            m28Qty: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* 3-PALAY SLIDING DOOR FORMULA BOX */}
                <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-sky-500/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-sky-400">
                      3-Palay Sliding Door Formula Box
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">2 Center + 4 Sides</span>
                  </div>
                  {renderDimInputs(
                    '3-Palay Center M24 Deduction: (W - x) / 2 [2 Pcs]',
                    slidingDoorFormula.m24WidthCenterDeduction3 || { inch: 0, sutar: 0 },
                    (next) =>
                      onUpdateSlidingDoorFormula({
                        ...slidingDoorFormula,
                        m24WidthCenterDeduction3: next,
                      })
                  )}
                  {renderDimInputs(
                    '3-Palay Sides M24 Deduction: (W - x) / 4 [4 Pcs]',
                    slidingDoorFormula.m24WidthSidesDeduction3 || { inch: 2, sutar: 0 },
                    (next) =>
                      onUpdateSlidingDoorFormula({
                        ...slidingDoorFormula,
                        m24WidthSidesDeduction3: next,
                      })
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M23 Height Pcs (3-Palay)
                      </label>
                      <input
                        type="number"
                        value={slidingDoorFormula.m23Qty3 ?? 2}
                        onChange={(e) =>
                          onUpdateSlidingDoorFormula({
                            ...slidingDoorFormula,
                            m23Qty3: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M28 Height Pcs (3-Palay)
                      </label>
                      <input
                        type="number"
                        value={slidingDoorFormula.m28Qty3 ?? 4}
                        onChange={(e) =>
                          onUpdateSlidingDoorFormula({
                            ...slidingDoorFormula,
                            m28Qty3: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* 4-PALAY SLIDING DOOR FORMULA BOX */}
                <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-emerald-500/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400">
                      4-Palay Sliding Door Formula Box
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">8 M24 + 1 D31</span>
                  </div>
                  {renderDimInputs(
                    '4-Palay M24 Width Deduction: (W - x) / 4 [8 Pcs]',
                    slidingDoorFormula.m24WidthDeduction4,
                    (next) =>
                      onUpdateSlidingDoorFormula({
                        ...slidingDoorFormula,
                        m24WidthDeduction4: next,
                      })
                  )}
                  {renderDimInputs(
                    '4-Palay D31 Interlock Height Deduction (H - x) [1 Pc]',
                    slidingDoorFormula.d31HeightDeduction4 || { inch: 2, sutar: 4 },
                    (next) =>
                      onUpdateSlidingDoorFormula({
                        ...slidingDoorFormula,
                        d31HeightDeduction4: next,
                      })
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M23 Height Pcs (4-Palay)
                      </label>
                      <input
                        type="number"
                        value={slidingDoorFormula.m23Qty4 ?? 4}
                        onChange={(e) =>
                          onUpdateSlidingDoorFormula({
                            ...slidingDoorFormula,
                            m23Qty4: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="p-2 rounded-lg bg-[#14181F] border border-slate-800">
                      <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                        M28 Height Pcs (4-Palay)
                      </label>
                      <input
                        type="number"
                        value={slidingDoorFormula.m28Qty4 ?? 4}
                        onChange={(e) =>
                          onUpdateSlidingDoorFormula({
                            ...slidingDoorFormula,
                            m28Qty4: parseInt(e.target.value, 10) || 0,
                          })
                        }
                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Additional Section-Wise Height & Width Formula Boxes inside Sliding Doors */}
              {renderOpenableCategoryEditor(
                'sliding_door',
                'Sliding Door — Custom & Extra Section Height/Width Formula Boxes (1, 2, 3 Pcs...)',
                slidingDoorFormula.customSectionRules || { formulas: {}, acc: {} },
                (nextRules) =>
                  onUpdateSlidingDoorFormula({
                    ...slidingDoorFormula,
                    customSectionRules: nextRules,
                  }),
                ['M30', 'M26', 'M30F', 'M26F', 'M24', 'M24A']
              )}
            </div>
          )}

          {/* 3, 4, 5. OPENABLE DOORS, FIX FRAMES, OPENABLE WINDOWS */}
          {formulaSubTab === 'DOOR' &&
            renderOpenableCategoryEditor(
              'door',
              'Openable Door Cutting Formulas (D54A, D50, D46, D52, D41, D59)',
              doorFormula,
              onUpdateDoorFormula
            )}
          {formulaSubTab === 'FIX' &&
            renderOpenableCategoryEditor(
              'fix',
              'Fix Frame Cutting Formulas (D54A, D42, D41, D59)',
              fixFormula,
              onUpdateFixFormula
            )}
          {formulaSubTab === 'OPENWIN' &&
            renderOpenableCategoryEditor(
              'openwin',
              'Openable Window Cutting Formulas (D54A, D50, D41, D59, D52)',
              openwinFormula,
              onUpdateOpenwinFormula
            )}

          {/* 6. F-SECTION FORMULA (WITH ON/OFF SWITCH) */}
          {formulaSubTab === 'FSECTION' && (
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    F-Section Cutting Formula (DC30F, DC26F, D54F, D51F, D42F, M30F)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Standard: Frame Size + 2" 3 sutar (+2.375") on both Height and Width.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs text-white font-semibold">
                  <span>F-Section Addition:</span>
                  {renderOnOffSwitch(fSectionFormula.enabled, (next) =>
                    onUpdateFSectionFormula({
                      ...fSectionFormula,
                      enabled: next,
                    })
                  )}
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {renderDimInputs(
                  'F-Section Height Addition (+ Inch & Sutar)',
                  fSectionFormula.heightDim,
                  (next) => onUpdateFSectionFormula({ ...fSectionFormula, heightDim: next })
                )}
                {renderDimInputs(
                  'F-Section Width Addition (+ Inch & Sutar)',
                  fSectionFormula.widthDim,
                  (next) => onUpdateFSectionFormula({ ...fSectionFormula, widthDim: next })
                )}
              </div>
            </div>
          )}

          {/* 7. GLASS CUTTING FORMULAS (SEPARATE DEDICATED CONTROLS FOR EACH CATEGORY) */}
          {formulaSubTab === 'GLASS' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
                    <span>🪟 Glass Cutting Margin Formulas (ہر کیٹیگری کا الگ الگ فارمولا)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Sliding Windows, Sliding Doors, Fix Windows, Openable Windows, aur Doors ke liye independent glass cutting margins.
                  </p>
                </div>
              </div>

              {/* 1. SLIDING WINDOWS GLASS FORMULA */}
              {(() => {
                const winGlass = glassFormulas['window'] || {
                  marginH: 1,
                  marginW: 1,
                  panels: 2,
                  marginHSutar: 0,
                  marginWSutar: 0,
                  slidingHeightDeductionInch: 5,
                  slidingHeightDeductionSutar: 5,
                  slidingWidthAddToM24Inch: 0,
                  slidingWidthAddToM24Sutar: 5,
                };
                return (
                  <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                        <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                          1. Sliding Window Glass Formula (سلائیڈنگ ونڈو)
                        </h4>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 font-mono border border-amber-500/30">
                        Category: window
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {renderDimInputs(
                        'Sliding Window Glass Height Deduction (H - x)',
                        {
                          inch: winGlass.slidingHeightDeductionInch ?? 5,
                          sutar: winGlass.slidingHeightDeductionSutar ?? 5,
                        },
                        (next) => {
                          onUpdateGlassFormula('window', {
                            ...winGlass,
                            slidingHeightDeductionInch: next.inch,
                            slidingHeightDeductionSutar: next.sutar,
                          });
                        }
                      )}
                      {renderDimInputs(
                        'Sliding Window Glass Width Addition (M24 + x)',
                        {
                          inch: winGlass.slidingWidthAddToM24Inch ?? 0,
                          sutar: winGlass.slidingWidthAddToM24Sutar ?? 5,
                        },
                        (next) => {
                          onUpdateGlassFormula('window', {
                            ...winGlass,
                            slidingWidthAddToM24Inch: next.inch,
                            slidingWidthAddToM24Sutar: next.sutar,
                          });
                        }
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* 2. SLIDING DOORS GLASS FORMULA */}
              {(() => {
                const sdoorGlass = glassFormulas['slidingdoor'] || {
                  marginH: 1,
                  marginW: 1,
                  panels: 2,
                  marginHSutar: 0,
                  marginWSutar: 0,
                  slidingHeightDeductionInch: 5,
                  slidingHeightDeductionSutar: 5,
                  slidingWidthAddToM24Inch: 0,
                  slidingWidthAddToM24Sutar: 5,
                };
                return (
                  <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                        <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider">
                          2. Sliding Door Glass Formula (سلائیڈنگ ڈور)
                        </h4>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 font-mono border border-cyan-500/30">
                        Category: slidingdoor
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {renderDimInputs(
                        'Sliding Door Glass Height Deduction (H - x)',
                        {
                          inch: sdoorGlass.slidingHeightDeductionInch ?? 5,
                          sutar: sdoorGlass.slidingHeightDeductionSutar ?? 5,
                        },
                        (next) => {
                          onUpdateGlassFormula('slidingdoor', {
                            ...sdoorGlass,
                            slidingHeightDeductionInch: next.inch,
                            slidingHeightDeductionSutar: next.sutar,
                          });
                        }
                      )}
                      {renderDimInputs(
                        'Sliding Door Glass Width Addition (M24 + x)',
                        {
                          inch: sdoorGlass.slidingWidthAddToM24Inch ?? 0,
                          sutar: sdoorGlass.slidingWidthAddToM24Sutar ?? 5,
                        },
                        (next) => {
                          onUpdateGlassFormula('slidingdoor', {
                            ...sdoorGlass,
                            slidingWidthAddToM24Inch: next.inch,
                            slidingWidthAddToM24Sutar: next.sutar,
                          });
                        }
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* 3. FIX WINDOWS & PARTITIONS GLASS FORMULA */}
              {(() => {
                const fixGlass = glassFormulas['fix'] || {
                  marginH: 1,
                  marginW: 1,
                  panels: 1,
                  marginHSutar: 0,
                  marginWSutar: 0,
                  slidingHeightDeductionInch: 1,
                  slidingHeightDeductionSutar: 0,
                  slidingWidthAddToM24Inch: 0,
                  slidingWidthAddToM24Sutar: 0,
                };
                return (
                  <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                        <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                          3. Fix Frame & Partitions Glass Formula (فکس فریم / گلاس پارٹیشن)
                        </h4>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 font-mono border border-emerald-500/30">
                        Category: fix
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {renderDimInputs(
                        'Fix Frame Glass Height Deduction (H - x)',
                        {
                          inch: fixGlass.marginH ?? 1,
                          sutar: fixGlass.marginHSutar ?? 0,
                        },
                        (next) => {
                          onUpdateGlassFormula('fix', {
                            ...fixGlass,
                            marginH: next.inch,
                            marginHSutar: next.sutar,
                          });
                        }
                      )}
                      {renderDimInputs(
                        'Fix Frame Glass Width Deduction (W - x)',
                        {
                          inch: fixGlass.marginW ?? 1,
                          sutar: fixGlass.marginWSutar ?? 0,
                        },
                        (next) => {
                          onUpdateGlassFormula('fix', {
                            ...fixGlass,
                            marginW: next.inch,
                            marginWSutar: next.sutar,
                          });
                        }
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* 4. OPENABLE WINDOWS GLASS FORMULA */}
              {(() => {
                const openwinGlass = glassFormulas['openwin'] || {
                  marginH: 1,
                  marginW: 1,
                  panels: 1,
                  marginHSutar: 0,
                  marginWSutar: 0,
                  slidingHeightDeductionInch: 1,
                  slidingHeightDeductionSutar: 0,
                  slidingWidthAddToM24Inch: 0,
                  slidingWidthAddToM24Sutar: 0,
                };
                return (
                  <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-violet-400"></span>
                        <h4 className="text-xs font-bold text-violet-300 uppercase tracking-wider">
                          4. Openable Window Glass Formula (اوپنیبل کھڑکی)
                        </h4>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-violet-500/10 text-violet-300 font-mono border border-violet-500/30">
                        Category: openwin
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {renderDimInputs(
                        'Openable Window Glass Height Deduction (H - x)',
                        {
                          inch: openwinGlass.marginH ?? 1,
                          sutar: openwinGlass.marginHSutar ?? 0,
                        },
                        (next) => {
                          onUpdateGlassFormula('openwin', {
                            ...openwinGlass,
                            marginH: next.inch,
                            marginHSutar: next.sutar,
                          });
                        }
                      )}
                      {renderDimInputs(
                        'Openable Window Glass Width Deduction (W - x)',
                        {
                          inch: openwinGlass.marginW ?? 1,
                          sutar: openwinGlass.marginWSutar ?? 0,
                        },
                        (next) => {
                          onUpdateGlassFormula('openwin', {
                            ...openwinGlass,
                            marginW: next.inch,
                            marginWSutar: next.sutar,
                          });
                        }
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* 5. OPENABLE / SWING DOORS GLASS FORMULA */}
              {(() => {
                const doorGlass = glassFormulas['door'] || {
                  marginH: 1,
                  marginW: 1,
                  panels: 1,
                  marginHSutar: 0,
                  marginWSutar: 0,
                  slidingHeightDeductionInch: 1,
                  slidingHeightDeductionSutar: 0,
                  slidingWidthAddToM24Inch: 0,
                  slidingWidthAddToM24Sutar: 0,
                };
                return (
                  <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-400"></span>
                        <h4 className="text-xs font-bold text-rose-300 uppercase tracking-wider">
                          5. Openable Door & Frame Glass Formula (اوپنیبل ڈور / چوکاٹ)
                        </h4>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 font-mono border border-rose-500/30">
                        Category: door
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {renderDimInputs(
                        'Door Glass Height Deduction (H - x)',
                        {
                          inch: doorGlass.marginH ?? 1,
                          sutar: doorGlass.marginHSutar ?? 0,
                        },
                        (next) => {
                          onUpdateGlassFormula('door', {
                            ...doorGlass,
                            marginH: next.inch,
                            marginHSutar: next.sutar,
                          });
                        }
                      )}
                      {renderDimInputs(
                        'Door Glass Width Deduction (W - x)',
                        {
                          inch: doorGlass.marginW ?? 1,
                          sutar: doorGlass.marginWSutar ?? 0,
                        },
                        (next) => {
                          onUpdateGlassFormula('door', {
                            ...doorGlass,
                            marginW: next.inch,
                            marginWSutar: next.sutar,
                          });
                        }
                      )}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* 8. DRAG-DROP SETUP AUTO-CONNECTED FORMULAS */}
          {formulaSubTab === 'DYNAMIC' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#14181F] border border-[#F5B738]/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-[#F5B738]">
                      Auto-Connected Drag & Drop Setups Formulas ({blueprints.length})
                    </h3>
                    <p className="text-xs text-slate-400">
                      Jo bhi Window ya Door aap Drag & Drop Studio mein banatay hain, us ka Formula Section yahan khud-ba-khud add ho jata hai.
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  {blueprints.map((bp) => (
                    <div
                      key={bp.id}
                      className="p-3.5 rounded-xl bg-[#0C0F14] border border-slate-800 space-y-2.5"
                    >
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <span className="text-xs font-bold text-white">
                          {bp.name} ({bp.category} · {bp.panelCount} Palay)
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono text-emerald-400">
                            Auto-Connected to Cutting, Length & Quotation
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              onUpdateBlueprints(blueprints.filter((b) => b.id !== bp.id));
                            }}
                            className="p-1 px-2.5 rounded-lg bg-red-950/60 hover:bg-red-900 border border-red-500/40 text-red-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-sm"
                            title="Delete this custom setup"
                          >
                            <Trash2 className="w-3 h-3 text-red-400" />
                            <span>Delete Setup</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                        {bp.items
                          .filter((it) => it.applyTo !== 'UI')
                          .map((it) => {
                            const itemKey = `${bp.id}-${it.id}`;
                            const isManual = !!customSecInputMode[itemKey];

                            return (
                              <div
                                key={it.id}
                                className="p-2.5 rounded-lg bg-[#14181F] border border-slate-800 space-y-1.5 text-xs"
                              >
                                <div className="font-semibold text-amber-300">{it.label}</div>
                                <div className="grid grid-cols-3 gap-1.5">
                                  <div>
                                    <div className="flex items-center justify-between mb-0.5">
                                      <label className="block text-[10px] text-slate-400">Section</label>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setCustomSecInputMode((prev) => ({
                                            ...prev,
                                            [itemKey]: !isManual,
                                          }))
                                        }
                                        className="text-[9px] text-amber-400 hover:text-amber-300 font-mono underline cursor-pointer"
                                        title={isManual ? 'Switch to Rate List Dropdown' : 'Type Custom Section Code'}
                                      >
                                        {isManual ? 'List' : 'Type'}
                                      </button>
                                    </div>

                                    {isManual ? (
                                      <div className="flex items-center gap-1">
                                        <input
                                          type="text"
                                          autoFocus
                                          value={it.sectionCode}
                                          onChange={(e) => {
                                            const nextSec = e.target.value.toUpperCase();
                                            onUpdateBlueprints(
                                              blueprints.map((b) =>
                                                b.id === bp.id
                                                  ? {
                                                      ...b,
                                                      items: b.items.map((item) =>
                                                        item.id === it.id
                                                          ? { ...item, sectionCode: nextSec }
                                                          : item
                                                      ),
                                                    }
                                                  : b
                                              )
                                            );
                                          }}
                                          placeholder="e.g. D50A, CW-10"
                                          className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-[#F5B738] font-mono text-amber-300 text-xs font-bold focus:outline-none"
                                        />
                                        <button
                                          type="button"
                                          onClick={() =>
                                            setCustomSecInputMode((prev) => ({ ...prev, [itemKey]: false }))
                                          }
                                          className="px-1.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 text-[10px] font-bold cursor-pointer shrink-0"
                                          title="Done"
                                        >
                                          ✓
                                        </button>
                                      </div>
                                    ) : (
                                      <select
                                        value={it.sectionCode}
                                        onChange={(e) => {
                                          const val = e.target.value;
                                          if (val === '__ENTER_CUSTOM__') {
                                            setCustomSecInputMode((prev) => ({ ...prev, [itemKey]: true }));
                                            return;
                                          }
                                          onUpdateBlueprints(
                                            blueprints.map((b) =>
                                              b.id === bp.id
                                                ? {
                                                    ...b,
                                                    items: b.items.map((item) =>
                                                      item.id === it.id
                                                        ? { ...item, sectionCode: val }
                                                        : item
                                                    ),
                                                  }
                                                : b
                                            )
                                          );
                                        }}
                                        className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-amber-500/70 font-mono text-amber-300 text-xs font-bold cursor-pointer focus:outline-none focus:border-amber-400"
                                      >
                                        {!allRateListSections.includes(it.sectionCode) && it.sectionCode && (
                                          <option value={it.sectionCode} className="bg-[#14181F] text-amber-300 font-bold">
                                            {it.sectionCode} (Current)
                                          </option>
                                        )}
                                        <optgroup label="All Rate List Sections">
                                          {allRateListSections.map((sec) => (
                                            <option key={sec} value={sec} className="bg-[#14181F] text-white">
                                              {sec} {SECTION_LABELS[sec] ? `· ${SECTION_LABELS[sec]}` : ''}
                                            </option>
                                          ))}
                                        </optgroup>
                                        <option value="__ENTER_CUSTOM__" className="bg-[#1C222B] text-amber-400 font-bold">
                                          ✍️ + Enter Custom Section...
                                        </option>
                                      </select>
                                    )}
                                  </div>
                                  <div>
                                    <label className="block text-[10px] text-slate-400">Formula</label>
                                    <input
                                      type="text"
                                      value={it.formulaExpression}
                                      onChange={(e) => {
                                        const nextForm = e.target.value;
                                        onUpdateBlueprints(
                                          blueprints.map((b) =>
                                            b.id === bp.id
                                              ? {
                                                  ...b,
                                                  items: b.items.map((item) =>
                                                    item.id === it.id
                                                      ? { ...item, formulaExpression: nextForm }
                                                      : item
                                                  ),
                                                }
                                              : b
                                          )
                                        );
                                      }}
                                      className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 font-mono text-emerald-300 text-xs"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] text-slate-400">Pieces</label>
                                    <input
                                      type="text"
                                      value={it.qtyFormula}
                                      onChange={(e) => {
                                        const nextQty = e.target.value;
                                        onUpdateBlueprints(
                                          blueprints.map((b) =>
                                            b.id === bp.id
                                              ? {
                                                  ...b,
                                                  items: b.items.map((item) =>
                                                    item.id === it.id
                                                      ? { ...item, qtyFormula: nextQty }
                                                      : item
                                                  ),
                                                }
                                              : b
                                          )
                                        );
                                      }}
                                      className="w-full px-2 py-1 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white text-xs"
                                    />
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {dynamicSections.length > 0 && (
                <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    Saved Custom Section Profiles ({dynamicSections.length})
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {dynamicSections.map((sec) => (
                      <div
                        key={sec.id}
                        className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-[#F5B738]">
                            {sec.code} — {sec.title} ({sec.category})
                          </div>
                          <div className="font-mono text-[11px] text-slate-300">
                            H: {sec.heightFormula} | 2P: {sec.widthFormula2Panel}
                          </div>
                        </div>
                        <button
                          onClick={() => onDeleteDynamicSection(sec.id)}
                          className="p-1.5 rounded text-rose-400 hover:bg-rose-950"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* SUB-TAB 1: INDUSTRIAL AI RATE LIST SCANNER (MULTI-PHOTO + CLEAR)    */}
      {/* =================================================================== */}
      {selectedSubTab === 1 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          <div className="lg:col-span-5 p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#F5B738]" />
                <h3 className="text-sm font-bold text-white">
                  Multi-Page AI Rate List Scanner (3, 4+ Photos at Once)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSavedRatesModal(true)}
                className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-[#F5B738] hover:from-amber-400 hover:to-amber-500 text-black text-xs font-black flex items-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <Table className="w-3.5 h-3.5" />
                <span>📋 Open Saved Rate List Window</span>
              </button>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Aap aik sath <strong>3, 4 ya zyada Rate List Photos / PDFs</strong> akathay select kar ke scan kar saktay hain. System tamam pages ko aik sath read kar ke 5-column dataset banaye ga!
            </p>

            {/* Clear All Rate List Data & Restore Defaults Bar */}
            <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/40 flex flex-wrap items-center justify-between gap-2">
              <div className="text-[11px] text-rose-200">
                <strong>Database Rate Control:</strong> Purani rate list saaf (0) karni ho:
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All Rate List Data</span>
                </button>
                <button
                  onClick={() => {
                    onRestoreDefaultRates();
                    showNotice('Factory default rates restored!');
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-[#1C222B] border border-slate-700 text-slate-200 hover:border-amber-400 text-[11px] font-semibold"
                >
                  Restore Defaults
                </button>
              </div>
            </div>

            {showClearConfirm && (
              <div className="p-3.5 rounded-xl bg-rose-950 border-2 border-rose-500 space-y-2.5 text-xs">
                <div className="font-bold text-white">
                  Confirm: Kya aap waqai Rate List ka sara data Clear (0) karna chahtay hain?
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onClearAllRates();
                      setScannedRows([]);
                      setFiveColumnOutput('');
                      setShowClearConfirm(false);
                      showNotice('All Rate List prices cleared to 0!');
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
                  >
                    Yes, Clear All Rates Now
                  </button>
                  <button
                    onClick={() => setShowClearConfirm(false)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-200"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <div className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-amber-300">
                  1. Select Multiple Photos / Screenshots / PDFs (3, 4+ Ek Sath)
                </label>
                {scanFiles.length > 0 && (
                  <button
                    onClick={() => setScanFiles([])}
                    className="text-[11px] text-rose-400 hover:underline"
                  >
                    Clear Selected ({scanFiles.length})
                  </button>
                )}
              </div>
              <input
                type="file"
                multiple
                accept="image/*,application/pdf"
                onChange={handleFileSelectForRateScan}
                className="w-full text-xs text-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-[#F5B738] file:text-black hover:file:bg-amber-400 cursor-pointer"
              />

              {scanFiles.length > 0 && (
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {scanFiles.map((f, idx) => (
                    <div
                      key={idx}
                      className="p-1.5 rounded-lg bg-[#14181F] border border-slate-700 relative group"
                    >
                      {f.previewUrl ? (
                        <img
                          src={f.previewUrl}
                          alt={f.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-16 object-cover rounded"
                        />
                      ) : (
                        <div className="w-full h-16 rounded bg-slate-900 flex items-center justify-center text-[10px] font-mono text-amber-300">
                          PDF Page
                        </div>
                      )}
                      <div className="text-[10px] text-slate-300 truncate mt-1">
                        {idx + 1}. {f.name}
                      </div>
                      <button
                        onClick={() => setScanFiles(scanFiles.filter((_, i) => i !== idx))}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-300">
                  2. Or Paste Raw Rate List Text / Sample Sheet
                </label>
                <button
                  onClick={() =>
                    setRawRateText(
                      `SLIDING WINDOWS SECTIONS\nDC30C 1.6mm | DULL 815 | H23 / PC-RAL 855 | SAHARA / BROWN 875\nDC26C 1.6mm | DULL 955 | BLACK / MULTI 1065\nM23 Normal | DULL 352 | WOOD COAT 440\nM24 (1.6mm) | DULL 495 | SAHARA / BROWN 530\nKT.1 | DULL 420 | H23 / PC-RAL 445\nCW-10 1.2mm mh | DULL 780 | ANODIZED 825`
                    )
                  }
                  className="text-[11px] text-[#F5B738] hover:underline font-semibold"
                >
                  Load Test Sample Sheet
                </button>
              </div>
              <textarea
                rows={5}
                value={rawRateText}
                onChange={(e) => setRawRateText(e.target.value)}
                placeholder="Paste raw OCR text, WhatsApp rate list, or 5-column lines here..."
                className="w-full p-2.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white focus:border-[#F5B738] focus:outline-none"
              />
            </div>

            <button
              onClick={handleRunIndustrialRateScan}
              disabled={isScanningRates}
              className="w-full py-2.5 rounded-lg bg-[#F5B738] text-black text-xs font-bold hover:bg-amber-400 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>
                {isScanningRates
                  ? 'Scanning & Mapping to Master Lists...'
                  : 'Scan & Extract 5-Column Rate Dataset'}
              </span>
            </button>

            {scanError && (
              <div className="p-3 rounded-lg bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs">
                {scanError}
              </div>
            )}
          </div>

          <div className="lg:col-span-7 p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-[#F5B738]">
                  Extracted 5-Column Dataset ({scannedRows.length} Records)
                </h3>
                <p className="text-[11px] text-slate-400 font-mono">
                  Format: [Section Title] | [Section Code] | [Gauge] | [Color] | [Rate]
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setShowSavedRatesModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/40 text-xs text-amber-300 hover:bg-amber-500 hover:text-black flex items-center gap-1.5 cursor-pointer font-bold"
                >
                  <Table className="w-3.5 h-3.5 text-[#F5B738]" />
                  <span>View Saved Rates</span>
                </button>

                {scannedRows.length > 0 && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(fiveColumnOutput);
                        showNotice('Copied pure 5-column dataset to clipboard!');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-slate-700 text-xs text-slate-200 hover:border-[#F5B738] flex items-center gap-1.5"
                    >
                      <Copy className="w-3.5 h-3.5 text-[#F5B738]" />
                      <span>Copy 5-Col Text</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const res = onUpsertScannedRates(scannedRows);
                        showNotice(
                          `Intelligent Upsert Complete: ${res.updated} existing rates UPDATED, ${res.inserted} new records INSERTED (0 deleted)!`
                        );
                      }}
                      className="px-3.5 py-1.5 rounded-lg bg-emerald-500 text-black text-xs font-bold hover:bg-emerald-400 flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Upsert to Database & Supabase</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {scannedRows.length === 0 ? (
              <div className="py-16 text-center border border-dashed border-slate-800 rounded-xl text-xs text-slate-500">
                Upload a rate list photo/PDF or click "Load Test Sample Sheet" → "Scan & Extract" to preview the 5-column dataset.
              </div>
            ) : (
              <>
                <div className="border border-slate-800 rounded-xl overflow-hidden max-h-[360px] overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#1C222B] text-slate-300 sticky top-0">
                      <tr>
                        <th className="py-2 px-3">Section Title (Category)</th>
                        <th className="py-2 px-3">Code</th>
                        <th className="py-2 px-3">Gauge</th>
                        <th className="py-2 px-3">Color</th>
                        <th className="py-2 px-3 text-right">Rate</th>
                        <th className="py-2 px-3 text-right">Upsert Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 font-mono text-[11px]">
                      {scannedRows.map((row, idx) => {
                        const cleanG = row.gauge.replace(/mm/i, '').trim() || '1.2';
                        const exists =
                          rates[cleanG]?.[row.color]?.[row.sectionCode] !== undefined;
                        return (
                          <tr key={idx} className="hover:bg-slate-900/50">
                            <td className="py-1.5 px-3 font-sans text-slate-300 truncate max-w-[180px]">
                              {row.sectionTitle}
                            </td>
                            <td className="py-1.5 px-3 font-bold text-[#F5B738]">
                              {row.sectionCode}
                            </td>
                            <td className="py-1.5 px-3 text-sky-300">{row.gauge}</td>
                            <td className="py-1.5 px-3 text-slate-200">{row.color}</td>
                            <td className="py-1.5 px-3 text-right font-bold text-emerald-400 tabular-nums">
                              {row.rate}
                            </td>
                            <td className="py-1.5 px-3 text-right">
                              <span
                                className={`text-[10px] font-bold ${
                                  exists ? 'text-amber-300' : 'text-emerald-400'
                                }`}
                              >
                                {exists ? 'UPDATE RATE' : 'INSERT NEW'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Pure 5-Column Pipe-Separated Output:
                  </label>
                  <pre className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 text-[11px] font-mono text-amber-200 overflow-x-auto max-h-40">
                    {fiveColumnOutput}
                  </pre>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* SAVED ACTIVE RATE LIST DATABASE MODAL WINDOW (Per user prompt request: "ak cheez or add karo k ak or window ani chaeya jis ma save rate list sari show ho jay") */}
      {showSavedRatesModal && (() => {
        const allKnownSections = Array.from(
          new Set([
            ...DEFAULT_SECTIONS,
            ...customSections,
            ...Object.keys(rates?.[savedRatesGauge]?.[savedRatesColor] || {}),
          ])
        ).filter(Boolean).sort();

        const savedSectionRows = allKnownSections
          .filter((sec) => {
            if (!savedRatesSearch.trim()) return true;
            return sec.toLowerCase().includes(savedRatesSearch.toLowerCase());
          })
          .map((sec) => ({
            code: sec,
            rate: rates?.[savedRatesGauge]?.[savedRatesColor]?.[sec] || 0,
          }));

        return (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-4xl bg-[#0F141C] border-2 border-amber-500/60 rounded-2xl p-5 text-white space-y-4 max-h-[90vh] flex flex-col shadow-2xl">
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-slate-700 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-amber-500/10 border border-[#F5B738] text-[#F5B738]">
                    <Table className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-[#F5B738] flex items-center gap-2">
                      <span>Saved Master Rate List Database Window</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                        LIVE SAVED RATES
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Aap ki tamam save shuda Aluminium Sections aur un ke active Rs./ft rates (Gauge & Finish wise)
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSavedRatesModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Filter Bar: Gauge, Color, and Search Section */}
              <div className="p-3 rounded-xl bg-[#141A24] border border-slate-800 space-y-3 text-xs">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  {/* Gauge Selection */}
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 font-semibold text-[11px] uppercase">Select Gauge:</span>
                    <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                      {GAUGES.map((g) => (
                        <button
                          key={g}
                          onClick={() => setSavedRatesGauge(g)}
                          className={`px-2.5 py-1 rounded-lg font-mono font-bold text-xs transition-colors cursor-pointer ${
                            savedRatesGauge === g
                              ? 'bg-[#F5B738] text-black shadow'
                              : 'bg-[#1C2534] text-slate-300 hover:text-white'
                          }`}
                        >
                          {g}mm
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Selection */}
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 font-semibold text-[11px] uppercase">Finish / Color:</span>
                    <select
                      value={savedRatesColor}
                      onChange={(e) => setSavedRatesColor(e.target.value)}
                      className="px-2.5 py-1 rounded-lg bg-[#0C1017] border border-slate-700 text-amber-300 font-bold outline-none cursor-pointer"
                    >
                      {Array.from(new Set(['DULL', 'CHAMPAGNE', 'BRONZE', 'BLACK', 'WHITE', 'GOLDEN', 'WOOD COAT', ...availableColors])).map(
                        (c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        )
                      )}
                    </select>
                  </div>
                </div>

                {/* Search Section Input */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={savedRatesSearch}
                    onChange={(e) => setSavedRatesSearch(e.target.value)}
                    placeholder="Search section code in saved list (DC30C, M24, D50A, D54A, CW-10...)"
                    className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-[#0C1017] border border-slate-700 text-xs text-white placeholder-slate-500 outline-none focus:border-[#F5B738]"
                  />
                </div>
              </div>

              {/* Saved Rates Table */}
              <div className="flex-1 overflow-y-auto rounded-xl border border-slate-800 bg-[#0C1017] custom-scrollbar max-h-[420px]">
                <table className="w-full text-xs text-left">
                  <thead className="bg-[#141A24] text-slate-400 uppercase font-semibold sticky top-0 border-b border-slate-800 z-10">
                    <tr>
                      <th className="p-2.5 pl-3">#</th>
                      <th className="p-2.5">Section Code</th>
                      <th className="p-2.5">Gauge</th>
                      <th className="p-2.5">Color / Finish</th>
                      <th className="p-2.5 text-right pr-4">Saved Rate (Rs. / ft)</th>
                      <th className="p-2.5 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-mono">
                    {savedSectionRows.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-slate-500 font-sans">
                          No sections found for {savedRatesGauge}mm · {savedRatesColor}.
                        </td>
                      </tr>
                    ) : (
                      savedSectionRows.map((row, rIdx) => (
                        <tr key={row.code} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-2.5 pl-3 text-slate-500">{rIdx + 1}</td>
                          <td className="p-2.5 font-bold text-white font-sans">{row.code}</td>
                          <td className="p-2.5 text-amber-300">{savedRatesGauge}mm</td>
                          <td className="p-2.5 text-slate-300">{savedRatesColor}</td>
                          <td className="p-2.5 text-right pr-4">
                            <span
                              className={`font-black ${
                                row.rate > 0 ? 'text-emerald-400 text-sm' : 'text-slate-600'
                              }`}
                            >
                              Rs. {row.rate > 0 ? row.rate.toLocaleString() : '0 (Not Set)'}
                            </span>
                          </td>
                          <td className="p-2.5 text-center">
                            {row.rate > 0 ? (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                                Saved ✓
                              </span>
                            ) : (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-500">
                                Zero
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Modal Bottom Actions */}
              <div className="flex items-center justify-between border-t border-slate-800 pt-3 flex-wrap gap-2 text-xs">
                <span className="text-slate-400 font-mono">
                  Total Sections Displayed: <strong className="text-amber-300">{savedSectionRows.length}</strong>
                </span>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const textLines = savedSectionRows
                        .map((r) => `${r.code} | ${savedRatesGauge}mm | ${savedRatesColor} | Rs. ${r.rate}`)
                        .join('\n');
                      navigator.clipboard.writeText(textLines);
                      showNotice('Copied saved rate list to clipboard!');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy List Text</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowSavedRatesModal(false)}
                    className="px-4 py-1.5 rounded-lg bg-amber-500 text-black font-bold hover:bg-amber-400 cursor-pointer"
                  >
                    Close Window
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* =================================================================== */}
      {/* SUB-TAB 3: SUB-ADMINS & ALL PERMISSIONS (WITH ON/OFF SWITCHES!)     */}
      {/* =================================================================== */}
      {selectedSubTab === 3 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          {/* Left 6 Cols: Create Sub-Admin with All 16 Permissions + Custom Permissions (All ON/OFF Switches!) */}
          <div className="lg:col-span-6 p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#F5B738]">
                  Create Sub-Admin & Delegate Permissions (ON / OFF Switches)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Tamam 16 permissions + custom permissions ke liye Checkboxes hata kar ON/OFF Switches laga diye gaye hain.
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    const allOn: any = { ...draftPermissions };
                    ALL_PERMISSION_DEFINITIONS.forEach((d) => {
                      allOn[d.key] = true;
                    });
                    setDraftPermissions(allOn);
                  }}
                  className="px-2.5 py-1 rounded bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 font-bold text-[10px]"
                >
                  All ON
                </button>
                <button
                  onClick={() => {
                    const allOff: any = { ...draftPermissions };
                    ALL_PERMISSION_DEFINITIONS.forEach((d) => {
                      allOff[d.key] = false;
                    });
                    setDraftPermissions(allOff);
                  }}
                  className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-bold text-[10px]"
                >
                  All OFF
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <input
                type="text"
                value={adminName}
                onChange={(e) => setAdminName(e.target.value)}
                placeholder="Sub-Admin Full Name *"
                className="px-3 py-2 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
              />
              <input
                type="email"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="Sub-Admin Email *"
                className="px-3 py-2 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
              />
              <input
                type="text"
                value={adminPhone}
                onChange={(e) => setAdminPhone(e.target.value)}
                placeholder="Sub-Admin Mobile Number"
                className="px-3 py-2 rounded-lg bg-[#0C0F14] border border-slate-700 font-mono text-white"
              />
              <input
                type="text"
                value={adminPass}
                onChange={(e) => setAdminPass(e.target.value)}
                placeholder="Access Passcode / PIN (e.g. 4455)"
                className="px-3 py-2 rounded-lg bg-[#0C0F14] border border-slate-700 font-mono text-amber-300"
              />
            </div>

            {/* All 16 Permissions with ON/OFF Toggle Switches */}
            <div className="space-y-2 pt-1 max-h-[420px] overflow-y-auto">
              {ALL_PERMISSION_DEFINITIONS.map((perm) => {
                const isOn = Boolean(draftPermissions[perm.key]);
                return (
                  <div
                    key={perm.key}
                    className="flex items-center justify-between gap-3 p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800"
                  >
                    <div>
                      <div className="font-bold text-white">{perm.title}</div>
                      <div className="text-[10px] text-slate-400">{perm.desc}</div>
                    </div>
                    {renderOnOffSwitch(isOn, (next) =>
                      setDraftPermissions({
                        ...draftPermissions,
                        [perm.key]: next,
                      })
                    )}
                  </div>
                );
              })}

              {/* Custom Permissions Adder with ON/OFF Switch */}
              {Object.entries(draftPermissions.customPermissions || {}).map(([cKey, cVal]) => (
                <div
                  key={cKey}
                  className="flex items-center justify-between gap-3 p-2.5 rounded-lg bg-[#0C0F14] border border-[#F5B738]/50"
                >
                  <div>
                    <div className="font-bold text-[#F5B738]">Custom: {cKey}</div>
                    <div className="text-[10px] text-slate-400">Custom delegated permission</div>
                  </div>
                  <div className="flex items-center gap-2">
                    {renderOnOffSwitch(cVal, (next) =>
                      setDraftPermissions({
                        ...draftPermissions,
                        customPermissions: {
                          ...draftPermissions.customPermissions,
                          [cKey]: next,
                        },
                      })
                    )}
                    <button
                      onClick={() => {
                        const nextCustom = { ...draftPermissions.customPermissions };
                        delete nextCustom[cKey];
                        setDraftPermissions({
                          ...draftPermissions,
                          customPermissions: nextCustom,
                        });
                      }}
                      className="text-rose-400"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Custom Permission Row */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newCustomPermName}
                onChange={(e) => setNewCustomPermName(e.target.value)}
                placeholder="+ Add Any Extra Custom Permission Name..."
                className="flex-1 px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
              />
              <button
                onClick={() => {
                  const clean = newCustomPermName.trim();
                  if (!clean) return;
                  setDraftPermissions({
                    ...draftPermissions,
                    customPermissions: {
                      ...draftPermissions.customPermissions,
                      [clean]: true,
                    },
                  });
                  setNewCustomPermName('');
                }}
                className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-[#F5B738] text-[#F5B738] font-bold"
              >
                + Add Switch
              </button>
            </div>

            <button
              onClick={() => {
                if (!adminName.trim() || !adminEmail.trim()) {
                  showNotice('Please enter Sub-Admin Name and Email');
                  return;
                }
                onSaveSubAdmin({
                  id: `sub-${Date.now()}`,
                  name: adminName.trim(),
                  email: adminEmail.trim(),
                  phone: adminPhone.trim(),
                  passwordHash: adminPass.trim() || '1234',
                  createdAt: Date.now(),
                  isActive: true,
                  permissions: { ...draftPermissions },
                });
                setAdminName('');
                setAdminEmail('');
                setAdminPhone('');
                setAdminPass('');
                showNotice(`Sub-Admin "${adminName.trim()}" saved with ON/OFF switches!`);
              }}
              className="w-full py-2.5 rounded-lg bg-[#F5B738] text-black font-bold hover:bg-amber-400 transition-colors"
            >
              Save Sub-Admin Account & Permissions
            </button>
          </div>

          {/* Right 6 Cols: Active Sub-Admins with Live Interactive ON/OFF Switches */}
          <div className="lg:col-span-6 p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
            <h3 className="text-sm font-bold text-white">
              Active Sub-Admins & Live Permission Switches ({subAdmins.length})
            </h3>
            {subAdmins.length === 0 ? (
              <div className="text-xs text-slate-400 py-8 text-center">
                No Sub-Admins delegated yet. Only Master Owner (Syed Saboor Nawab) has full control. Create a Sub-Admin on the left to manage their live ON/OFF permission switches!
              </div>
            ) : (
              <div className="space-y-3">
                {subAdmins.map((adm) => (
                  <div
                    key={adm.id}
                    className="p-3.5 rounded-xl bg-[#0C0F14] border border-slate-800 space-y-3 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-bold text-[#F5B738] text-sm">
                          {adm.name} ({adm.email})
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          Phone: {adm.phone || 'N/A'} · PIN: {adm.passwordHash}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {renderOnOffSwitch(
                          adm.isActive,
                          (next) =>
                            onUpdateSubAdmins(
                              subAdmins.map((s) =>
                                s.id === adm.id ? { ...s, isActive: next } : s
                              )
                            ),
                          'ACTIVE',
                          'LOCKED'
                        )}
                        <button
                          onClick={() => onDeleteSubAdmin(adm.id)}
                          className="p-1.5 rounded bg-rose-950 text-rose-400 hover:text-rose-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1 border-t border-slate-800/80">
                      {ALL_PERMISSION_DEFINITIONS.map((perm) => {
                        const isOn = Boolean(adm.permissions[perm.key]);
                        return (
                          <div
                            key={perm.key}
                            className="p-2 rounded bg-[#14181F] border border-slate-800 flex items-center justify-between gap-2"
                          >
                            <span className="text-[11px] text-slate-200 truncate">
                              {perm.title}
                            </span>
                            {renderOnOffSwitch(isOn, (next) =>
                              onUpdateSubAdmins(
                                subAdmins.map((s) =>
                                  s.id === adm.id
                                    ? {
                                        ...s,
                                        permissions: {
                                          ...s.permissions,
                                          [perm.key]: next,
                                        },
                                      }
                                    : s
                                )
                              )
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* SUB-TAB 4: BROADCAST OFFERS & ANNOUNCEMENT BANNERS                  */}
      {/* =================================================================== */}
      {selectedSubTab === 4 && (
        <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] max-w-2xl space-y-3 text-xs">
          <h3 className="text-sm font-bold text-[#F5B738]">
            Live Broadcast Offer / Rate Update Notice Banner
          </h3>
          <p className="text-slate-400">
            Jo announcement aap yahan publish karein gay, woh tamam Client Apps ke top par live show ho gi.
          </p>
          <input
            type="text"
            value={offerBadge}
            onChange={(e) => setOfferBadge(e.target.value)}
            placeholder="Badge Text (e.g. Rate Update Notice / Special Offer)"
            className="w-full px-3 py-2 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
          />
          <input
            type="text"
            value={offerTitle}
            onChange={(e) => setOfferTitle(e.target.value)}
            placeholder="Announcement Title"
            className="w-full px-3 py-2 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
          />
          <textarea
            rows={3}
            value={offerMsg}
            onChange={(e) => setOfferMsg(e.target.value)}
            placeholder="Announcement Message for all Fabricators / Clients..."
            className="w-full p-3 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
          />
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (!offerTitle.trim()) return;
                onSaveOffer({
                  id: `offer-${Date.now()}`,
                  title: offerTitle.trim(),
                  message: offerMsg.trim(),
                  badgeText: offerBadge.trim() || 'Notice',
                  isActive: true,
                  createdAt: Date.now(),
                  createdBy: 'Syed Saboor Nawab',
                });
                showNotice('Broadcast Banner saved & published!');
              }}
              className="px-4 py-2 rounded-lg bg-emerald-500 text-black font-bold"
            >
              Publish Banner to All Clients
            </button>
            {activeOffer && (
              <button
                onClick={() => {
                  onSaveOffer(null);
                  setOfferTitle('');
                  setOfferMsg('');
                  showNotice('Broadcast Banner removed');
                }}
                className="px-4 py-2 rounded-lg bg-rose-600 text-white font-bold"
              >
                Remove Active Banner
              </button>
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* SUB-TAB 5: SUPABASE CLOUD, SECURITY AUDIT & CLIENT GEMINI COMMAND   */}
      {/* =================================================================== */}
      {selectedSubTab === 5 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          <div className="lg:col-span-6 space-y-4">
            <div className="p-4 rounded-xl bg-[#14181F] border border-emerald-500/50 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white">
                    Supabase Enterprise Cloud Connection (Free Tier Active)
                  </h3>
                </div>
                <span className="text-[11px] font-mono text-emerald-400">PostgREST v1</span>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Supabase Project URL
                </label>
                <input
                  type="text"
                  value={supabaseUrl}
                  onChange={(e) => setSupabaseUrl(e.target.value)}
                  className="w-full px-3 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-amber-300"
                />
              </div>

              <div className="p-2.5 rounded bg-[#0C0F14] border border-slate-800 space-y-1 font-mono text-[11px]">
                <div className="text-slate-400">
                  Publishable Key: <span className="text-slate-200">{DEFAULT_PUBLISHABLE_KEY}</span>
                </div>
                <div className="text-slate-400">
                  Tables:{' '}
                  <span className="text-emerald-400">
                    users · subscriptions · app_configs · rate_lists · user_inputs
                  </span>
                </div>
              </div>

              <button
                onClick={async () => {
                  setSupabaseStatus('Testing ping to Supabase...');
                  const res = await onPushFullConfigToCloud();
                  setSupabaseStatus(res.message);
                }}
                className="w-full py-2 rounded-lg bg-[#F5B738] text-black font-bold hover:bg-amber-400 transition-colors"
              >
                Test Ping & Sync Full Admin Config to Supabase
              </button>

              {supabaseStatus && (
                <div className="p-2.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-[11px]">
                  {supabaseStatus}
                </div>
              )}
            </div>

            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-[#F5B738]" />
                <h3 className="text-sm font-bold text-[#F5B738]">
                  Admin-Base Anti-Theft & Formula Security Controls (Live Switches)
                </h3>
              </div>
              <p className="text-[11px] text-slate-400">
                Yeh security switches Client App ko control kartay hain taake agar kisi ke hath code ya APK lag bhi jaye to woh aap ke formulas ya app chori na kar sakay:
              </p>
              <div className="space-y-2">
                {[
                  {
                    key: 'serverDrivenFormulasOnly' as const,
                    title: '1. Zero Formulas in Client Code (100% Admin Cloud Formulas)',
                    desc: 'Formulas client code mein nahi hon gay — sirf verified active user ko Admin Cloud se runtime par milain gay.',
                  },
                  {
                    key: 'enforceDeviceHardwareLock' as const,
                    title: '2. Single-Device Hardware ID Binding (Anti-Sharing Lock)',
                    desc: 'Ek user account sirf us ke registered mobile Device ID par chalay ga; doosray phone par login block ho ga.',
                  },
                  {
                    key: 'autoLockOnSubscriptionExpiry' as const,
                    title: '3. Auto-Lock Calculator & Formulas on Package Expiry',
                    desc: 'Package ya 2-Day Trial khatam hotay hi Client App mein cutting aur quotation auto-lock ho jaye gi.',
                  },
                  {
                    key: 'requireServerTimeValidation' as const,
                    title: '4. Anti-Clock Rollback Protection (Server Time Check)',
                    desc: 'Agar user mobile ki tareekh (date/time) peechay kar ke free trial barhana chahay to server time usay pakar kar lock kar de ga.',
                  },
                  {
                    key: 'blockFormulaAndRateCopy' as const,
                    title: '5. Lock & Hide Formula Math + Anti-Copy Protection',
                    desc: 'Client App mein cutting formulas hidden rahain gay taake koi formulas dekh ya copy na kar sakay.',
                  },
                ].map((secItem) => {
                  const isOn = layoutConfig[secItem.key] !== false;
                  return (
                    <div
                      key={secItem.key}
                      className="p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-bold text-emerald-400 text-xs">{secItem.title}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{secItem.desc}</div>
                      </div>
                      {renderOnOffSwitch(isOn, (next) => {
                        onUpdateLayoutConfig({
                          ...layoutConfig,
                          [secItem.key]: next,
                        });
                        showNotice(`Updated "${secItem.title}"`);
                      })}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#F5B738] space-y-3 text-xs">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    SendPK SMS & Email OTP Gateway Settings (Cloud Synced — No Reinstall Needed!)
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Jab bhi aap future mein <strong>SendPK</strong> ka SMS package purchase karein, apni API Key, Username/Password aur Brand Mask yahan dalein aur <strong>Save & Push to Cloud</strong> daba dein.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-300 font-semibold">SendPK Live SMS:</span>
                  {renderOnOffSwitch(
                    smsGatewayConfig.sendpkEnabled,
                    (next) => {
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        sendpkEnabled: next,
                      });
                      showNotice(
                        next
                          ? 'SendPK Live SMS Mode turned ON!'
                          : 'SendPK Live SMS Mode turned OFF (Fallback Mode Active)'
                      );
                    },
                    'LIVE ON',
                    'OFF'
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    SendPK API Key (After Purchase)
                  </label>
                  <input
                    type="text"
                    value={smsGatewayConfig.sendpkApiKey}
                    onChange={(e) =>
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        sendpkApiKey: e.target.value,
                      })
                    }
                    placeholder="e.g. 923105524225-xxxxxxxxxxxx"
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    SendPK Sender Mask / Brand Name
                  </label>
                  <input
                    type="text"
                    value={smsGatewayConfig.sendpkSenderMask}
                    onChange={(e) =>
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        sendpkSenderMask: e.target.value,
                      })
                    }
                    placeholder="e.g. BOSS ALUM or 8583"
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-amber-300 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    SendPK Username (Optional if API Key used)
                  </label>
                  <input
                    type="text"
                    value={smsGatewayConfig.sendpkUsername}
                    onChange={(e) =>
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        sendpkUsername: e.target.value,
                      })
                    }
                    placeholder="SendPK account username / mobile"
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    SendPK Password (Optional if API Key used)
                  </label>
                  <input
                    type="password"
                    value={smsGatewayConfig.sendpkPassword}
                    onChange={(e) =>
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        sendpkPassword: e.target.value,
                      })
                    }
                    placeholder="SendPK account password"
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    Backup SMS.com.pk API Key (Optional)
                  </label>
                  <input
                    type="text"
                    value={smsGatewayConfig.smsComPkApiKey}
                    onChange={(e) =>
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        smsComPkApiKey: e.target.value,
                      })
                    }
                    placeholder="Optional SMS.com.pk API Key"
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    Resend Email OTP API Key (Optional)
                  </label>
                  <input
                    type="text"
                    value={smsGatewayConfig.resendApiKey}
                    onChange={(e) =>
                      onUpdateSmsGatewayConfig({
                        ...smsGatewayConfig,
                        resendApiKey: e.target.value,
                      })
                    }
                    placeholder="e.g. re_xxxxxxxxx"
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 mb-1">
                  OTP SMS Message Template (Use {'{OTP}'} for 6-digit code)
                </label>
                <input
                  type="text"
                  value={smsGatewayConfig.otpMessageTemplate}
                  onChange={(e) =>
                    onUpdateSmsGatewayConfig({
                      ...smsGatewayConfig,
                      otpMessageTemplate: e.target.value,
                    })
                  }
                  className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-white"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  onClick={async () => {
                    setIsPushing(true);
                    const res = await onPushFullConfigToCloud();
                    setIsPushing(false);
                    showNotice('SendPK SMS & OTP Settings saved & pushed to Supabase Cloud!');
                    setSupabaseStatus(res.message);
                  }}
                  className="px-4 py-2 rounded-lg bg-emerald-500 text-black font-bold hover:bg-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <CloudUpload className="w-3.5 h-3.5" />
                  <span>Save & Push SendPK Settings to Cloud</span>
                </button>
              </div>

              {/* Live Test SMS Sender */}
              <div className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 space-y-2">
                <div className="font-bold text-amber-300 text-[11px]">
                  Test SendPK SMS Gateway Live (Send Test OTP to Mobile)
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={testSmsPhone}
                    onChange={(e) => setTestSmsPhone(e.target.value)}
                    placeholder="03105524225"
                    className="flex-1 px-2.5 py-1.5 rounded bg-[#14181F] border border-slate-700 font-mono text-white"
                  />
                  <button
                    disabled={isSendingTestSms}
                    onClick={async () => {
                      setIsSendingTestSms(true);
                      setTestSmsStatus('Sending test OTP...');
                      try {
                        const resp = await fetch('/api/send-sms-otp', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                            phone: testSmsPhone,
                            gatewayConfig: smsGatewayConfig,
                          }),
                        });
                        const data = await resp.json();
                        if (data.deliveredViaSmsGateway) {
                          setTestSmsStatus(
                            `DELIVERED via ${data.provider} to ${data.mobile92}! OTP: ${data.otpCode}`
                          );
                        } else {
                          setTestSmsStatus(
                            `Test OTP Generated (${data.otpCode}) for ${data.mobile92}. Note: ${data.gatewayResponse}`
                          );
                        }
                      } catch (err: any) {
                        setTestSmsStatus(`Error: ${err?.message || 'Failed'}`);
                      } finally {
                        setIsSendingTestSms(false);
                      }
                    }}
                    className="px-3 py-1.5 rounded bg-[#F5B738] text-black font-bold whitespace-nowrap"
                  >
                    {isSendingTestSms ? 'Sending...' : 'Send Test SMS'}
                  </button>
                </div>
                {testSmsStatus && (
                  <div className="text-[11px] font-mono text-emerald-300">{testSmsStatus}</div>
                )}
              </div>

              {/* Live Cloud OTP Verifications Log (See Client OTP Codes even before SendPK is purchased!) */}
              <div className="p-3 rounded-lg bg-[#0C0F14] border border-sky-500/40 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-sky-400 text-[11px]">
                      Live Client OTP Verification Codes (`otp_verifications` Table)
                    </div>
                    <div className="text-[10px] text-slate-400">
                      SendPK purchase karne se pehle agar koi client OTP code poochay, to yahan click kar ke us ka 6-digit OTP dekh saktay hain:
                    </div>
                  </div>
                  <button
                    onClick={handleFetchCloudOtpLogs}
                    className="px-2.5 py-1 rounded bg-sky-500 text-black font-bold text-[11px] flex items-center gap-1 shrink-0"
                  >
                    <RefreshCw className={`w-3 h-3 ${isLoadingOtpLogs ? 'animate-spin' : ''}`} />
                    <span>Load OTPs</span>
                  </button>
                </div>
                {cloudOtpLogs.length > 0 && (
                  <div className="max-h-36 overflow-y-auto space-y-1 pt-1">
                    {cloudOtpLogs.map((row, rIdx) => (
                      <div
                        key={rIdx}
                        className="p-1.5 rounded bg-[#14181F] border border-slate-800 flex items-center justify-between text-[11px] font-mono"
                      >
                        <span className="text-slate-200">
                          {row.phone || row.email || 'Client'} ({row.channel || 'OTP'})
                        </span>
                        <span className="text-[#F5B738] font-bold">
                          OTP: {row.otp_code || 'N/A'}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#14181F] border border-[#F5B738] space-y-3 text-xs">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    Universal Gemini Command for Mobile & Computer Client Apps (Copy & Paste)
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Yeh Command apni <strong>Client App</strong> ke Gemini chat mein paste kar dein taake jab aap future mein SendPK purchase kar ke upar API Key dalein, to Client App <strong>bina dobara install kiye</strong> Cloud se SendPK chala le!
                  </p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(clientAppGeminiMasterCommand);
                    showNotice('Universal Gemini Command copied! Works for both Mobile & Computer Client Apps.');
                  }}
                  className="px-3.5 py-2 rounded-lg bg-[#F5B738] text-black font-bold flex items-center gap-1.5 shrink-0"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Command</span>
                </button>
              </div>

              <pre className="p-3.5 rounded-xl bg-[#0C0F14] border border-slate-800 text-[11px] font-mono text-amber-100 whitespace-pre-wrap leading-relaxed max-h-[300px] overflow-y-auto">
                {clientAppGeminiMasterCommand}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
