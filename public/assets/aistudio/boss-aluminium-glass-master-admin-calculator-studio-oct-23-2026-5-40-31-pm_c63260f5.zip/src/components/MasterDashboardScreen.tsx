import React, { useState } from 'react';
import {
  Users,
  Smartphone,
  CreditCard,
  Package,
  Layers,
  Search,
  CheckCircle2,
  Lock,
  Unlock,
  Plus,
  Trash2,
  RefreshCw,
  Copy,
  Check,
  Eye,
  EyeOff,
  CloudUpload,
  Sparkles,
  Phone,
  Mail,
  MapPin,
  FileText,
  AlertTriangle,
  RotateCcw,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  Key,
  MessageSquare,
  Sliders,
  X,
  Upload,
  Edit2,
  Tag,
  Percent,
  Zap,
  Radio,
} from 'lucide-react';
import {
  IdentityRecord,
  BankAccountConfig,
  PaymentReceiptLog,
  SubscriptionPackageConfig,
  SubscriptionPackage,
  AppOfferBanner,
  ClientAppLayoutControlConfig,
  DeletedBackupItem,
  WindowItem,
  DoorItem,
  FixFrameItem,
  OpenableWindowItem,
  SlidingDoorItem,
  BossTab,
} from '../types/bossModels';
import { DEFAULT_SECTIONS, getStarterPackages } from '../utils/bossDefaultRates';

interface MasterDashboardScreenProps {
  users: IdentityRecord[];
  onUpdateUsers: (users: IdentityRecord[]) => void;
  bankAccounts: BankAccountConfig[];
  onUpdateBankAccounts: (accounts: BankAccountConfig[]) => void;
  paymentLogs: PaymentReceiptLog[];
  onAddPaymentLog: (log: PaymentReceiptLog) => void;
  packages: SubscriptionPackageConfig[];
  onUpdatePackages: (pkgs: SubscriptionPackageConfig[]) => void;
  activeOffer?: AppOfferBanner | null;
  onSaveOffer?: (offer: AppOfferBanner | null) => void;
  layoutConfig: ClientAppLayoutControlConfig;
  onUpdateLayoutConfig: (cfg: ClientAppLayoutControlConfig) => void;
  windows: WindowItem[];
  onUpdateWindows: (wins: WindowItem[]) => void;
  doors: DoorItem[];
  onUpdateDoors: (doors: DoorItem[]) => void;
  fixframes: FixFrameItem[];
  onUpdateFixFrames: (frames: FixFrameItem[]) => void;
  openableWindows: OpenableWindowItem[];
  onUpdateOpenableWindows: (wins: OpenableWindowItem[]) => void;
  slidingDoors: SlidingDoorItem[];
  onUpdateSlidingDoors: (doors: SlidingDoorItem[]) => void;
  projectExtras: any[];
  onUpdateProjectExtras: (extras: any[]) => void;
  customSections: string[];
  onUpdateCustomSections: (secs: string[]) => void;
  availableColors: string[];
  onUpdateAvailableColors: (colors: string[]) => void;
  hiddenSections: string[];
  onToggleHideSection: (sec: string) => void;
  onDeleteSection: (sec: string) => void;
  onDeleteColor: (col: string) => void;
  glassRates: Record<string, Record<string, number>>;
  onUpdateGlassRate: (gauge: string, color: string, rate: number) => void;
  onAddGlassColor: (gauge: string, color: string, rate: number) => void;
  onDeleteGlassColor: (gauge: string, color: string) => void;
  deletedBackupVault: DeletedBackupItem[];
  onAddBackupItem: (item: any) => void;
  onRestoreBackupItem: (item: any) => void;
  onClearAllBackup?: () => void;
  onPullUsersFromCloud: () => void;
  onSyncUserToSupabase: (user: IdentityRecord) => void;
}

export const MasterDashboardScreen: React.FC<MasterDashboardScreenProps> = ({
  users = [],
  onUpdateUsers,
  bankAccounts = [],
  onUpdateBankAccounts,
  paymentLogs = [],
  onAddPaymentLog,
  packages = [],
  onUpdatePackages,
  activeOffer,
  onSaveOffer,
  layoutConfig,
  onUpdateLayoutConfig,
  deletedBackupVault = [],
  onAddBackupItem,
  onRestoreBackupItem,
  onClearAllBackup,
  onPullUsersFromCloud,
  onSyncUserToSupabase,
}) => {
  // 5 MASTER TABS (Per Screenshot 3 & 4)
  const [activeTab, setActiveTab] = useState<
    'CLIENTS' | 'PAGES' | 'INBOX' | 'DEFAULTS' | 'BACKUP'
  >('CLIENTS');

  // Search & Status Filter for Clients (Per Screenshot 1: All, Active, Expired/Locked, Lifetime VIP, Paid Accounts)
  const [clientSearch, setClientSearch] = useState('');
  const [clientStatusFilter, setClientStatusFilter] = useState<
    'ALL' | 'ACTIVE' | 'EXPIRED_LOCKED' | 'LIFETIME' | 'PAID'
  >('ALL');

  // Preview Photo Modal State
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const [previewPhotoTitle, setPreviewPhotoTitle] = useState<string>('');

  // Gallery Modal for Client
  const [selectedGalleryUser, setSelectedGalleryUser] = useState<IdentityRecord | null>(null);

  // Toast Notice
  const [dashToast, setDashToast] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setDashToast(msg);
    setTimeout(() => setDashToast(null), 3500);
  };

  // Add Manual Client Modal
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserCnic, setNewUserCnic] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserShop, setNewUserShop] = useState('');
  const [newUserTier, setNewUserTier] = useState<string>('LIFETIME_VIP');

  // Add New Page / Tab Modal (Per Screenshot 4)
  const [showAddTabModal, setShowAddTabModal] = useState(false);
  const [newTabTitle, setNewTabTitle] = useState('');
  const [newTabId, setNewTabId] = useState('');
  const [newTabIcon, setNewTabIcon] = useState('Layers');

  // Subscription Package Add / Edit Modal State
  const [showPkgModal, setShowPkgModal] = useState(false);
  const [editingPkgId, setEditingPkgId] = useState<string | null>(null);
  const [pkgName, setPkgName] = useState('');
  const [pkgPlanCode, setPkgPlanCode] = useState('MONTHLY');
  const [pkgDurationMonths, setPkgDurationMonths] = useState<number>(1);
  const [pkgDurationLabel, setPkgDurationLabel] = useState('1 Month (30 Days)');
  const [pkgPriceRs, setPkgPriceRs] = useState<number>(3000);
  const [pkgOriginalPriceRs, setPkgOriginalPriceRs] = useState<number>(3000);
  const [pkgDiscountPct, setPkgDiscountPct] = useState<number>(0);
  const [pkgDiscountOfferText, setPkgDiscountOfferText] = useState('');
  const [pkgBadgeText, setPkgBadgeText] = useState('');
  const [pkgIsLifetime, setPkgIsLifetime] = useState(false);
  const [pkgIsActive, setPkgIsActive] = useState(true);
  const [pkgFeatures, setPkgFeatures] = useState<string[]>([]);
  const [newFeatureInput, setNewFeatureInput] = useState('');

  // Global Discount Offer Modal State
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [globalDiscountPct, setGlobalDiscountPct] = useState<number>(20);
  const [globalOfferTitle, setGlobalOfferTitle] = useState('Ramzan & Eid Special Discount Offer');
  const [globalOfferMsg, setGlobalOfferMsg] = useState('Special 20% discount offer activated on all subscription packages! Limited time only.');
  const [globalSyncToBanner, setGlobalSyncToBanner] = useState(true);
  const [pkgToDelete, setPkgToDelete] = useState<SubscriptionPackageConfig | null>(null);

  const handleOpenAddPkg = () => {
    setEditingPkgId(null);
    setPkgName('');
    setPkgPlanCode('MONTHLY');
    setPkgDurationMonths(1);
    setPkgDurationLabel('1 Month (30 Days)');
    setPkgPriceRs(3000);
    setPkgOriginalPriceRs(3000);
    setPkgDiscountPct(0);
    setPkgDiscountOfferText('');
    setPkgBadgeText('Standard');
    setPkgIsLifetime(false);
    setPkgIsActive(true);
    setPkgFeatures([
      'All 9 Cutting, Length, Glass & Quotation Screens',
      'Live Cloud Rate List & Formula Updates',
      'Unlimited PDF & WhatsApp Quotations',
    ]);
    setNewFeatureInput('');
    setShowPkgModal(true);
  };

  const handleOpenEditPkg = (pkg: SubscriptionPackageConfig) => {
    setEditingPkgId(pkg.id);
    setPkgName(pkg.name || '');
    setPkgPlanCode(pkg.planCode || 'MONTHLY');
    setPkgDurationMonths(pkg.durationMonths ?? 1);
    setPkgDurationLabel(pkg.durationLabel || `${pkg.durationMonths} Month(s)`);
    const orig = pkg.originalPriceRs ?? pkg.price ?? pkg.priceRs ?? 0;
    const curPrice = pkg.priceRs ?? pkg.price ?? orig;
    setPkgOriginalPriceRs(orig);
    setPkgPriceRs(curPrice);
    setPkgDiscountPct(pkg.discountPct ?? (orig > curPrice ? Math.round(((orig - curPrice) / orig) * 100) : 0));
    setPkgDiscountOfferText(pkg.discountOfferText || '');
    setPkgBadgeText(pkg.badgeText || pkg.badge || '');
    setPkgIsLifetime(Boolean(pkg.isLifetime));
    setPkgIsActive(pkg.isActive !== false);
    setPkgFeatures(Array.isArray(pkg.features) ? [...pkg.features] : []);
    setNewFeatureInput('');
    setShowPkgModal(true);
  };

  const handleSavePkg = () => {
    if (!pkgName.trim()) {
      showToast('Please enter Package Name');
      return;
    }
    const cleanOrig = Math.max(0, Number(pkgOriginalPriceRs) || Number(pkgPriceRs) || 0);
    const cleanPrice = Math.max(0, Number(pkgPriceRs) || 0);
    const cleanDisc = pkgDiscountPct > 0 ? pkgDiscountPct : cleanOrig > cleanPrice ? Math.round(((cleanOrig - cleanPrice) / cleanOrig) * 100) : 0;

    const updatedItem: SubscriptionPackageConfig = {
      id: editingPkgId || `pkg-${Date.now()}`,
      name: pkgName.trim(),
      planCode: pkgPlanCode.trim().toUpperCase() || 'CUSTOM',
      durationMonths: Number(pkgDurationMonths) || 1,
      durationLabel: pkgDurationLabel.trim() || `${pkgDurationMonths} Month(s)`,
      priceRs: cleanPrice,
      price: cleanPrice,
      originalPriceRs: cleanOrig,
      discountPct: cleanDisc,
      discountOfferText: pkgDiscountOfferText.trim(),
      badgeText: pkgBadgeText.trim(),
      badge: pkgBadgeText.trim(),
      isLifetime: Boolean(pkgIsLifetime),
      isActive: Boolean(pkgIsActive),
      features: pkgFeatures.filter((f) => f.trim().length > 0),
    };

    if (editingPkgId) {
      const next = packages.map((p) => (p.id === editingPkgId ? updatedItem : p));
      onUpdatePackages(next);
      showToast(`Package "${pkgName.trim()}" updated successfully!`);
    } else {
      onUpdatePackages([...packages, updatedItem]);
      showToast(`New package "${pkgName.trim()}" created!`);
    }
    setShowPkgModal(false);
  };

  const handleDeletePkgConfirm = () => {
    if (!pkgToDelete) return;
    const next = packages.filter((p) => p.id !== pkgToDelete.id);
    onUpdatePackages(next);
    showToast(`Package "${pkgToDelete.name}" deleted.`);
    setPkgToDelete(null);
  };

  const handleApplyGlobalDiscount = () => {
    const pct = Math.max(0, Math.min(100, Number(globalDiscountPct) || 0));
    if (pct <= 0) {
      showToast('Please enter a valid discount percentage (e.g. 10%, 20%, 30%)');
      return;
    }
    const updated = packages.map((p) => {
      const orig = p.originalPriceRs && p.originalPriceRs > 0 ? p.originalPriceRs : (p.priceRs ?? p.price ?? 3000);
      const discounted = Math.round(orig * (1 - pct / 100));
      return {
        ...p,
        originalPriceRs: orig,
        priceRs: discounted,
        price: discounted,
        discountPct: pct,
        discountOfferText: globalOfferTitle.trim() || `${pct}% Discount Offer`,
        badgeText: p.badgeText || `${pct}% OFF`,
      };
    });
    onUpdatePackages(updated);

    if (globalSyncToBanner && onSaveOffer) {
      onSaveOffer({
        id: `offer-${Date.now()}`,
        title: globalOfferTitle.trim() || `Special ${pct}% Discount Offer`,
        message: globalOfferMsg.trim() || `Save ${pct}% on all subscription packages! Transfer payment to our bank account and activate instantly.`,
        badgeText: `🔥 ${pct}% SPECIAL OFFER`,
        discountPct: pct,
        isActive: true,
        createdAt: Date.now(),
        createdBy: 'Master Owner',
      });
      showToast(`${pct}% Discount applied to all packages & published to Live Broadcast Banner!`);
    } else {
      showToast(`${pct}% Discount applied to all ${packages.length} packages!`);
    }
    setShowDiscountModal(false);
  };

  const handleClearGlobalDiscounts = () => {
    const restored = packages.map((p) => {
      const orig = p.originalPriceRs && p.originalPriceRs > 0 ? p.originalPriceRs : (p.priceRs ?? p.price ?? 3000);
      return {
        ...p,
        priceRs: orig,
        price: orig,
        originalPriceRs: undefined,
        discountPct: 0,
        discountOfferText: '',
      };
    });
    onUpdatePackages(restored);
    if (onSaveOffer && activeOffer) {
      onSaveOffer(null);
    }
    showToast('All package discounts removed and prices reset to original!');
    setShowDiscountModal(false);
  };

  const handleRestoreStarterPackages = () => {
    const defaults = getStarterPackages();
    onUpdatePackages(defaults);
    showToast('Restored default 5 Subscription Packages (3k, 8k, 16k, 31k, 60k)!');
  };

  // Mock / Initial Support Inquiries
  const [supportRequests, setSupportRequests] = useState([
    {
      id: 'sr-1',
      clientName: 'Tariq Mehmood',
      phone: '0300-4419283',
      cnic: '37405-1234567-1',
      requestType: 'TID Receipt Verification',
      message: 'Sent Rs. 3,000 via EasyPaisa TID: 8392019482 for 1 Month Renewal.',
      createdAt: Date.now() - 3600000 * 4,
      isResolved: false,
    },
    {
      id: 'sr-2',
      clientName: 'Al-Madina Aluminium Gujranwala',
      phone: '0321-9876543',
      cnic: '34101-9988776-5',
      requestType: 'Hardware Lock Reset',
      message: 'New phone bought, please reset device binding for our factory app.',
      createdAt: Date.now() - 86400000,
      isResolved: false,
    },
  ]);

  // Client counts
  const now = Date.now();
  const totalUsers = users.length;
  const activeCount = users.filter((u) => (u.isActivated || u.isLifetimeFree) && !u.isBlocked).length;
  const expiredOrLockedCount = users.filter(
    (u) => u.isBlocked || (!u.isLifetimeFree && u.activatedUntil && u.activatedUntil < now)
  ).length;
  const lifetimeCount = users.filter((u) => u.isLifetimeFree).length;
  const paidCount = users.filter((u) => u.packagePlan && u.packagePlan !== 'TRIAL').length;

  // Filtered Clients
  const filteredUsers = users.filter((u) => {
    const q = clientSearch.toLowerCase().trim();
    const matchQ =
      !q ||
      u.name?.toLowerCase().includes(q) ||
      u.phone?.toLowerCase().includes(q) ||
      u.cnic?.toLowerCase().includes(q) ||
      u.email?.toLowerCase().includes(q) ||
      u.deviceId?.toLowerCase().includes(q) ||
      u.shopAddress?.toLowerCase().includes(q);

    if (!matchQ) return false;

    if (clientStatusFilter === 'ACTIVE') {
      return (u.isActivated || u.isLifetimeFree) && !u.isBlocked;
    }
    if (clientStatusFilter === 'EXPIRED_LOCKED') {
      return u.isBlocked || (!u.isLifetimeFree && u.activatedUntil && u.activatedUntil < now);
    }
    if (clientStatusFilter === 'LIFETIME') {
      return u.isLifetimeFree;
    }
    if (clientStatusFilter === 'PAID') {
      return u.packagePlan && u.packagePlan !== 'TRIAL';
    }
    return true;
  });

  // Client Actions
  const handleToggleBlock = (user: IdentityRecord) => {
    const nextBlocked = !user.isBlocked;
    const updated: IdentityRecord = {
      ...user,
      isBlocked: nextBlocked,
      blockReason: nextBlocked ? 'Suspended by Master Admin' : '',
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(nextBlocked ? `Client "${user.name}" Blocked & Suspended` : `Client "${user.name}" Unblocked`);
  };

  const handleLockApp = (user: IdentityRecord) => {
    const reason = user.blockReason ? '' : 'Locked by Boss Master Security';
    const updated: IdentityRecord = {
      ...user,
      isBlocked: !user.isBlocked,
      blockReason: reason,
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(`App Lock updated for "${user.name}"`);
  };

  const handleToggleVip = (user: IdentityRecord) => {
    const isVip = !user.isLifetimeFree;
    const updated: IdentityRecord = {
      ...user,
      isLifetimeFree: isVip,
      isActivated: true,
      packagePlan: isVip ? 'LIFETIME_VIP' : 'MONTHLY',
      activatedUntil: isVip ? now + 86400000 * 365 * 50 : now + 86400000 * 30,
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(isVip ? `⭐ VIP Lifetime Free activated for "${user.name}"` : `VIP Revoked for "${user.name}"`);
  };

  const handleExtendTrial = (user: IdentityRecord, days: number = 7) => {
    const currentExpiry = Number(user.activatedUntil || now);
    const base = currentExpiry > now ? currentExpiry : now;
    const newExpiry = base + days * 86400000;
    const updated: IdentityRecord = {
      ...user,
      isActivated: true,
      activatedUntil: newExpiry,
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(`+${days} Days added to "${user.name}" license!`);
  };

  const handleLogoutDevice = (user: IdentityRecord) => {
    const updated: IdentityRecord = {
      ...user,
      deviceId: 'RESET_' + Math.random().toString(36).substring(2, 10).toUpperCase(),
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(`Device session reset for "${user.name}". They can log in on their new phone.`);
  };

  const handleAllowCnic = (user: IdentityRecord) => {
    const updated: IdentityRecord = {
      ...user,
      allowSecondCnic: !user.allowSecondCnic,
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(`Secondary device access toggled for CNIC ${user.cnic}`);
  };

  const handleDeleteUser = (user: IdentityRecord) => {
    const nextUsers = users.filter((u) => u.phone !== user.phone && u.deviceId !== user.deviceId);
    onUpdateUsers(nextUsers);
    if (onAddBackupItem) {
      onAddBackupItem({
        id: 'del-user-' + Date.now(),
        category: 'USER_ACCOUNT',
        title: `Client Account: ${user.name} (${user.phone})`,
        codeOrKey: user.phone,
        deletedAt: Date.now(),
        payload: user,
      });
    }
    showToast(`Client "${user.name}" deleted and saved to Backup Vault`);
  };

  const handleApplyPackage = (user: IdentityRecord, planVal: string) => {
    let isLifetime = false;
    let addDays = 30;
    let planCode = 'MONTHLY';

    if (planVal === 'LIFETIME') {
      isLifetime = true;
      planCode = 'LIFETIME_VIP';
      addDays = 365 * 50;
    } else if (planVal === 'QUARTERLY') {
      planCode = 'QUARTERLY';
      addDays = 90;
    } else if (planVal === 'HALF_YEARLY') {
      planCode = 'HALF_YEARLY';
      addDays = 180;
    } else if (planVal === 'YEARLY') {
      planCode = 'YEARLY';
      addDays = 365;
    } else {
      planCode = 'MONTHLY';
      addDays = 30;
    }

    const updated: IdentityRecord = {
      ...user,
      isLifetimeFree: isLifetime,
      isActivated: true,
      packagePlan: planCode,
      activatedUntil: now + addDays * 86400000,
    };
    const nextUsers = users.map((u) => (u.phone === user.phone ? updated : u));
    onUpdateUsers(nextUsers);
    onSyncUserToSupabase(updated);
    showToast(`Applied package "${planCode}" to client "${user.name}"!`);
  };

  const handleCreateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserPhone.trim()) {
      showToast('Please enter Name and Mobile number');
      return;
    }
    const cleanPhone = newUserPhone.trim();
    const isVip = newUserTier === 'LIFETIME_VIP';
    const newRecord: IdentityRecord = {
      deviceId: 'DEV-' + Math.random().toString(36).substring(2, 10).toUpperCase(),
      name: newUserName.trim(),
      phone: cleanPhone,
      cnic: newUserCnic.trim() || '37405-0000000-0',
      email: newUserEmail.trim() || `${cleanPhone}@bossaluminium.pk`,
      shopAddress: newUserShop.trim() || 'Aluminium & Glass Workshop, Pakistan',
      ipAddress: '103.255.4.1',
      trialStartTime: now,
      firstRegisteredAt: now,
      isActivated: true,
      activatedUntil: isVip ? now + 86400000 * 365 * 50 : now + 86400000 * 30,
      packagePlan: isVip ? 'LIFETIME_VIP' : 'MONTHLY',
      isBlocked: false,
      blockReason: '',
      isLifetimeFree: isVip,
    };

    onUpdateUsers([newRecord, ...users]);
    onSyncUserToSupabase(newRecord);
    setShowAddUserModal(false);
    setNewUserName('');
    setNewUserPhone('');
    setNewUserCnic('');
    setNewUserEmail('');
    setNewUserShop('');
    showToast(`New client "${newRecord.name}" created and synced live!`);
  };

  // Standard Master Tabs for Client App Top Menu
  const standardTabs: Array<{ id: string; defaultTitle: string; icon: string }> = [
    { id: 'WINDOWS', defaultTitle: 'Windows', icon: 'Box' },
    { id: 'DOORS', defaultTitle: 'Doors & Frames', icon: 'Layers' },
    { id: 'EXTRA_PIECES', defaultTitle: 'Extra Pieces', icon: 'Sliders' },
    { id: 'CUTTING', defaultTitle: 'Cutting Chart', icon: 'FileText' },
    { id: 'LENGTH', defaultTitle: 'Length Chart', icon: 'FileText' },
    { id: 'GLASS', defaultTitle: 'Glass Chart', icon: 'Sparkles' },
    { id: 'QUOTATION', defaultTitle: 'Quotation', icon: 'CreditCard' },
    { id: 'HISTORY', defaultTitle: 'History', icon: 'Clock' },
    { id: 'RATES', defaultTitle: 'Rates & Settings', icon: 'Sliders' },
  ];

  // Combined with custom tabs
  const customTabsList = Object.keys(layoutConfig.tabCustomTitles || {})
    .filter((k) => !standardTabs.some((st) => st.id === k))
    .map((k) => ({
      id: k,
      defaultTitle: layoutConfig.tabCustomTitles[k] || k,
      icon: 'Layers',
      isCustom: true,
    }));

  const allPageTabs = [...standardTabs, ...customTabsList];

  const handleUpdateTabTitle = (tabId: string, val: string) => {
    onUpdateLayoutConfig({
      ...layoutConfig,
      tabCustomTitles: {
        ...(layoutConfig.tabCustomTitles || {}),
        [tabId]: val,
      },
    });
  };

  const handleToggleTabVisibility = (tabId: string) => {
    const current = layoutConfig.enabledTabs?.[tabId] !== false;
    onUpdateLayoutConfig({
      ...layoutConfig,
      enabledTabs: {
        ...(layoutConfig.enabledTabs || {}),
        [tabId]: !current,
      },
    });
    showToast(`Tab "${tabId}" is now ${!current ? 'Visible (ON)' : 'Hidden (OFF)'}`);
  };

  const handleDeleteTab = (tabId: string, tabTitle: string) => {
    onUpdateLayoutConfig({
      ...layoutConfig,
      enabledTabs: {
        ...(layoutConfig.enabledTabs || {}),
        [tabId]: false,
      },
    });
    if (onAddBackupItem) {
      onAddBackupItem({
        id: 'del-tab-' + Date.now(),
        category: 'CALC_TAB',
        title: `App Tab: ${tabTitle} (${tabId})`,
        codeOrKey: tabId,
        deletedAt: Date.now(),
        payload: { tabId, tabTitle },
      });
    }
    showToast(`Tab "${tabTitle}" removed and saved in Backup Vault!`);
  };

  const handleAddNewTabSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTabTitle.trim()) {
      showToast('Please enter a Tab Name');
      return;
    }
    const cleanId = (newTabId.trim() || newTabTitle.trim())
      .toUpperCase()
      .replace(/[^A-Z0-9_]/g, '_');

    onUpdateLayoutConfig({
      ...layoutConfig,
      enabledTabs: {
        ...(layoutConfig.enabledTabs || {}),
        [cleanId]: true,
      },
      tabCustomTitles: {
        ...(layoutConfig.tabCustomTitles || {}),
        [cleanId]: newTabTitle.trim(),
      },
    });
    setShowAddTabModal(false);
    setNewTabTitle('');
    setNewTabId('');
    showToast(`✓ New Standalone Page/Tab "${newTabTitle.trim()}" published to Client App!`);
  };

  return (
    <div className="space-y-4">
      {/* Toast Notification */}
      {dashToast && (
        <div className="fixed bottom-6 right-6 z-50 p-3.5 rounded-xl bg-amber-500 text-black font-bold text-xs shadow-2xl flex items-center gap-2 border border-amber-300 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-black" />
          <span>{dashToast}</span>
        </div>
      )}

      {/* Top Header Card */}
      <div className="p-4 rounded-xl bg-[#0F141C] border border-[#2B3441] flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-black text-[#F5B738] tracking-wide flex items-center gap-2">
            <Users className="w-5 h-5 text-[#F5B738]" />
            <span>Master Control & Client Licenses Vault</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real-time management of client devices, approvals, CNIC verification, bank accounts & mobile apps
          </p>
        </div>

        {/* 5 Master Tabs (Screenshots 3 & 4) */}
        <div className="flex items-center gap-1.5 flex-wrap p-1 bg-[#141A24] border border-slate-800 rounded-xl text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('CLIENTS')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'CLIENTS'
                ? 'bg-[#F5B738] text-black shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>1. Clients & Licenses ({totalUsers})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PAGES')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'PAGES'
                ? 'bg-[#F5B738] text-black shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>2. Top Menu & Page Controls</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('INBOX')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'INBOX'
                ? 'bg-[#F5B738] text-black shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>3. Client Support Inbox ({supportRequests.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('DEFAULTS')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'DEFAULTS'
                ? 'bg-[#F5B738] text-black shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>4. Official Default Settings</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('BACKUP')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'BACKUP'
                ? 'bg-[#F5B738] text-black shadow-md'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>5. Backup Vault ({deletedBackupVault.length})</span>
          </button>
        </div>
      </div>

      {/* =================================================================== */}
      {/* TAB 1: CLIENTS & LICENSES (SCREENSHOT 1 EXACT DESIGN)               */}
      {/* =================================================================== */}
      {activeTab === 'CLIENTS' && (
        <div className="space-y-4">
          {/* Status Filter Pills (Per Screenshot 1: All, Active, Expired/Locked, Lifetime VIP, Paid Accounts) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button
              type="button"
              onClick={() => setClientStatusFilter('ALL')}
              className={`px-3.5 py-1.5 rounded-full font-bold transition-colors cursor-pointer ${
                clientStatusFilter === 'ALL'
                  ? 'bg-amber-500 text-black shadow'
                  : 'bg-[#141A24] text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              All ({totalUsers})
            </button>

            <button
              type="button"
              onClick={() => setClientStatusFilter('ACTIVE')}
              className={`px-3.5 py-1.5 rounded-full font-bold transition-colors cursor-pointer ${
                clientStatusFilter === 'ACTIVE'
                  ? 'bg-amber-500 text-black shadow'
                  : 'bg-[#141A24] text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              Active ({activeCount})
            </button>

            <button
              type="button"
              onClick={() => setClientStatusFilter('EXPIRED_LOCKED')}
              className={`px-3.5 py-1.5 rounded-full font-bold transition-colors cursor-pointer ${
                clientStatusFilter === 'EXPIRED_LOCKED'
                  ? 'bg-amber-500 text-black shadow'
                  : 'bg-[#141A24] text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              Expired/Locked ({expiredOrLockedCount})
            </button>

            <button
              type="button"
              onClick={() => setClientStatusFilter('LIFETIME')}
              className={`px-3.5 py-1.5 rounded-full font-bold transition-colors cursor-pointer ${
                clientStatusFilter === 'LIFETIME'
                  ? 'bg-amber-500 text-black shadow'
                  : 'bg-[#141A24] text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              Lifetime VIP ({lifetimeCount})
            </button>

            <button
              type="button"
              onClick={() => setClientStatusFilter('PAID')}
              className={`px-3.5 py-1.5 rounded-full font-bold transition-colors cursor-pointer ${
                clientStatusFilter === 'PAID'
                  ? 'bg-amber-500 text-black shadow'
                  : 'bg-[#141A24] text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              Paid Accounts ({paidCount})
            </button>

            {/* Pull Cloud & + Add Client */}
            <div className="ml-auto flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  onPullUsersFromCloud();
                  showToast('Pulling latest clients & subscriptions from Supabase Cloud...');
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-400 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Pull Cloud</span>
              </button>

              <button
                type="button"
                onClick={() => setShowAddUserModal(true)}
                className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-[#F5B738] text-black text-xs font-black flex items-center gap-1.5 shadow cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Client</span>
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={clientSearch}
              onChange={(e) => setClientSearch(e.target.value)}
              placeholder="Search by Client Name, Mobile, CNIC, Device ID, or Shop Address..."
              className="w-full pl-9 pr-3 py-2 bg-[#0F141C] border border-slate-800 focus:border-[#F5B738] rounded-xl text-xs text-white placeholder-slate-500 outline-none"
            />
          </div>

          {/* Client Cards List */}
          <div className="space-y-4">
            {filteredUsers.length === 0 ? (
              <div className="p-12 text-center border-2 border-dashed border-slate-800 rounded-2xl text-slate-400 text-xs bg-[#0C1017]">
                No client accounts matched your filter criteria.
              </div>
            ) : (
              filteredUsers.map((u, idx) => {
                const picsCount = u.uploadedPhotos?.length || (u.cnicPhotoPath ? 2 : 0);
                const firstLetter = u.name ? u.name.charAt(0).toUpperCase() : 'S';

                return (
                  <div
                    key={u.deviceId || u.phone || idx}
                    className="p-5 rounded-2xl bg-[#0B0F16] border-2 border-amber-500/70 shadow-xl space-y-3.5 text-white"
                  >
                    {/* Header: Circle Avatar + Name/VIP + Registered Date + Top Buttons */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        {/* Circle Avatar (matching Screenshot 1) */}
                        <div className="w-10 h-10 rounded-full bg-[#E5A835] text-black font-black text-lg flex items-center justify-center shrink-0 shadow-md">
                          {firstLetter}
                        </div>
                        <div>
                          <h3 className="text-sm sm:text-base font-bold text-[#F5B738] flex items-center gap-2 flex-wrap">
                            <span>
                              {idx + 1}. {u.name || 'Unnamed Client'}
                            </span>
                            <span className="text-xs text-[#F5B738] font-bold">
                              · {u.isLifetimeFree ? 'LIFETIME_VIP' : u.packagePlan || 'TRIAL'}
                            </span>
                          </h3>
                          <p className="text-[11px] text-slate-400 font-mono">
                            Registered:{' '}
                            {new Date(
                              u.firstRegisteredAt || u.trialStartTime || now
                            ).toLocaleDateString('en-GB', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                            })}
                          </p>
                        </div>
                      </div>

                      {/* Top Right Buttons: Uploaded Pics & Get Code */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={() => setSelectedGalleryUser(u)}
                          className="px-3 py-1.5 rounded-lg bg-sky-950/60 border border-sky-500/60 text-xs font-bold text-sky-300 hover:bg-sky-900/60 flex items-center gap-1.5 shadow cursor-pointer"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>Uploaded Pics ({picsCount})</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            const code = u.clientKey || `DEV-${u.phone || u.deviceId}`;
                            navigator.clipboard.writeText(code);
                            showToast(`Client Key "${code}" copied to clipboard!`);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-amber-950/60 border border-amber-500/60 text-xs font-bold text-amber-300 hover:bg-amber-900/60 flex items-center gap-1.5 shadow cursor-pointer"
                        >
                          <Key className="w-3.5 h-3.5" />
                          <span>Get Code</span>
                        </button>
                      </div>
                    </div>

                    {/* Blue Details Box (Matching Screenshot 1) */}
                    <div className="p-3.5 rounded-xl bg-[#0B1523] border border-[#1E2D42] space-y-2 text-xs">
                      {/* Row 1: Mobile + CNIC + WhatsApp */}
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="text-slate-200">
                          <span className="text-slate-400">Mobile:</span>{' '}
                          <strong className="text-white font-mono">{u.phone || 'N/A'}</strong>
                          {' · '}
                          <span className="text-slate-400">CNIC:</span>{' '}
                          <strong className="text-white font-mono">{u.cnic || 'N/A'}</strong>
                        </div>
                        {u.phone && (
                          <a
                            href={`https://wa.me/92${u.phone.replace(/[^0-9]/g, '').replace(/^0/, '')}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-2.5 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 shadow"
                          >
                            <span>WhatsApp</span>
                          </a>
                        )}
                      </div>

                      {/* Row 2: Shop / Factory */}
                      <div className="text-slate-300">
                        <span className="text-slate-400">Shop / Factory:</span>{' '}
                        {u.shopAddress || 'Boss Aluminium & Glass HQ, Main Market, Pakistan'}
                      </div>

                      {/* Row 3: Email + Client Key */}
                      <div className="flex items-center justify-between flex-wrap gap-2 text-slate-300 font-mono text-[11px]">
                        <div>
                          <span className="text-slate-400">Email:</span> {u.email || 'N/A'}
                        </div>
                        <div className="text-slate-400">
                          Client Key:{' '}
                          <strong className="text-amber-300">
                            {u.clientKey || 'DEV-DEV528-4225'}
                          </strong>
                        </div>
                      </div>

                      {/* Row 4: Device ID + IP */}
                      <div className="flex items-center justify-between flex-wrap gap-2 text-slate-400 font-mono text-[11px]">
                        <div>
                          Dev:{' '}
                          <span className="text-slate-300">
                            {u.deviceId || 'DEV-528527AD0AD85E56'}
                          </span>
                        </div>
                        <div>
                          IP: <span className="text-sky-300">Cloud-Sync</span>
                        </div>
                      </div>
                    </div>

                    {/* CNIC Front/Back & Uploaded Pics Section */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-amber-300 font-bold flex items-center gap-1">
                            <ImageIcon className="w-3.5 h-3.5" />
                            <span>
                              CNIC Front/Back & Uploaded Pics ({picsCount} Files)
                            </span>
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 font-bold">
                            ID Front: Verified ✓
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 font-bold">
                            ID Back: Verified ✓
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedGalleryUser(u)}
                          className="text-[11px] text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Open Full Gallery / Upload</span>
                        </button>
                      </div>

                      {/* Photo Cards Row */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {/* CNIC Back Photo */}
                        <div
                          onClick={() => {
                            setPreviewPhotoUrl(u.cnicBackPhotoPath || u.cnicPhotoPath || '');
                            setPreviewPhotoTitle('CNIC Back Photo (Verified ID)');
                          }}
                          className="p-1.5 rounded-xl bg-[#090D13] border border-slate-800 hover:border-amber-400 cursor-pointer group relative overflow-hidden"
                        >
                          <div className="h-20 bg-slate-900 rounded-lg flex items-center justify-center overflow-hidden">
                            {u.cnicBackPhotoPath ? (
                              <img
                                src={u.cnicBackPhotoPath}
                                alt="CNIC Back"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                            ) : (
                              <div className="text-center p-2">
                                <FileText className="w-6 h-6 text-slate-500 mx-auto" />
                                <span className="text-[10px] text-slate-400">CNIC Back</span>
                              </div>
                            )}
                          </div>
                          <div className="text-[10px] font-bold text-slate-300 mt-1 truncate">
                            CNIC Back Photo (Verified ID)
                          </div>
                        </div>

                        {/* CNIC Front Photo */}
                        <div
                          onClick={() => {
                            setPreviewPhotoUrl(u.cnicPhotoPath || u.cnicBackPhotoPath || '');
                            setPreviewPhotoTitle('CNIC Front Photo (Verified ID)');
                          }}
                          className="p-1.5 rounded-xl bg-[#090D13] border border-slate-800 hover:border-amber-400 cursor-pointer group relative overflow-hidden"
                        >
                          <div className="h-20 bg-slate-900 rounded-lg flex items-center justify-center overflow-hidden">
                            {u.cnicPhotoPath ? (
                              <img
                                src={u.cnicPhotoPath}
                                alt="CNIC Front"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                            ) : (
                              <div className="text-center p-2">
                                <FileText className="w-6 h-6 text-slate-500 mx-auto" />
                                <span className="text-[10px] text-slate-400">CNIC Front</span>
                              </div>
                            )}
                          </div>
                          <div className="text-[10px] font-bold text-slate-300 mt-1 truncate">
                            CNIC Front Photo (Verified ID)
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Package Selector Row (Per Screenshot 1: Green text + Apply Package select) */}
                    <div className="p-3 rounded-xl bg-[#0C121C] border border-slate-800/80 space-y-1.5 text-xs">
                      <div className="text-emerald-400 font-bold text-xs">
                        {u.isLifetimeFree
                          ? 'LIFETIME FREE VIP (Rs. 60,000 Plan - Never Expires)'
                          : `${u.packagePlan || 'Standard Active'} (${Math.max(
                              0,
                              Math.ceil(((u.activatedUntil || 0) - now) / 86400000)
                            )} Days Remaining)`}
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-slate-400 text-[11px] font-semibold">
                          Apply Package:
                        </span>
                        <select
                          value={u.isLifetimeFree ? 'LIFETIME' : u.packagePlan || 'MONTHLY'}
                          onChange={(e) => handleApplyPackage(u, e.target.value)}
                          className="px-3 py-1.5 rounded-lg bg-[#141C2B] border border-slate-700 text-amber-300 text-xs font-bold outline-none cursor-pointer focus:border-[#F5B738]"
                        >
                          <option value="LIFETIME">
                            Lifetime Free VIP Package — Rs. 60,000 (Lifetime Free (Never Expires))
                          </option>
                          <option value="MONTHLY">
                            1 Month Standard Package — Rs. 3,000 (30 Days)
                          </option>
                          <option value="QUARTERLY">
                            3 Months Business Package — Rs. 8,000 (90 Days)
                          </option>
                          <option value="HALF_YEARLY">
                            6 Months Pro Package — Rs. 15,000 (180 Days)
                          </option>
                          <option value="YEARLY">
                            1 Year Enterprise Package — Rs. 28,000 (365 Days)
                          </option>
                        </select>
                      </div>
                    </div>

                    {/* Action Buttons Row (Per Screenshot 1: Block, Lock App, Revoke VIP, +7 Days Trial, Logout Device, Allow CNIC, Trash) */}
                    <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-slate-800/80">
                      {/* Block */}
                      <button
                        type="button"
                        onClick={() => handleToggleBlock(u)}
                        className={`px-3 py-1.5 rounded-lg text-white font-bold text-xs shadow cursor-pointer ${
                          u.isBlocked ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'
                        }`}
                      >
                        {u.isBlocked ? 'Unblock' : 'Block'}
                      </button>

                      {/* Lock App */}
                      <button
                        type="button"
                        onClick={() => handleLockApp(u)}
                        className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow cursor-pointer"
                      >
                        Lock App
                      </button>

                      {/* Revoke VIP / Make VIP */}
                      <button
                        type="button"
                        onClick={() => handleToggleVip(u)}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-xs shadow cursor-pointer"
                      >
                        {u.isLifetimeFree ? 'Revoke VIP' : 'Make VIP'}
                      </button>

                      {/* +7 Days Trial */}
                      <button
                        type="button"
                        onClick={() => handleExtendTrial(u, 7)}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow cursor-pointer"
                      >
                        +7 Days Trial
                      </button>

                      {/* Logout Device */}
                      <button
                        type="button"
                        onClick={() => handleLogoutDevice(u)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 cursor-pointer"
                      >
                        Logout Device
                      </button>

                      {/* Allow CNIC */}
                      <button
                        type="button"
                        onClick={() => handleAllowCnic(u)}
                        className={`px-3 py-1.5 rounded-lg font-bold text-xs border cursor-pointer ${
                          u.allowSecondCnic
                            ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                        }`}
                      >
                        {u.allowSecondCnic ? 'CNIC Allowed ✓' : 'Allow CNIC'}
                      </button>

                      {/* Delete Client */}
                      <button
                        type="button"
                        onClick={() => handleDeleteUser(u)}
                        className="p-1.5 rounded-lg border border-rose-500/40 text-rose-400 hover:bg-rose-950/60 ml-auto cursor-pointer"
                        title="Delete Client Record"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 2: TOP MENU & PAGE CONTROLS (SCREENSHOT 4 EXACT DESIGN)         */}
      {/* =================================================================== */}
      {activeTab === 'PAGES' && (
        <div className="p-5 rounded-2xl bg-[#0B0F16] border border-[#2B3441] space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#F5B738]" />
                <span>Client App Top Scroll Menu & Pages Control</span>
              </h3>
              <p className="text-xs text-slate-400">
                Rename, hide/show, delete, or add custom standalone tabs. Syncs live to Supabase layout_config_v1.
              </p>
            </div>

            {/* + Add New Page / Tab Button (Per Screenshot 4) */}
            <button
              type="button"
              onClick={() => setShowAddTabModal(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-[#F5B738] hover:from-amber-400 hover:to-amber-500 text-black text-xs font-black flex items-center gap-1.5 shadow-lg shadow-amber-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ + Add New Page / Tab</span>
            </button>
          </div>

          {/* List of All Top Menu Tabs */}
          <div className="space-y-2">
            {allPageTabs.map((t, idx) => {
              const isEnabled = layoutConfig.enabledTabs?.[t.id] !== false;
              const currentTitle = layoutConfig.tabCustomTitles?.[t.id] ?? t.defaultTitle;

              return (
                <div
                  key={t.id}
                  className="p-3.5 rounded-xl bg-[#141A24] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-lg bg-slate-800 text-amber-400 font-mono font-bold flex items-center justify-center text-xs">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>{t.defaultTitle}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 font-mono text-slate-400">
                          {t.id}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        Status:{' '}
                        <strong className={isEnabled ? 'text-emerald-400' : 'text-slate-500'}>
                          {isEnabled ? 'ACTIVE ON CLIENT APP' : 'HIDDEN'}
                        </strong>
                      </span>
                    </div>
                  </div>

                  {/* Title Input & Controls */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-slate-400">Label:</span>
                      <input
                        type="text"
                        value={currentTitle}
                        onChange={(e) => handleUpdateTabTitle(t.id, e.target.value)}
                        placeholder="Custom title..."
                        className="px-2.5 py-1 rounded-lg bg-[#0C1017] border border-slate-700 text-xs text-amber-300 font-bold focus:border-[#F5B738] outline-none"
                      />
                    </div>

                    {/* Toggle Show/Hide Switch */}
                    <button
                      type="button"
                      onClick={() => handleToggleTabVisibility(t.id)}
                      className={`px-3 py-1 rounded-lg font-bold text-xs cursor-pointer ${
                        isEnabled
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500 hover:text-black'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {isEnabled ? 'Hide Tab' : 'Show Tab'}
                    </button>

                    {/* Delete Tab (Pushes to Backup Vault) */}
                    <button
                      type="button"
                      onClick={() => handleDeleteTab(t.id, currentTitle)}
                      className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 cursor-pointer"
                      title="Delete Tab from App (Saved to Backup Vault)"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 3: CLIENT SUPPORT INBOX                                         */}
      {/* =================================================================== */}
      {activeTab === 'INBOX' && (
        <div className="p-5 rounded-2xl bg-[#0B0F16] border border-[#2B3441] space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#F5B738]" />
                <span>Client Support Inbox & Verification Requests ({supportRequests.length})</span>
              </h3>
              <p className="text-xs text-slate-400">
                Clients ki taraf se anay walay messages, TID payment receipts aur lock reset requests:
              </p>
            </div>
          </div>

          <div className="space-y-2.5">
            {supportRequests.map((req) => (
              <div
                key={req.id}
                className="p-4 rounded-xl bg-[#141A24] border border-slate-800 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{req.clientName}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                      {req.requestType}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {new Date(req.createdAt).toLocaleString()}
                  </span>
                </div>

                <div className="text-slate-300 font-sans p-2 rounded-lg bg-[#0C1017] border border-slate-800">
                  {req.message}
                </div>

                <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
                  <div className="text-slate-400 font-mono text-[11px]">
                    Phone: <strong className="text-white">{req.phone}</strong> · CNIC: {req.cnic}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const target = users.find((u) => u.phone === req.phone);
                        if (target) {
                          handleApplyPackage(target, 'MONTHLY');
                        }
                        setSupportRequests(supportRequests.filter((r) => r.id !== req.id));
                        showToast(`Request approved & 1-Month activated for ${req.clientName}!`);
                      }}
                      className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer"
                    >
                      Approve & Activate
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSupportRequests(supportRequests.filter((r) => r.id !== req.id));
                        showToast('Request marked resolved.');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs cursor-pointer"
                    >
                      Mark Resolved
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 4: OFFICIAL DEFAULT SETTINGS (BANKS, PACKAGES & BRANDING)        */}
      {/* =================================================================== */}
      {activeTab === 'DEFAULTS' && (
        <div className="space-y-4">
          {/* Bank Accounts List */}
          <div className="p-4 rounded-xl bg-[#141A24] border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#F5B738]" />
              <span>Bank & EasyPaisa Payment Receiving Accounts ({bankAccounts.length})</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {bankAccounts.map((acc, i) => (
                <div
                  key={acc.id || i}
                  className="p-4 rounded-xl bg-[#0C1017] border border-slate-700 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{acc.bankName}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                      ACTIVE
                    </span>
                  </div>
                  <div className="space-y-1 font-mono">
                    <div className="text-amber-300 font-bold text-sm">
                      A/C: {acc.accountNumber}
                    </div>
                    <div className="text-slate-300">Title: {acc.accountTitle}</div>
                    <div className="text-slate-400 text-[11px]">
                      Branch: {acc.branchCode || 'All Pakistan'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Subscription Packages (Full Interactive CRUD & Discount Offers) */}
          <div className="p-4 rounded-xl bg-[#141A24] border border-slate-800 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2.5 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-[#F5B738]" />
                <span className="text-sm font-bold text-[#F5B738]">
                  Mobile App Subscription Packages ({packages.length})
                </span>
                {packages.some((p) => (p.discountPct && p.discountPct > 0) || (p.originalPriceRs && p.originalPriceRs > p.priceRs)) && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold flex items-center gap-1">
                    <Zap className="w-3 h-3 text-rose-400" />
                    <span>Special Discount Active</span>
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleOpenAddPkg}
                  className="px-3 py-1.5 rounded-lg bg-[#F5B738] hover:bg-amber-400 text-black text-xs font-bold flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Add Package</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowDiscountModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>⚡ Discount Offers</span>
                </button>
                <button
                  type="button"
                  onClick={handleRestoreStarterPackages}
                  title="Reset to official 3k, 8k, 16k, 31k, 60k packages"
                  className="px-2.5 py-1.5 rounded-lg bg-[#1C222B] hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-1 border border-slate-700 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Reset Default 5</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {packages.map((pkg, idx) => {
                const hasDiscount =
                  (pkg.discountPct && pkg.discountPct > 0) ||
                  (pkg.originalPriceRs && pkg.originalPriceRs > (pkg.priceRs ?? pkg.price ?? 0));
                const origPrice = pkg.originalPriceRs ?? pkg.priceRs ?? pkg.price ?? 0;
                const curPrice = pkg.priceRs ?? pkg.price ?? origPrice;
                const discPct = pkg.discountPct ?? (origPrice > curPrice ? Math.round(((origPrice - curPrice) / origPrice) * 100) : 0);

                return (
                  <div
                    key={pkg.id || idx}
                    className={`p-4 rounded-xl bg-[#0C1017] border ${
                      pkg.isActive === false
                        ? 'border-slate-800 opacity-60'
                        : hasDiscount
                        ? 'border-rose-500/40 shadow-lg shadow-rose-950/20'
                        : 'border-slate-700'
                    } space-y-3 text-xs relative flex flex-col justify-between`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-1.5">
                        <div>
                          <div className="font-black text-white text-sm flex items-center gap-1.5">
                            <span>{pkg.name}</span>
                            {pkg.isLifetime && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                                VIP
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono uppercase">
                            Plan: {pkg.planCode}
                          </span>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          {(pkg.badge || pkg.badgeText) && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500 text-black font-extrabold shadow-sm">
                              {pkg.badge || pkg.badgeText}
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              const next = packages.map((p) =>
                                p.id === pkg.id ? { ...p, isActive: p.isActive === false } : p
                              );
                              onUpdatePackages(next);
                            }}
                            className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                              pkg.isActive === false
                                ? 'bg-slate-800 text-slate-400 border border-slate-700'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {pkg.isActive === false ? 'PAUSED' : 'ACTIVE'}
                          </button>
                        </div>
                      </div>

                      {/* Pricing with Discount calculation */}
                      <div className="pt-1">
                        {hasDiscount ? (
                          <div className="space-y-1">
                            <div className="flex items-baseline gap-2 flex-wrap">
                              <span className="text-2xl font-black text-emerald-400">
                                Rs. {curPrice.toLocaleString()}
                              </span>
                              <span className="text-xs line-through text-slate-400">
                                Rs. {origPrice.toLocaleString()}
                              </span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-600 text-white font-black animate-pulse">
                                {discPct}% OFF
                              </span>
                            </div>
                            {pkg.discountOfferText && (
                              <div className="text-[11px] text-amber-300 font-semibold italic flex items-center gap-1">
                                <Zap className="w-3 h-3 text-amber-400 shrink-0" />
                                <span>{pkg.discountOfferText}</span>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="text-2xl font-black text-amber-400">
                            Rs. {curPrice.toLocaleString()}
                          </div>
                        )}
                        <div className="text-slate-400 text-[11px] mt-0.5">
                          Duration: {pkg.durationLabel || `${pkg.durationMonths} Month(s)`}
                        </div>
                      </div>

                      {/* Features */}
                      <ul className="space-y-1.5 text-slate-300 border-t border-slate-800/80 pt-2.5">
                        {(pkg.features || []).map((f, fi) => (
                          <li key={fi} className="flex items-start gap-1.5 text-[11px] leading-tight">
                            <Check className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{f}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Action Buttons: Edit, Discount, Delete */}
                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleOpenEditPkg(pkg)}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-[#1C222B] hover:bg-slate-800 text-amber-400 font-bold flex items-center justify-center gap-1 border border-slate-700 text-[11px] transition-colors cursor-pointer"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>Edit</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const disc = prompt(`Enter discount % for "${pkg.name}":`, String(pkg.discountPct || 20));
                          if (disc !== null) {
                            const val = Math.max(0, Math.min(100, Number(disc) || 0));
                            const orig = pkg.originalPriceRs ?? pkg.priceRs ?? pkg.price ?? 3000;
                            const newPrice = Math.round(orig * (1 - val / 100));
                            const next = packages.map((p) =>
                              p.id === pkg.id
                                ? {
                                    ...p,
                                    originalPriceRs: orig,
                                    priceRs: newPrice,
                                    price: newPrice,
                                    discountPct: val,
                                    discountOfferText: val > 0 ? `${val}% Special Discount` : '',
                                  }
                                : p
                            );
                            onUpdatePackages(next);
                            showToast(`${val}% discount set for ${pkg.name}!`);
                          }
                        }}
                        title="Set individual discount for this package"
                        className="py-1.5 px-2 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 font-bold flex items-center justify-center gap-1 border border-rose-800/50 text-[11px] transition-colors cursor-pointer"
                      >
                        <Percent className="w-3 h-3" />
                        <span>Disc</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPkgToDelete(pkg)}
                        className="py-1.5 px-2 rounded-lg bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white font-bold flex items-center justify-center border border-rose-500/30 text-[11px] transition-colors cursor-pointer"
                        title="Delete this package"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 5: BACKUP VAULT (SCREENSHOT 3 EXACT DESIGN)                     */}
      {/* =================================================================== */}
      {activeTab === 'BACKUP' && (
        <div className="p-5 rounded-2xl bg-[#0B0F16] border border-[#2B3441] space-y-4">
          {/* Header + Clear / Purge All Backup Button (Per Screenshot 3) */}
          <div className="flex items-center justify-between flex-wrap gap-3 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-amber-500 flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-rose-500" />
                <span>Admin Deleted Items Backup Vault</span>
              </h3>
              <p className="text-xs text-slate-400">
                Safeguard for deleted sections, profiles, and formulas. Restore anytime or permanently purge.
              </p>
            </div>

            {/* Clear / Purge All Backup Button */}
            <button
              type="button"
              onClick={() => {
                if (onClearAllBackup) {
                  onClearAllBackup();
                }
                showToast('Deleted Backup Vault cleared and permanently purged!');
              }}
              className="px-3.5 py-1.5 rounded-lg border border-rose-500/60 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 hover:text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
              <span>Clear / Purge All Backup</span>
            </button>
          </div>

          <div className="space-y-2">
            {deletedBackupVault.length === 0 ? (
              <div className="p-10 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
                Backup Vault is empty. No deleted items recorded.
              </div>
            ) : (
              deletedBackupVault.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-xl bg-[#141A24] border border-slate-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{item.title}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                        {item.category}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      Deleted: {new Date(item.deletedAt).toLocaleString()}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onRestoreBackupItem(item);
                      showToast(`Restored "${item.title}" successfully!`);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Restore</span>
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: ADD NEW STANDALONE PAGE / TAB (Per Screenshot 4)             */}
      {/* =================================================================== */}
      {showAddTabModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0F141C] border-2 border-[#F5B738] rounded-2xl p-5 text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
                <Plus className="w-4 h-4" />
                <span>+ + Add New Page / Tab for Client App</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddTabModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddNewTabSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Page / Tab Title (Aap ki pasand ka name):
                </label>
                <input
                  type="text"
                  required
                  value={newTabTitle}
                  onChange={(e) => {
                    setNewTabTitle(e.target.value);
                    if (!newTabId) {
                      setNewTabId(
                        e.target.value
                          .toUpperCase()
                          .replace(/[^A-Z0-9_]/g, '_')
                      );
                    }
                  }}
                  placeholder="e.g. Curtain Wall 3D, Store Stock, Special Design"
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Tab Identifier (ID Code):
                </label>
                <input
                  type="text"
                  required
                  value={newTabId}
                  onChange={(e) => setNewTabId(e.target.value.toUpperCase())}
                  placeholder="e.g. CURTAIN_WALL_3D"
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 font-mono text-amber-300 focus:border-[#F5B738] outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Select Tab Icon:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {['Layers', 'Sparkles', 'Box', 'FileText', 'Sliders', 'CreditCard', 'Key', 'MessageSquare'].map(
                    (ic) => (
                      <button
                        key={ic}
                        type="button"
                        onClick={() => setNewTabIcon(ic)}
                        className={`p-2 rounded-lg border text-center font-bold text-xs cursor-pointer ${
                          newTabIcon === ic
                            ? 'bg-[#F5B738] text-black border-[#F5B738]'
                            : 'bg-[#141A24] text-slate-300 border-slate-800'
                        }`}
                      >
                        {ic}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddTabModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-[#F5B738] text-black font-black hover:from-amber-400 hover:to-amber-500 shadow-md"
                >
                  Save & Publish New Tab
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: ADD CLIENT RECORD                                            */}
      {/* =================================================================== */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0F141C] border-2 border-[#F5B738] rounded-2xl p-5 text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
                <Plus className="w-4 h-4" />
                <span>+ Register New Client License Account</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddUserModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateClient} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Client Full Name:</label>
                  <input
                    type="text"
                    required
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="e.g. Tariq Mehmood"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Number:</label>
                  <input
                    type="text"
                    required
                    value={newUserPhone}
                    onChange={(e) => setNewUserPhone(e.target.value)}
                    placeholder="e.g. 0310-5524225"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">CNIC Number:</label>
                  <input
                    type="text"
                    value={newUserCnic}
                    onChange={(e) => setNewUserCnic(e.target.value)}
                    placeholder="e.g. 37405-0000000-0"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Email (Optional):</label>
                  <input
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="e.g. client@gmail.com"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Shop / Factory Address:</label>
                <input
                  type="text"
                  value={newUserShop}
                  onChange={(e) => setNewUserShop(e.target.value)}
                  placeholder="e.g. Boss Aluminium & Glass, Main Market"
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Subscription Tier:</label>
                <select
                  value={newUserTier}
                  onChange={(e) => setNewUserTier(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-amber-300 font-bold focus:border-[#F5B738] outline-none"
                >
                  <option value="LIFETIME_VIP">⭐ Lifetime Free VIP (Never Expires)</option>
                  <option value="MONTHLY">1 Month Standard (Rs. 3,000)</option>
                  <option value="QUARTERLY">3 Months Business (Rs. 8,000)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-[#F5B738] text-black font-black hover:from-amber-400 hover:to-amber-500 shadow-md"
                >
                  Save & Register Client
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: FULL GALLERY / PHOTO VIEWER                                  */}
      {/* =================================================================== */}
      {selectedGalleryUser && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-[#0F141C] border-2 border-amber-500/70 rounded-2xl p-5 text-white space-y-4 max-h-[90vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-[#F5B738] flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#F5B738]" />
                <span>Uploaded Documents Gallery: {selectedGalleryUser.name}</span>
              </h3>
              <button
                type="button"
                onClick={() => setSelectedGalleryUser(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* CNIC Front */}
                <div className="p-3 rounded-xl bg-[#0C1017] border border-slate-800 space-y-2">
                  <span className="text-xs font-bold text-amber-300">CNIC Front Photo</span>
                  <div className="h-44 bg-slate-900 rounded-lg overflow-hidden flex items-center justify-center">
                    {selectedGalleryUser.cnicPhotoPath ? (
                      <img
                        src={selectedGalleryUser.cnicPhotoPath}
                        alt="CNIC Front"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <span className="text-xs text-slate-500">No front photo uploaded</span>
                    )}
                  </div>
                </div>

                {/* CNIC Back */}
                <div className="p-3 rounded-xl bg-[#0C1017] border border-slate-800 space-y-2">
                  <span className="text-xs font-bold text-amber-300">CNIC Back Photo</span>
                  <div className="h-44 bg-slate-900 rounded-lg overflow-hidden flex items-center justify-center">
                    {selectedGalleryUser.cnicBackPhotoPath ? (
                      <img
                        src={selectedGalleryUser.cnicBackPhotoPath}
                        alt="CNIC Back"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <span className="text-xs text-slate-500">No back photo uploaded</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end border-t border-slate-800 pt-3">
              <button
                type="button"
                onClick={() => setSelectedGalleryUser(null)}
                className="px-4 py-2 rounded-xl bg-amber-500 text-black font-bold hover:bg-amber-400"
              >
                Close Gallery
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add / Edit Subscription Package */}
      {showPkgModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#141A24] border-2 border-amber-500/80 rounded-2xl max-w-xl w-full p-5 space-y-4 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black text-[#F5B738] flex items-center gap-2">
                <Package className="w-4 h-4 text-[#F5B738]" />
                <span>{editingPkgId ? 'Edit Subscription Package' : 'Create New Subscription Package'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowPkgModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs max-h-[75vh] overflow-y-auto pr-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Package Name:</label>
                  <input
                    type="text"
                    required
                    value={pkgName}
                    onChange={(e) => setPkgName(e.target.value)}
                    placeholder="e.g. 1 Month Standard Package"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Plan Code (Key):</label>
                  <input
                    type="text"
                    required
                    value={pkgPlanCode}
                    onChange={(e) => setPkgPlanCode(e.target.value.toUpperCase())}
                    placeholder="e.g. MONTHLY, QUARTERLY, YEARLY"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Duration (Months):</label>
                  <input
                    type="number"
                    min="1"
                    max="999"
                    value={pkgDurationMonths}
                    onChange={(e) => {
                      const m = Number(e.target.value) || 1;
                      setPkgDurationMonths(m);
                      if (!pkgDurationLabel || pkgDurationLabel.includes('Month')) {
                        setPkgDurationLabel(m >= 999 ? 'Lifetime Free (Never Expires)' : m === 12 ? '1 Year (365 Days)' : `${m} Month(s) (${m * 30} Days)`);
                      }
                    }}
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Duration Label (Shown to Client):</label>
                  <input
                    type="text"
                    value={pkgDurationLabel}
                    onChange={(e) => setPkgDurationLabel(e.target.value)}
                    placeholder="e.g. 1 Month (30 Days)"
                    className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white focus:border-[#F5B738] outline-none"
                  />
                </div>
              </div>

              {/* Pricing & Discount Calculations */}
              <div className="p-3.5 rounded-xl bg-[#0C1017] border border-slate-800 space-y-3">
                <div className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5">
                  <Percent className="w-3.5 h-3.5" />
                  <span>Pricing & Discount Offer Calculator</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 text-[11px] font-medium mb-1">Regular Price (Rs):</label>
                    <input
                      type="number"
                      min="0"
                      value={pkgOriginalPriceRs}
                      onChange={(e) => {
                        const orig = Number(e.target.value) || 0;
                        setPkgOriginalPriceRs(orig);
                        if (pkgDiscountPct > 0) {
                          setPkgPriceRs(Math.round(orig * (1 - pkgDiscountPct / 100)));
                        } else {
                          setPkgPriceRs(orig);
                        }
                      }}
                      className="w-full p-2.5 rounded-xl bg-[#141A24] border border-slate-700 text-white focus:border-amber-400 outline-none font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] font-medium mb-1">Discount %:</label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={pkgDiscountPct}
                      onChange={(e) => {
                        const pct = Math.max(0, Math.min(100, Number(e.target.value) || 0));
                        setPkgDiscountPct(pct);
                        if (pct > 0 && pkgOriginalPriceRs > 0) {
                          setPkgPriceRs(Math.round(pkgOriginalPriceRs * (1 - pct / 100)));
                        } else if (pct === 0) {
                          setPkgPriceRs(pkgOriginalPriceRs);
                        }
                      }}
                      className="w-full p-2.5 rounded-xl bg-[#141A24] border border-rose-500/50 text-rose-300 focus:border-rose-400 outline-none font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] font-medium mb-1">Final Price (Rs):</label>
                    <input
                      type="number"
                      min="0"
                      value={pkgPriceRs}
                      onChange={(e) => {
                        const p = Number(e.target.value) || 0;
                        setPkgPriceRs(p);
                        if (pkgOriginalPriceRs > p) {
                          setPkgDiscountPct(Math.round(((pkgOriginalPriceRs - p) / pkgOriginalPriceRs) * 100));
                        } else {
                          setPkgDiscountPct(0);
                        }
                      }}
                      className="w-full p-2.5 rounded-xl bg-[#141A24] border border-emerald-500/50 text-emerald-400 focus:border-emerald-400 outline-none font-black text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 text-[11px] font-medium mb-1">Special Discount Offer Text:</label>
                    <input
                      type="text"
                      value={pkgDiscountOfferText}
                      onChange={(e) => setPkgDiscountOfferText(e.target.value)}
                      placeholder="e.g. Eid 20% OFF (Limited Time Offer)"
                      className="w-full p-2 rounded-lg bg-[#141A24] border border-slate-700 text-amber-300 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 text-[11px] font-medium mb-1">Badge Text (Ribbon):</label>
                    <input
                      type="text"
                      value={pkgBadgeText}
                      onChange={(e) => setPkgBadgeText(e.target.value)}
                      placeholder="e.g. SAVE RS. 1,000 / POPULAR"
                      className="w-full p-2 rounded-lg bg-[#141A24] border border-slate-700 text-white outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-6 pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={pkgIsLifetime}
                    onChange={(e) => setPkgIsLifetime(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                  />
                  <span>Lifetime VIP Package</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={pkgIsActive}
                    onChange={(e) => setPkgIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-400"
                  />
                  <span>Active & Available to Clients</span>
                </label>
              </div>

              {/* Features List */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <label className="block text-slate-300 font-semibold">Included Features & Capabilities:</label>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {pkgFeatures.map((feat, fidx) => (
                    <div key={fidx} className="flex items-center gap-2 bg-[#0C1017] p-2 rounded-lg border border-slate-800">
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="flex-1 text-slate-200 text-[11px]">{feat}</span>
                      <button
                        type="button"
                        onClick={() => setPkgFeatures(pkgFeatures.filter((_, i) => i !== fidx))}
                        className="text-rose-400 hover:text-rose-300 p-0.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 pt-1">
                  <input
                    type="text"
                    value={newFeatureInput}
                    onChange={(e) => setNewFeatureInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (newFeatureInput.trim()) {
                          setPkgFeatures([...pkgFeatures, newFeatureInput.trim()]);
                          setNewFeatureInput('');
                        }
                      }
                    }}
                    placeholder="+ Add a new feature bullet point..."
                    className="flex-1 p-2 rounded-lg bg-[#090D13] border border-slate-700 text-white outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (newFeatureInput.trim()) {
                        setPkgFeatures([...pkgFeatures, newFeatureInput.trim()]);
                        setNewFeatureInput('');
                      }
                    }}
                    className="px-3 py-2 rounded-lg bg-[#1C222B] border border-amber-500 text-amber-400 font-bold hover:bg-amber-500 hover:text-black transition-colors"
                  >
                    + Add
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-slate-800 pt-3">
              <button
                type="button"
                onClick={() => setShowPkgModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSavePkg}
                className="px-5 py-2 rounded-xl bg-[#F5B738] text-black hover:bg-amber-400 text-xs font-black shadow-lg shadow-amber-500/20"
              >
                {editingPkgId ? 'Save Package Changes' : 'Create Package'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Global Discount Offer Campaign */}
      {showDiscountModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141A24] border-2 border-rose-500/80 rounded-2xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black text-rose-400 flex items-center gap-2">
                <Zap className="w-4 h-4 text-rose-400" />
                <span>Apply Special Discount Offer to Subscription Packages</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowDiscountModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <p className="text-slate-300 leading-relaxed">
                Yahan say aap saray subscription packages par aik sath <strong>Discount Offer</strong> laga saktay hain. Har package par original price kat kar new discounted price show ho gi!
              </p>

              {/* Quick Preset Buttons */}
              <div className="space-y-1.5">
                <label className="block text-slate-400 text-[11px] font-semibold">Quick Select Discount %:</label>
                <div className="grid grid-cols-6 gap-2">
                  {[10, 15, 20, 25, 30, 50].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setGlobalDiscountPct(pct)}
                      className={`py-2 rounded-lg font-black text-xs transition-all ${
                        globalDiscountPct === pct
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-900/40 ring-2 ring-rose-400'
                          : 'bg-[#0C1017] border border-slate-700 text-slate-200 hover:border-rose-400'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Discount Percentage (%):</label>
                <input
                  type="number"
                  min="1"
                  max="90"
                  value={globalDiscountPct}
                  onChange={(e) => setGlobalDiscountPct(Math.max(1, Math.min(90, Number(e.target.value) || 0)))}
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-rose-500/50 text-rose-300 text-base font-black outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Offer Campaign Title:</label>
                <input
                  type="text"
                  value={globalOfferTitle}
                  onChange={(e) => setGlobalOfferTitle(e.target.value)}
                  placeholder="e.g. Ramzan & Eid Special 20% Discount Offer"
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Announcement Message for App Layout:</label>
                <textarea
                  rows={2}
                  value={globalOfferMsg}
                  onChange={(e) => setGlobalOfferMsg(e.target.value)}
                  placeholder="Message explaining payment process & discount..."
                  className="w-full p-2.5 rounded-xl bg-[#090D13] border border-slate-700 text-white outline-none"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer p-2.5 rounded-xl bg-[#0C1017] border border-slate-800 text-slate-200">
                <input
                  type="checkbox"
                  checked={globalSyncToBanner}
                  onChange={(e) => setGlobalSyncToBanner(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-500 focus:ring-rose-400"
                />
                <span className="text-[11px] font-semibold">
                  Push to Live Broadcast Banner in App Layout so all users see the offer banner immediately!
                </span>
              </label>

              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleClearGlobalDiscounts}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                >
                  Clear Discounts (Reset)
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowDiscountModal(false)}
                    className="px-3.5 py-2 rounded-xl bg-[#1C222B] text-slate-300 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleApplyGlobalDiscount}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white text-xs font-black shadow-lg shadow-rose-950/50"
                  >
                    ⚡ Apply {globalDiscountPct}% Discount Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Delete Package Confirmation */}
      {pkgToDelete && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141A24] border-2 border-rose-500 rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <Trash2 className="w-4 h-4" />
              <span>Delete Subscription Package?</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Kya aap waqai <strong>"{pkgToDelete.name}"</strong> (Rs. {pkgToDelete.priceRs ?? pkgToDelete.price}) package ko delete karna chahtay hain?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setPkgToDelete(null)}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeletePkgConfirm}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
