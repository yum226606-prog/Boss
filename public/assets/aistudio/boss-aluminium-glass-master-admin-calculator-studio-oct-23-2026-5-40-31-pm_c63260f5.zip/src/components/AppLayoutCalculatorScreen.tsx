import React, { useState } from 'react';
import {
  ArrowLeftRight,
  Bookmark,
  CheckCircle2,
  CloudUpload,
  Download,
  Eye,
  EyeOff,
  FileText,
  History,
  Layers,
  Lock,
  Plus,
  Printer,
  RefreshCw,
  Ruler,
  Scissors,
  Search,
  Settings,
  Share2,
  Trash2,
  Unlock,
  Upload,
  Edit2,
  X,
  Check,
  Zap,
  Tag,
  Percent,
  Copy,
  Phone,
  Radio,
} from 'lucide-react';
import {
  AluminiumCostRow,
  BossTab,
  ClientAppLayoutControlConfig,
  CutPiece,
  DoorItem,
  DragDropBlueprint,
  ExtraPiece,
  FixFrameItem,
  FormulaCategorySettings,
  FSectionFormula,
  GlassCostLine,
  GlassCutResult,
  GlassFormula,
  MeasurementUnit,
  OpenableWindowItem,
  QuotationResult,
  SavedQuotation,
  SlidingDoorFormulaSettings,
  SlidingDoorItem,
  WindowFormulaSettings,
  WindowItem,
  DeletedBackupItem,
  AppOfferBanner,
  SubscriptionPackageConfig,
  BankAccountConfig,
} from '../types/bossModels';
import {
  barLengthsFor,
  computeBlueprintWindowPieces,
  computeGlassCutsForState,
  computeOpenablePieces,
  computeSlidingDoorPieces,
  computeSlidingWindowPieces,
  formatDim,
  formatDimValueOnly,
  packSection,
  parseDimToInches,
  pricingGaugeForSection,
  toDotSutar,
  unitLabel,
} from '../utils/bossCalculationEngine';
import {
  DEFAULT_GLASS_COLORS_5MM,
  DEFAULT_GLASS_COLORS_8MM,
  DEFAULT_SECTIONS,
  GAUGES,
  SECTION_LABELS,
} from '../utils/bossDefaultRates';

interface AppLayoutCalculatorScreenProps {
  currentTab: BossTab;
  onSelectTab: (tab: BossTab) => void;
  ctxGauge: string;
  ctxGaugeMode: 'ON' | 'OFF';
  onSetCtxGauge: (g: string, mode: 'ON' | 'OFF') => void;
  ctxColor: string;
  onSetCtxColor: (c: string) => void;
  ctxFrameType: string;
  onSetCtxFrameType: (ft: string) => void;
  ctxGlassMode: 'ON' | 'OFF';
  ctxGlassGauge: string;
  ctxGlassColor: string;
  onSetCtxGlass: (g: string, c: string, mode: 'ON' | 'OFF') => void;
  availableColors: string[];
  onAddColor: (c: string) => void;
  onDeleteColor?: (c: string) => void;
  onEditColor?: (oldCol: string, newCol: string) => void;
  customSections: string[];
  onAddCustomSection: (sec: string, rate: number) => void;
  onDeleteSection?: (sec: string) => void;
  onAddCustomSectionPair: (s1: string, r1: number, s2: string, r2: number) => string;
  onAddGlassColor?: (gauge: string, color: string, rate: number) => void;
  onDeleteGlassColor?: (gauge: string, color: string) => void;
  deletedBackupVault?: DeletedBackupItem[];
  onRestoreBackupItem?: (id: string) => void;
  windows: WindowItem[];
  onUpdateWindows: (list: WindowItem[]) => void;
  doors: DoorItem[];
  onUpdateDoors: (list: DoorItem[]) => void;
  fixframes: FixFrameItem[];
  onUpdateFixFrames: (list: FixFrameItem[]) => void;
  openableWindows: OpenableWindowItem[];
  onUpdateOpenableWindows: (list: OpenableWindowItem[]) => void;
  slidingDoors: SlidingDoorItem[];
  onUpdateSlidingDoors: (list: SlidingDoorItem[]) => void;
  projectExtras: ExtraPiece[];
  onUpdateProjectExtras: (list: ExtraPiece[]) => void;
  rates: Record<string, Record<string, Record<string, number>>>;
  onUpdateSectionRate: (gauge: string, color: string, sec: string, rate: number) => void;
  glassRates: Record<string, Record<string, number>>;
  onUpdateGlassRate: (gauge: string, color: string, rate: number) => void;
  hiddenSections: string[];
  onToggleHideSection: (sec: string) => void;
  onUnhideAllSections: () => void;
  windowFormula: WindowFormulaSettings;
  slidingDoorFormula: SlidingDoorFormulaSettings;
  doorFormula: FormulaCategorySettings;
  fixFormula: FormulaCategorySettings;
  openwinFormula: FormulaCategorySettings;
  fSectionFormula: FSectionFormula;
  glassFormulas: Record<string, GlassFormula>;
  measurementUnit: MeasurementUnit;
  onSetMeasurementUnit: (u: MeasurementUnit) => void;
  glassFittingOption: 'FIX_RUBBER' | 'U_PVC';
  onSetGlassFittingOption: (opt: 'FIX_RUBBER' | 'U_PVC') => void;
  companyName: string;
  companyTagline: string;
  companyAddress: string;
  companyPhone: string;
  companyNtn: string;
  onUpdateCompanyInfo: (info: {
    name: string;
    tagline: string;
    address: string;
    phone: string;
    ntn: string;
  }) => void;
  customerName: string;
  customerPhone: string;
  onSetCustomerInfo: (name: string, phone: string) => void;
  hardwareRate: number;
  markupPct: number;
  transportRent: number;
  labourCost: number;
  onUpdateDefaults: (hw: number, mp: number, tr: number, lc: number) => void;
  savedQuotations: SavedQuotation[];
  onSaveQuotationHistory: (q: SavedQuotation) => void;
  onDeleteQuotationHistory: (id: number) => void;
  onRestoreQuotation: (q: SavedQuotation) => void;
  onOpenSettingsTab: () => void;
  blueprints: DragDropBlueprint[];
  onClearAllRates: () => void;
  onRestoreDefaultRates: () => void;
  onOpenThemeStudio: () => void;
  mainLogoUrl: string;
  onUpdateMainLogoUrl?: (url: string) => void;
  letterheadBgUrl: string;
  onUpdateLetterheadBgUrl?: (url: string) => void;
  onRestoreDefaultBrandingAssets?: () => void;
  layoutConfig: ClientAppLayoutControlConfig;
  onUpdateLayoutConfig?: (cfg: ClientAppLayoutControlConfig) => void;
  onExportFullBackup?: () => void;
  onImportFullBackup?: (jsonStr: string) => boolean;
  onPushFullConfigToCloud?: () => Promise<{ ok: boolean; message: string }>;
  activeOffer?: AppOfferBanner | null;
  onSaveOffer?: (offer: AppOfferBanner | null) => void;
  packages?: SubscriptionPackageConfig[];
  onUpdatePackages?: (pkgs: SubscriptionPackageConfig[]) => void;
  bankAccounts?: BankAccountConfig[];
}

export const AppLayoutCalculatorScreen: React.FC<AppLayoutCalculatorScreenProps> = (props) => {
  const {
    currentTab,
    onSelectTab,
    ctxGauge,
    ctxGaugeMode,
    onSetCtxGauge,
    ctxColor,
    onSetCtxColor,
    ctxFrameType,
    onSetCtxFrameType,
    ctxGlassMode,
    ctxGlassGauge,
    ctxGlassColor,
    onSetCtxGlass,
    availableColors,
    onAddColor,
    onDeleteColor = () => {},
    onEditColor = () => {},
    customSections,
    onAddCustomSection,
    onDeleteSection = () => {},
    onAddCustomSectionPair,
    onAddGlassColor = () => {},
    onDeleteGlassColor = () => {},
    deletedBackupVault = [],
    onRestoreBackupItem = () => {},
    windows,
    onUpdateWindows,
    doors,
    onUpdateDoors,
    fixframes,
    onUpdateFixFrames,
    openableWindows,
    onUpdateOpenableWindows,
    slidingDoors,
    onUpdateSlidingDoors,
    projectExtras,
    onUpdateProjectExtras,
    rates,
    onUpdateSectionRate,
    glassRates,
    onUpdateGlassRate,
    hiddenSections,
    onToggleHideSection,
    onUnhideAllSections,
    windowFormula,
    slidingDoorFormula,
    doorFormula,
    fixFormula,
    openwinFormula,
    fSectionFormula,
    glassFormulas,
    measurementUnit,
    onSetMeasurementUnit,
    glassFittingOption,
    onSetGlassFittingOption,
    companyName,
    companyTagline,
    companyAddress,
    companyPhone,
    companyNtn,
    onUpdateCompanyInfo,
    customerName,
    customerPhone,
    onSetCustomerInfo,
    hardwareRate,
    markupPct,
    transportRent,
    labourCost,
    onUpdateDefaults,
    savedQuotations,
    onSaveQuotationHistory,
    onDeleteQuotationHistory,
    onRestoreQuotation,
    onOpenSettingsTab,
    blueprints,
    onClearAllRates,
    onRestoreDefaultRates,
    onOpenThemeStudio,
    mainLogoUrl,
    onUpdateMainLogoUrl = () => {},
    letterheadBgUrl,
    onUpdateLetterheadBgUrl = () => {},
    onRestoreDefaultBrandingAssets = () => {},
    layoutConfig,
    onUpdateLayoutConfig = () => {},
    onExportFullBackup = () => {},
    onImportFullBackup = () => false,
    onPushFullConfigToCloud,
    activeOffer,
    onSaveOffer,
    packages = [],
    onUpdatePackages,
    bankAccounts = [],
  } = props;

  const [syncingCloud, setSyncingCloud] = useState(false);
  const [doorSubTab, setDoorSubTab] = useState<'DOORS' | 'FIX' | 'OP_WIN' | 'SLIDING'>('DOORS');
  const [settingsNotice, setSettingsNotice] = useState<string | null>(null);
  const [showPackagesModal, setShowPackagesModal] = useState(false);
  const [copiedBankId, setCopiedBankId] = useState<string | null>(null);
  const [dismissedBannerId, setDismissedBannerId] = useState<string | null>(null);

  const showSettingsToast = (msg: string) => {
    setSettingsNotice(msg);
    setTimeout(() => setSettingsNotice(null), 3200);
  };

  const handleImageFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    cb: (dataUrl: string) => void,
    label: string
  ) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        cb(reader.result);
        showSettingsToast(`${label} updated!`);
      }
    };
    reader.readAsDataURL(f);
    e.target.value = '';
  };

  // Active Shop Logo for Quotation & Charts (falls back to Official Golden Lion Main Icon if no custom Shop Logo is set)
  const activeShopLogoUrl =
    layoutConfig.shopLogoUrl && layoutConfig.shopLogoUrl.trim().length > 0
      ? layoutConfig.shopLogoUrl
      : mainLogoUrl;

  // Dynamic 5mm & 8mm Glass Colors from live glassRates (supports separate Add & Delete for 5mm and 8mm!)
  const glassColors5mm =
    Object.keys(glassRates['5'] || {}).length > 0
      ? Object.keys(glassRates['5'])
      : DEFAULT_GLASS_COLORS_5MM;
  const glassColors8mm =
    Object.keys(glassRates['8'] || {}).length > 0
      ? Object.keys(glassRates['8'])
      : DEFAULT_GLASS_COLORS_8MM;
  const deletedSecs = layoutConfig.deletedSections || [];

  // Reusable Per-Frame Gauge Option Button & Glass + Glass Color Option Button (SINGLE CLEAN OPTION BUTTONS - NO DUPLICATES!)
  // Unlocks automatically when Top Bar Main Gauge or Main Glass is turned OFF!
  const renderFrameGaugeAndGlassControls = (params: {
    sectionGauge: string;
    onChangeGauge: (g: string) => void;
    glassEnabled: boolean;
    onChangeGlassEnabled: (en: boolean) => void;
    glassGauge: string;
    glassColor: string;
    onChangeGlassSpec: (g: string, col: string) => void;
  }) => {
    const isGaugeLocked = ctxGaugeMode === 'ON';
    const isGlassLocked = ctxGlassMode === 'ON';
    const activeGauge = isGaugeLocked ? ctxGauge : params.sectionGauge || '1.6';
    const activeGlassGauge = isGlassLocked ? ctxGlassGauge : params.glassGauge || '5';
    const activeGlassColor = isGlassLocked ? ctxGlassColor : params.glassColor || 'CLEAR';
    const glassColorList = activeGlassGauge === '8' ? glassColors8mm : glassColors5mm;

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
        {/* 1. Single Per-Frame Gauge Option Button */}
        <div
          className={`p-2 rounded-lg border text-xs flex items-center justify-between gap-2 ${
            isGaugeLocked
              ? 'bg-[#0C0F14]/80 border-slate-800'
              : 'bg-[#0C0F14] border-amber-500/60'
          }`}
        >
          <div className="flex items-center gap-1.5 min-w-0">
            <button
              type="button"
              onClick={() =>
                onSetCtxGauge(ctxGauge, isGaugeLocked ? 'OFF' : 'ON')
              }
              className={`p-1 rounded transition-colors ${
                isGaugeLocked
                  ? 'bg-slate-800 text-slate-400 hover:text-[#F5B738]'
                  : 'bg-amber-500/20 text-[#F5B738]'
              }`}
              title={
                isGaugeLocked
                  ? 'Main Gauge ON — Click to Unlock Separate Gauge'
                  : 'Separate Gauge Unlocked — Click to Lock to Main Gauge'
              }
            >
              {isGaugeLocked ? (
                <Lock className="w-3.5 h-3.5" />
              ) : (
                <Unlock className="w-3.5 h-3.5" />
              )}
            </button>
            <span className="font-semibold text-slate-300 truncate">Gauge:</span>
          </div>

          <select
            disabled={isGaugeLocked}
            value={activeGauge}
            onChange={(e) => params.onChangeGauge(e.target.value)}
            className="px-2.5 py-1 rounded bg-[#1C222B] border border-slate-700 text-xs font-mono font-bold text-[#F5B738] disabled:opacity-55 cursor-pointer"
          >
            {GAUGES.map((g) => (
              <option key={g} value={g}>
                {g} mm
              </option>
            ))}
          </select>
        </div>

        {/* 2. Single Per-Frame Glass MM & Glass Color Option Button */}
        <div
          className={`p-2 rounded-lg border text-xs flex items-center justify-between gap-1.5 ${
            isGlassLocked
              ? 'bg-[#0C0F14]/80 border-slate-800'
              : 'bg-[#0C0F14] border-sky-500/60'
          }`}
        >
          <div className="flex items-center gap-1.5 min-w-0">
            <button
              type="button"
              onClick={() =>
                onSetCtxGlass(ctxGlassGauge, ctxGlassColor, isGlassLocked ? 'OFF' : 'ON')
              }
              className={`p-1 rounded transition-colors ${
                isGlassLocked
                  ? 'bg-slate-800 text-slate-400 hover:text-sky-300'
                  : 'bg-sky-500/20 text-sky-300'
              }`}
              title={
                isGlassLocked
                  ? 'Main Glass ON — Click to Unlock Separate Glass'
                  : 'Separate Glass Unlocked — Click to Lock to Main Glass'
              }
            >
              {isGlassLocked ? (
                <Lock className="w-3.5 h-3.5" />
              ) : (
                <Unlock className="w-3.5 h-3.5" />
              )}
            </button>
            <input
              type="checkbox"
              checked={params.glassEnabled}
              onChange={(e) => params.onChangeGlassEnabled(e.target.checked)}
              className="accent-[#F5B738] cursor-pointer"
              title="Enable / Disable Glass for this frame"
            />
            <span className="font-semibold text-slate-300 truncate">Glass:</span>
          </div>

          {params.glassEnabled ? (
            <div className="flex items-center gap-1">
              <select
                disabled={isGlassLocked}
                value={activeGlassGauge}
                onChange={(e) => {
                  const gm = e.target.value;
                  const nextColors = gm === '8' ? glassColors8mm : glassColors5mm;
                  const validColor = nextColors.includes(activeGlassColor)
                    ? activeGlassColor
                    : nextColors[0] || 'CLEAR';
                  params.onChangeGlassSpec(gm, validColor);
                }}
                className="px-1.5 py-1 rounded bg-[#1C222B] border border-slate-700 text-[11px] font-mono font-bold text-sky-300 disabled:opacity-55 cursor-pointer"
              >
                <option value="5">5mm</option>
                <option value="8">8mm</option>
              </select>

              <select
                disabled={isGlassLocked}
                value={activeGlassColor}
                onChange={(e) => params.onChangeGlassSpec(activeGlassGauge, e.target.value)}
                className="px-2 py-1 rounded bg-[#1C222B] border border-slate-700 text-[11px] font-bold text-amber-200 disabled:opacity-55 cursor-pointer max-w-[110px]"
              >
                {glassColorList.map((gc) => (
                  <option key={gc} value={gc}>
                    {gc}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <span className="text-[11px] font-bold text-rose-400">OFF (No Glass)</span>
          )}
        </div>
      </div>
    );
  };
  const [showCompareCF, setShowCompareCF] = useState(false);
  const [showAddPairModal, setShowAddPairModal] = useState(false);
  const [confirmClearRates, setConfirmClearRates] = useState(false);
  const [pairSec1, setPairSec1] = useState('');
  const [pairRate1, setPairRate1] = useState('750');
  const [pairSec2, setPairSec2] = useState('');
  const [pairRate2, setPairRate2] = useState('850');

  // Extra Piece Form State
  const [extraSec, setExtraSec] = useState('M23');
  const [extraLenFt, setExtraLenFt] = useState('10');
  const [extraQty, setExtraQty] = useState('1');
  const [extraGauge, setExtraGauge] = useState(ctxGauge);

  // Rates & Settings Sub-State
  const [rateGaugeTab, setRateGaugeTab] = useState(ctxGauge || '1.6');
  const [rateColorTab, setRateColorTab] = useState(ctxColor || 'DULL');
  const [rateSearch, setRateSearch] = useState('');
  const [newSecCodeInput, setNewSecCodeInput] = useState('');
  const [newSecRateInput, setNewSecRateInput] = useState('750');
  const [newColorInput, setNewColorInput] = useState('');
  const [editingColorName, setEditingColorName] = useState<string | null>(null);
  const [editingColorVal, setEditingColorVal] = useState('');
  const [newGlass5Color, setNewGlass5Color] = useState('');
  const [newGlass5Rate, setNewGlass5Rate] = useState('210');
  const [newGlass8Color, setNewGlass8Color] = useState('');
  const [newGlass8Rate, setNewGlass8Rate] = useState('340');
  const [historySearch, setHistorySearch] = useState('');

  // Compute all cut pieces for current state (or override frameType C vs F)
  const resolveOuterFrameSection = (
    currentOuter: string,
    targetFrameType: string | null = ctxFrameType !== 'OFF' ? ctxFrameType : null
  ) => {
    const pairMapF: Record<string, string> = {
      D54A: 'D54F',
      D54: 'D54F',
      D51: 'D51F',
      D51A: 'D51F',
      D42: 'D42F',
      D45: 'D45F',
      D45A: 'D45F',
    };
    const pairMapC: Record<string, string> = {
      D54F: 'D54A',
      D51F: 'D51A',
      D42F: 'D42',
      D45F: 'D45A',
    };
    if (targetFrameType) {
      const up = currentOuter.toUpperCase();
      if (targetFrameType === 'F') {
        return pairMapF[up] || (up.endsWith('F') ? currentOuter : `${currentOuter}F`);
      }
      if (targetFrameType === 'C') {
        if (!up.endsWith('F')) {
          return currentOuter;
        }
        return pairMapC[up] || currentOuter.replace(/f$/i, '');
      }
      return targetFrameType;
    }
    return currentOuter;
  };

  const getAllCutPieces = (overrideFrameType: string | null = null): CutPiece[] => {
    const all: CutPiece[] = [];
    const targetFt =
      overrideFrameType === 'OFF'
        ? null
        : overrideFrameType !== null
        ? overrideFrameType
        : ctxFrameType !== 'OFF'
        ? ctxFrameType
        : null;

    const masterGaugeActive = ctxGaugeMode === 'ON';

    const resolveOuter = (currentOuter: string) =>
      resolveOuterFrameSection(currentOuter, targetFt);

    windows.forEach((w, idx) => {
      const effFt = targetFt || (w.frameType ? w.frameType : 'C');
      const effGauge = masterGaugeActive ? ctxGauge : w.sectionGauge;
      const winWithEff = { ...w, frameType: effFt, sectionGauge: effGauge };
      const matchedBp = blueprints.find(
        (b) => b.id === w.blueprintId || b.id === w.frameType || b.name === w.blueprintName
      );
      if (matchedBp) {
        const src = `Window #${idx + 1} · ${matchedBp.name} (${w.panelCount} Palay)`;
        computeBlueprintWindowPieces(winWithEff, matchedBp, windowFormula).forEach((p) => {
          all.push({
            ...p,
            source: src,
            gauge: p.section === 'D29' || p.section === 'D31' ? '1.2' : p.gauge || effGauge,
          });
        });
      } else {
        const src = `Window #${idx + 1} (${w.panelCount} Palay)`;
        computeSlidingWindowPieces(winWithEff, effFt, windowFormula, fSectionFormula).forEach((p) => {
          all.push({ ...p, source: src, gauge: p.section === 'D29' || p.section === 'D31' ? '1.2' : effGauge });
        });
      }
    });

    doors.forEach((d, idx) => {
      const src = `Door #${idx + 1}`;
      const effOuter = resolveOuter(d.outer);
      const effGauge = masterGaugeActive ? ctxGauge : d.sectionGauge;
      computeOpenablePieces(
        d.width,
        d.height,
        d.qty,
        effOuter,
        'door',
        doorFormula,
        d.extras,
        effGauge,
        fSectionFormula,
        d.d59Qty,
        d.d59aQty,
        d.d52Qty
      ).forEach((p) => all.push({ ...p, source: src, gauge: effGauge }));
    });

    fixframes.forEach((f, idx) => {
      const src = `Fix Frame #${idx + 1}`;
      const effOuter = resolveOuter(f.outer);
      const effGauge = masterGaugeActive ? ctxGauge : f.sectionGauge;
      computeOpenablePieces(
        f.width,
        f.height,
        f.qty,
        effOuter,
        'fix',
        fixFormula,
        f.extras,
        effGauge,
        fSectionFormula,
        f.d59Qty,
        f.d59aQty,
        f.d52Qty
      ).forEach((p) => all.push({ ...p, source: src, gauge: effGauge }));
    });

    openableWindows.forEach((op, idx) => {
      const src = `Openable Window #${idx + 1}`;
      const effOuter = resolveOuter(op.outer);
      const effGauge = masterGaugeActive ? ctxGauge : op.sectionGauge;
      computeOpenablePieces(
        op.width,
        op.height,
        op.qty,
        effOuter,
        'openwin',
        openwinFormula,
        op.extras,
        effGauge,
        fSectionFormula,
        op.d59Qty,
        op.d59aQty,
        op.d52Qty
      ).forEach((p) => all.push({ ...p, source: src, gauge: effGauge }));
    });

    slidingDoors.forEach((sd, idx) => {
      const src = `Sliding Door #${idx + 1} (${sd.panelCount} Palay)`;
      const effOuter = targetFt ? (targetFt === 'F' ? 'F' : targetFt === 'C' ? 'NORMAL' : targetFt) : sd.outer;
      const effGauge = masterGaugeActive ? ctxGauge : sd.sectionGauge;
      computeSlidingDoorPieces(
        { ...sd, outer: effOuter, sectionGauge: effGauge },
        slidingDoorFormula,
        fSectionFormula
      ).forEach((p) => all.push({ ...p, source: src, gauge: p.section === 'D31' ? '1.2' : effGauge }));
    });

    projectExtras.forEach((ex, idx) => {
      if (ex.lengthFt > 0 && ex.qty > 0) {
        const effGauge = masterGaugeActive ? ctxGauge : ex.gauge || ctxGauge;
        all.push({
          section: ex.section,
          length: ex.lengthFt * 12.0,
          qty: ex.qty,
          source: `Extra Piece #${idx + 1}`,
          label: `${ex.section} Extra profile (${ex.lengthFt} ft)`,
          gauge: effGauge,
        });
      }
    });

    return all;
  };

  const glassCuts = computeGlassCutsForState({
    windows,
    doors,
    fixframes,
    openableWindows,
    slidingDoors,
    glassFormulas,
    windowFormula,
    glassFittingOption,
    measurementUnit,
    ctxGlassMode,
    ctxGlassGauge,
    ctxGlassColor,
  });

  const calculateQuotation = (overrideFt: string = ctxFrameType): QuotationResult => {
    const visiblePieces = getAllCutPieces(overrideFt).filter(
      (p) => !hiddenSections.includes(p.section) && !deletedSecs.includes(p.section)
    );
    const buckets: Record<string, CutPiece[]> = {};
    visiblePieces.forEach((p) => {
      const effectiveGauge = p.gauge || ctxGauge;
      const pGauge = pricingGaugeForSection(p.section, effectiveGauge);
      const key = `${p.section}|${pGauge}`;
      if (!buckets[key]) buckets[key] = [];
      buckets[key].push(p);
    });

    const alumRows: AluminiumCostRow[] = [];
    let alumSubtotal = 0;

    Object.entries(buckets).forEach(([key, pieces]) => {
      const [sec, g] = key.split('|');
      const packed = packSection(pieces, barLengthsFor(sec));
      let totalBars = 0;
      let totalFt = 0;
      Object.entries(packed.tally).forEach(([lenStr, info]) => {
        totalBars += info.count;
        totalFt += info.count * Number(lenStr);
      });
      const rate = rates[g]?.[ctxColor]?.[sec] ?? rates['1.2']?.['DULL']?.[sec] ?? 0;
      const cost = totalFt * rate;
      if (totalBars > 0) {
        alumRows.push({
          section: sec,
          gauge: g,
          bars: totalBars,
          totalFt,
          ratePerFt: rate,
          cost,
        });
        alumSubtotal += cost;
      }
    });

    // Discount (%) deduction from Aluminium Subtotal (Replaces Markup %)
    const discountAmount = alumSubtotal * (Math.max(0, markupPct) / 100.0);
    const alumWithMarkup = Math.max(0, alumSubtotal - discountAmount);

    const totalUnits =
      windows.reduce((s, i) => s + i.qty, 0) +
      doors.reduce((s, i) => s + i.qty, 0) +
      fixframes.reduce((s, i) => s + i.qty, 0) +
      openableWindows.reduce((s, i) => s + i.qty, 0) +
      slidingDoors.reduce((s, i) => s + i.qty, 0);

    const hardwareTotal = layoutConfig.showHardwareRow ? totalUnits * hardwareRate : 0;

    const glassGroupMap: Record<string, { sqft: number; rate: number }> = {};
    glassCuts.forEach((cut) => {
      const key = `${cut.glassGauge}mm ${cut.glassColor}`;
      const rate = glassRates[cut.glassGauge]?.[cut.glassColor] ?? 240;
      const cur = glassGroupMap[key] || { sqft: 0, rate };
      glassGroupMap[key] = { sqft: cur.sqft + cut.sqft, rate };
    });

    const glassLines: GlassCostLine[] = Object.entries(glassGroupMap).map(([key, val]) => ({
      description: `Glass ${key}`,
      sqft: val.sqft,
      rate: val.rate,
      total: val.sqft * val.rate,
    }));

    const glassTotal = glassLines.reduce((s, l) => s + l.total, 0);
    const effTransport = layoutConfig.showTransportRow ? transportRent : 0;
    const effLabour = layoutConfig.showLabourRow ? labourCost : 0;
    const grandTotal = alumWithMarkup + hardwareTotal + glassTotal + effTransport + effLabour;

    return {
      aluminiumRows: alumRows,
      alumTotal: alumSubtotal,
      alumWithMarkup,
      markupPct,
      totalUnits,
      hardwareTotal,
      glassTotal,
      glassLines,
      transportRent: effTransport,
      labourCost: effLabour,
      grandTotal,
    };
  };

  const allPiecesVisible = getAllCutPieces().filter((p) => !hiddenSections.includes(p.section));
  const sectionPiecesMap: Record<string, CutPiece[]> = {};
  allPiecesVisible.forEach((p) => {
    if (!sectionPiecesMap[p.section]) sectionPiecesMap[p.section] = [];
    sectionPiecesMap[p.section].push(p);
  });

  const activeQuote = calculateQuotation(ctxFrameType);
  const quoteC = calculateQuotation('C');
  const quoteF = calculateQuotation('F');

  const totalGlassPieces = glassCuts.reduce((sum, g) => sum + g.pieces, 0);
  const totalGlassSqFt = glassCuts.reduce((sum, g) => sum + g.sqft, 0);

  // High-Resolution PNG Image Generator & Native Share / Download for Quotation & All Charts
  const handleShareChartAsPng = async (
    chartType: 'CUTTING' | 'LENGTH' | 'GLASS' | 'QUOTATION'
  ) => {
    const loadImg = (src: string): Promise<HTMLImageElement | null> =>
      new Promise((resolve) => {
        if (!src) return resolve(null);
        const im = new Image();
        im.crossOrigin = 'anonymous';
        im.onload = () => resolve(im);
        im.onerror = () => resolve(null);
        im.src = src;
      });

    const lines: { left: string; mid?: string; right: string; highlight?: boolean }[] = [];
    let title = 'OFFICIAL QUOTATION';

    if (chartType === 'CUTTING') {
      title = 'WORKSHOP CUTTING CHART & BAR OPTIMIZATION';
      Object.entries(sectionPiecesMap).forEach(([sec, pcs]) => {
        const packed = packSection(pcs, barLengthsFor(sec));
        lines.push({
          left: `SECTION: ${SECTION_LABELS[sec] || sec} (${sec})`,
          right: `${packed.bins.length} Bar(s)`,
          highlight: true,
        });
        packed.bins.forEach((bar, bIdx) => {
          lines.push({
            left: `  BAR #${bIdx + 1} (${bar.lenFt} FT ${bar.isCustom ? 'OFFCUT' : 'BAR'})`,
            right: `Waste: ${formatDim(Math.max(0, bar.remainInches), measurementUnit)}`,
          });
          bar.pieces.forEach((p) => {
            lines.push({
              left: `    • ${p.source} — ${p.label}`,
              right: formatDim(p.length, measurementUnit),
            });
          });
        });
      });
    } else if (chartType === 'LENGTH') {
      title = 'STOCK BAR LENGTH CHART & ORDER TALLY';
      let grandBars = 0;
      let grandFt = 0;
      Object.entries(sectionPiecesMap).forEach(([sec, pcs]) => {
        const packed = packSection(pcs, barLengthsFor(sec));
        let tBars = 0;
        let tFt = 0;
        const bd = Object.entries(packed.tally)
          .sort((a, b) => Number(b[0]) - Number(a[0]))
          .map(([len, info]) => {
            tBars += info.count;
            tFt += Number(len) * info.count;
            return `${len}FT × ${info.count}`;
          })
          .join(' · ');
        grandBars += tBars;
        grandFt += tFt;
        lines.push({
          left: `${SECTION_LABELS[sec] || sec} (${sec})`,
          mid: bd,
          right: `${tBars} Bars (${tFt} ft)`,
        });
      });
      lines.push({
        left: 'GRAND TOTAL STOCK BARS & FEET',
        right: `${grandBars} Bars · ${grandFt} Feet`,
        highlight: true,
      });
    } else if (chartType === 'GLASS') {
      title = 'GLASS CUTTING SCHEDULE & TOTAL BILL';
      glassCuts.forEach((g) => {
        lines.push({
          left: `${g.frameLabel} (${g.glassGauge}mm ${g.glassColor})`,
          mid: `Cut: ${formatDim(g.gWpanel, measurementUnit)} × ${formatDim(g.gH, measurementUnit)} | Billed: ${g.billedWFt}×${g.billedHFt}ft`,
          right: `${g.pieces} Pcs · ${g.sqft.toFixed(2)} Sq.Ft`,
        });
      });
      activeQuote.glassLines.forEach((gl) => {
        lines.push({
          left: `${gl.description}`,
          mid: `${gl.sqft.toFixed(2)} Sq.Ft @ Rs ${gl.rate}/sq.ft`,
          right: `Rs ${Math.round(gl.total).toLocaleString()}`,
        });
      });
      lines.push({
        left: `GRAND TOTAL GLASS (${totalGlassPieces} Pcs · ${totalGlassSqFt.toFixed(2)} Sq.Ft)`,
        right: `Rs ${Math.round(activeQuote.glassTotal).toLocaleString()}`,
        highlight: true,
      });
    } else {
      title = 'OFFICIAL QUOTATION & COST SUMMARY';
      activeQuote.aluminiumRows.forEach((row) => {
        lines.push({
          left: `${SECTION_LABELS[row.section] || row.section} (${row.gauge}mm)`,
          mid: `${row.bars} Bars · ${row.totalFt} ft @ Rs ${Math.round(row.ratePerFt)}`,
          right: `Rs ${Math.round(row.cost).toLocaleString()}`,
        });
      });
      lines.push({
        left: 'Aluminium Gross Total',
        right: `Rs ${Math.round(activeQuote.alumTotal).toLocaleString()}`,
      });
      if (layoutConfig.showDiscountRow) {
        lines.push({
          left: `Discount (${markupPct}%)`,
          right: `- Rs ${Math.round(Math.max(0, activeQuote.alumTotal - activeQuote.alumWithMarkup)).toLocaleString()}`,
        });
      }
      lines.push({
        left: 'Aluminium Net Total (After Discount)',
        right: `Rs ${Math.round(activeQuote.alumWithMarkup).toLocaleString()}`,
        highlight: true,
      });
      if (layoutConfig.showHardwareRow) {
        lines.push({
          left: `Hardware (${activeQuote.totalUnits} units × Rs ${hardwareRate})`,
          right: `Rs ${Math.round(activeQuote.hardwareTotal).toLocaleString()}`,
        });
      }
      activeQuote.glassLines.forEach((gl) => {
        lines.push({
          left: `${gl.description} (${gl.sqft.toFixed(1)} sq.ft @ Rs ${gl.rate})`,
          right: `Rs ${Math.round(gl.total).toLocaleString()}`,
        });
      });
      if (layoutConfig.showTransportRow && activeQuote.transportRent > 0) {
        lines.push({
          left: 'Transport Rent',
          right: `Rs ${Math.round(activeQuote.transportRent).toLocaleString()}`,
        });
      }
      if (layoutConfig.showLabourRow && activeQuote.labourCost > 0) {
        lines.push({
          left: 'Labour / Installation',
          right: `Rs ${Math.round(activeQuote.labourCost).toLocaleString()}`,
        });
      }
      lines.push({
        left: 'NET GRAND TOTAL',
        right: `Rs ${Math.round(activeQuote.grandTotal).toLocaleString()}`,
        highlight: true,
      });
    }

    const width = 1100;
    const rowH = 38;
    const height = Math.max(760, 280 + lines.length * rowH + 110);
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dark luxury background
    ctx.fillStyle = '#0D1118';
    ctx.fillRect(0, 0, width, height);

    // Optional Letterhead Background watermark
    if (layoutConfig.showLetterheadBackground && letterheadBgUrl) {
      const bgImg = await loadImg(letterheadBgUrl);
      if (bgImg) {
        ctx.save();
        ctx.globalAlpha = layoutConfig.letterheadOpacity || 0.28;
        ctx.drawImage(bgImg, 0, 0, width, height);
        ctx.restore();
      }
    }

    // Outer Gold Frame
    ctx.strokeStyle = '#F5B738';
    ctx.lineWidth = 4;
    ctx.strokeRect(16, 16, width - 32, height - 32);

    // Shop Logo (or Official Golden Lion Logo fallback)
    const logoImg = await loadImg(activeShopLogoUrl);
    if (logoImg) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(82, 82, 42, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(logoImg, 40, 40, 84, 84);
      ctx.restore();
      ctx.strokeStyle = '#F5B738';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(82, 82, 42, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Company Header
    ctx.fillStyle = '#F5B738';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(companyName || 'BOSS ALUMINIUM & GLASS', 142, 66);
    ctx.fillStyle = '#FDE68A';
    ctx.font = '600 15px sans-serif';
    ctx.fillText(companyTagline || 'STRONGER · SMARTER · BETTER', 142, 92);
    ctx.fillStyle = '#CBD5E1';
    ctx.font = '14px sans-serif';
    ctx.fillText(`Phone: ${companyPhone} · Address: ${companyAddress}`, 142, 116);

    // Chart Title & Date
    ctx.textAlign = 'right';
    ctx.fillStyle = '#F5B738';
    ctx.font = 'bold 20px monospace';
    ctx.fillText(title, width - 44, 68);
    ctx.fillStyle = '#E2E8F0';
    ctx.font = '14px monospace';
    ctx.fillText(`Date: ${new Date().toLocaleDateString('en-GB')}`, width - 44, 94);
    ctx.fillText(
      `Customer: ${customerName || 'Valued Client'} ${customerPhone ? `(${customerPhone})` : ''}`,
      width - 44,
      118
    );
    ctx.textAlign = 'left';

    // Divider
    ctx.strokeStyle = '#F5B738';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(40, 142);
    ctx.lineTo(width - 40, 142);
    ctx.stroke();

    // Rows
    let y = 182;
    lines.forEach((ln) => {
      ctx.fillStyle = ln.highlight ? 'rgba(245, 183, 56, 0.16)' : 'rgba(12, 15, 20, 0.72)';
      ctx.fillRect(40, y - 24, width - 80, 32);

      ctx.fillStyle = ln.highlight ? '#F5B738' : '#F8FAFC';
      ctx.font = ln.highlight ? 'bold 16px sans-serif' : '15px sans-serif';
      ctx.fillText(ln.left, 52, y - 3);

      if (ln.mid) {
        ctx.fillStyle = '#FDE68A';
        ctx.font = '14px monospace';
        ctx.fillText(ln.mid, 430, y - 3);
      }

      ctx.textAlign = 'right';
      ctx.fillStyle = ln.highlight ? '#F5B738' : '#34D399';
      ctx.font = ln.highlight ? 'bold 17px monospace' : 'bold 15px monospace';
      ctx.fillText(ln.right, width - 52, y - 3);
      ctx.textAlign = 'left';
      y += rowH;
    });

    // Footer
    ctx.fillStyle = '#94A3B8';
    ctx.font = '13px sans-serif';
    ctx.fillText(layoutConfig.quotationFooterTerms || '', 44, height - 38);

    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const fileName = `Boss-${chartType.toLowerCase()}-${Date.now()}.png`;
      const pngFile = new File([blob], fileName, { type: 'image/png' });

      // Always download a copy so the user immediately gets the PNG image
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 5000);

      // Also invoke native mobile/desktop Share Sheet if supported
      if (navigator.share && navigator.canShare && navigator.canShare({ files: [pngFile] })) {
        try {
          await navigator.share({
            title: `${companyName} - ${title}`,
            text: `${companyName} — ${title} for ${customerName || 'Valued Client'}`,
            files: [pngFile],
          });
        } catch {
          // user dismissed share sheet; file already downloaded
        }
      }
      showSettingsToast(`${chartType} Picture (PNG) saved & ready to share!`);
    }, 'image/png');
  };

  // Share or Download any Saved History Quotation as an Official High-Resolution PNG Image
  const handleShareHistoryItemAsPng = async (item: SavedQuotation) => {
    const loadImg = (src: string): Promise<HTMLImageElement | null> =>
      new Promise((resolve) => {
        if (!src) return resolve(null);
        const im = new Image();
        im.crossOrigin = 'anonymous';
        im.onload = () => resolve(im);
        im.onerror = () => resolve(null);
        im.src = src;
      });

    const lines: { left: string; mid?: string; right: string; highlight?: boolean }[] = [
      {
        left: 'Project Items Summary',
        mid: `${item.totalUnits} Total Units (${item.gauge}mm · ${item.color})`,
        right: item.itemsSummary,
      },
      {
        left: 'Aluminium Net Total',
        right: `Rs ${Math.round(item.alumTotal).toLocaleString()}`,
      },
      {
        left: 'Hardware Total',
        right: `Rs ${Math.round(item.hardwareTotal).toLocaleString()}`,
      },
      {
        left: 'Glass Total Bill',
        right: `Rs ${Math.round(item.glassTotal).toLocaleString()}`,
      },
    ];
    if (item.transportRent > 0) {
      lines.push({
        left: 'Transport Rent',
        right: `Rs ${Math.round(item.transportRent).toLocaleString()}`,
      });
    }
    if (item.labourCost > 0) {
      lines.push({
        left: 'Labour / Installation',
        right: `Rs ${Math.round(item.labourCost).toLocaleString()}`,
      });
    }
    lines.push({
      left: 'NET GRAND TOTAL',
      right: `Rs ${Math.round(item.grandTotal).toLocaleString()}`,
      highlight: true,
    });

    const width = 1100;
    const height = 740;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0D1118';
    ctx.fillRect(0, 0, width, height);

    if (layoutConfig.showLetterheadBackground && letterheadBgUrl) {
      const bgImg = await loadImg(letterheadBgUrl);
      if (bgImg) {
        ctx.save();
        ctx.globalAlpha = layoutConfig.letterheadOpacity || 0.28;
        ctx.drawImage(bgImg, 0, 0, width, height);
        ctx.restore();
      }
    }

    ctx.strokeStyle = '#F5B738';
    ctx.lineWidth = 4;
    ctx.strokeRect(16, 16, width - 32, height - 32);

    const logoImg = await loadImg(activeShopLogoUrl);
    if (logoImg) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(82, 82, 42, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(logoImg, 40, 40, 84, 84);
      ctx.restore();
      ctx.strokeStyle = '#F5B738';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(82, 82, 42, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = '#F5B738';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(companyName || 'BOSS ALUMINIUM & GLASS', 142, 66);
    ctx.fillStyle = '#FDE68A';
    ctx.font = '600 15px sans-serif';
    ctx.fillText(companyTagline || 'STRONGER · SMARTER · BETTER', 142, 92);
    ctx.fillStyle = '#CBD5E1';
    ctx.font = '14px sans-serif';
    ctx.fillText(`Phone: ${companyPhone} · Address: ${companyAddress}`, 142, 116);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#F5B738';
    ctx.font = 'bold 20px monospace';
    ctx.fillText('SAVED OFFICIAL QUOTATION', width - 44, 68);
    ctx.fillStyle = '#E2E8F0';
    ctx.font = '14px monospace';
    ctx.fillText(`Saved Date: ${item.timestamp}`, width - 44, 94);
    ctx.fillText(
      `Customer: ${item.customerName || item.label} ${item.customerPhone ? `(${item.customerPhone})` : ''}`,
      width - 44,
      118
    );
    ctx.textAlign = 'left';

    ctx.strokeStyle = '#F5B738';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(40, 142);
    ctx.lineTo(width - 40, 142);
    ctx.stroke();

    let y = 190;
    lines.forEach((ln) => {
      ctx.fillStyle = ln.highlight ? 'rgba(245, 183, 56, 0.18)' : 'rgba(12, 15, 20, 0.75)';
      ctx.fillRect(40, y - 26, width - 80, 38);

      ctx.fillStyle = ln.highlight ? '#F5B738' : '#F8FAFC';
      ctx.font = ln.highlight ? 'bold 17px sans-serif' : '15px sans-serif';
      ctx.fillText(ln.left, 52, y - 2);

      if (ln.mid) {
        ctx.fillStyle = '#FDE68A';
        ctx.font = '14px monospace';
        ctx.fillText(ln.mid, 320, y - 2);
      }

      ctx.textAlign = 'right';
      ctx.fillStyle = ln.highlight ? '#F5B738' : '#34D399';
      ctx.font = ln.highlight ? 'bold 18px monospace' : 'bold 15px monospace';
      ctx.fillText(ln.right, width - 52, y - 2);
      ctx.textAlign = 'left';
      y += 46;
    });

    ctx.fillStyle = '#94A3B8';
    ctx.font = '13px sans-serif';
    ctx.fillText(layoutConfig.quotationFooterTerms || '', 44, height - 38);

    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const fileName = `Boss-Quotation-${(item.customerName || 'Client').replace(/\s+/g, '-')}-${item.id}.png`;
      const pngFile = new File([blob], fileName, { type: 'image/png' });

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 5000);

      if (navigator.share && navigator.canShare && navigator.canShare({ files: [pngFile] })) {
        try {
          await navigator.share({
            title: `${companyName} - Quotation (${item.label})`,
            text: `Official Quotation for ${item.customerName || item.label} — Total Rs ${Math.round(item.grandTotal).toLocaleString()}`,
            files: [pngFile],
          });
        } catch {
          // user closed share sheet
        }
      }
      showSettingsToast(`Quotation Picture (PNG) for "${item.label}" saved & ready to share!`);
    }, 'image/png');
  };

  const TABS: { id: BossTab; title: string }[] = (
    [
      {
        id: 'WINDOWS' as BossTab,
        title: `${layoutConfig.tabCustomTitles.WINDOWS || 'Windows'} (${windows.length})`,
      },
      {
        id: 'DOORS' as BossTab,
        title: `${layoutConfig.tabCustomTitles.DOORS || 'Doors & Frames'} (${
          doors.length + fixframes.length + openableWindows.length + slidingDoors.length
        })`,
      },
      {
        id: 'EXTRA_PIECES' as BossTab,
        title: `${layoutConfig.tabCustomTitles.EXTRA_PIECES || 'Extra Pieces'} (${
          projectExtras.length
        })`,
      },
      { id: 'CUTTING' as BossTab, title: layoutConfig.tabCustomTitles.CUTTING || 'Cutting Chart' },
      { id: 'LENGTH' as BossTab, title: layoutConfig.tabCustomTitles.LENGTH || 'Length Chart' },
      { id: 'GLASS' as BossTab, title: layoutConfig.tabCustomTitles.GLASS || 'Glass Chart' },
      { id: 'QUOTATION' as BossTab, title: layoutConfig.tabCustomTitles.QUOTATION || 'Quotation' },
      {
        id: 'HISTORY' as BossTab,
        title: `${layoutConfig.tabCustomTitles.HISTORY || 'History'} (${savedQuotations.length})`,
      },
      { id: 'RATES' as BossTab, title: layoutConfig.tabCustomTitles.RATES || 'Rates & Settings' },
    ] as { id: BossTab; title: string }[]
  ).filter((t) => layoutConfig.enabledTabs[t.id] !== false);

  return (
    <div className="space-y-3">
      {/* =================================================================== */}
      {/* LIVE BROADCAST OFFER & ANNOUNCEMENT BANNER                          */}
      {/* =================================================================== */}
      {activeOffer && activeOffer.isActive && dismissedBannerId !== activeOffer.id && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-amber-500/20 border-2 border-amber-400 shadow-xl shadow-amber-950/40 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-black flex items-center justify-center font-black shrink-0 shadow-md">
              <Zap className="w-5 h-5 text-black animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-rose-600 text-white tracking-wider uppercase shadow-sm">
                  {activeOffer.badgeText || 'SPECIAL OFFER'}
                </span>
                <span className="text-sm font-black text-white">
                  {activeOffer.title}
                </span>
                {activeOffer.discountPct && activeOffer.discountPct > 0 && (
                  <span className="text-xs font-black text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/50">
                    Save {activeOffer.discountPct}% OFF!
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-300 mt-1 leading-relaxed">
                {activeOffer.message}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowPackagesModal(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-black flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              <span>👑 View Subscription Packages</span>
            </button>
            <button
              type="button"
              onClick={() => setDismissedBannerId(activeOffer.id)}
              className="p-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-slate-400 hover:text-white"
              title="Dismiss announcement banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* BOSS TOP CONTEXT HEADER (PORTED FROM BossTopHeader.kt)              */}
      {/* =================================================================== */}
      <div className="p-3.5 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <img
              src={mainLogoUrl}
              alt="Boss Aluminium Lion Logo"
              className="w-11 h-11 rounded-full object-cover border-2 border-[#F5B738] shrink-0"
            />
            <div>
              <div className="text-sm font-black text-[#F5B738] tracking-wide">
                {companyName || 'BOSS ALUMINIUM & GLASS'}
              </div>
              <div className="text-[11px] text-amber-200/80 font-medium">
                {companyTagline || 'STRONGER · SMARTER · BETTER'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {onPushFullConfigToCloud && (
              <button
                onClick={async () => {
                  setSyncingCloud(true);
                  try {
                    const res = await onPushFullConfigToCloud();
                    showSettingsToast(res.message);
                  } catch (e: any) {
                    showSettingsToast(e?.message || 'Sync error');
                  } finally {
                    setSyncingCloud(false);
                  }
                }}
                disabled={syncingCloud}
                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md shadow-emerald-950/40"
              >
                <CloudUpload className="w-3.5 h-3.5" />
                <span>{syncingCloud ? 'Syncing...' : '☁️ Push to Client App'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setShowPackagesModal(true)}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-black text-xs font-black flex items-center gap-1.5 shadow-md shadow-amber-500/25 transition-all cursor-pointer"
            >
              <span>👑 Packages & Offers</span>
              {packages.some((p) => (p.discountPct && p.discountPct > 0) || (p.originalPriceRs && p.originalPriceRs > p.priceRs)) && (
                <span className="px-1.5 py-0.5 rounded bg-rose-600 text-white text-[9px] font-black animate-pulse">
                  OFFER
                </span>
              )}
            </button>
            {layoutConfig.showThemeStudioButton && (
              <button
                onClick={onOpenThemeStudio}
                className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-[#F5B738]/60 text-xs font-bold text-[#F5B738] hover:bg-[#F5B738] hover:text-black flex items-center gap-1.5 transition-colors"
              >
                <span>🎨 Mobile Theme Studio</span>
              </button>
            )}
            {layoutConfig.showDoneQuotationButton && (
              <button
                onClick={() => onSelectTab('QUOTATION')}
                className="px-3.5 py-1.5 rounded-lg bg-[#F5B738] text-black text-xs font-bold hover:bg-amber-400 flex items-center gap-1.5 transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Done (View Quotation)</span>
              </button>
            )}
            <button
              onClick={() => onSelectTab('RATES')}
              className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-[#F5B738]/70 text-xs font-bold text-[#F5B738] hover:bg-[#F5B738] hover:text-black flex items-center gap-1.5 transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>App Settings & Rates</span>
            </button>
            <button
              onClick={onOpenSettingsTab}
              className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-slate-700 text-xs text-slate-200 hover:border-[#F5B738] flex items-center gap-1.5"
            >
              <Scissors className="w-3.5 h-3.5 text-[#F5B738]" />
              <span>Admin Formulas</span>
            </button>
          </div>
        </div>

        {/* 4 Master Pricing Context Selector Chips with Explicit ON/OFF Unlock Switches! */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {/* 1. Master Gauge Selector + ON/OFF Switch */}
          {layoutConfig.showMasterGaugeSelector && (
            <div className="flex items-center justify-between gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#1C222B] border border-[#2B3441]">
              <span className="text-[11px] text-slate-400 shrink-0">Main Gauge:</span>
              <select
                value={ctxGauge}
                onChange={(e) => onSetCtxGauge(e.target.value, ctxGaugeMode)}
                disabled={ctxGaugeMode === 'OFF'}
                className="bg-transparent text-xs font-bold text-[#F5B738] focus:outline-none cursor-pointer disabled:opacity-40"
              >
                {GAUGES.map((g) => (
                  <option key={g} value={g} className="bg-[#14181F]">
                    {g} mm
                  </option>
                ))}
              </select>
              <button
                onClick={() =>
                  onSetCtxGauge(ctxGauge, ctxGaugeMode === 'ON' ? 'OFF' : 'ON')
                }
                className={`px-2 py-0.5 rounded text-[10px] font-black transition-colors shrink-0 ${
                  ctxGaugeMode === 'ON'
                    ? 'bg-emerald-500 text-black'
                    : 'bg-rose-600 text-white'
                }`}
                title="Turn OFF to unlock separate Gauge button on every frame"
              >
                {ctxGaugeMode === 'ON' ? 'ON (All)' : 'OFF (Separate)'}
              </button>
            </div>
          )}

          {/* 2. Master Color Selector */}
          {layoutConfig.showMasterColorSelector && (
            <div className="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-[#1C222B] border border-[#2B3441]">
              <span className="text-[11px] text-slate-400">Finish/Color:</span>
              <select
                value={ctxColor}
                onChange={(e) => onSetCtxColor(e.target.value)}
                className="bg-transparent text-xs font-bold text-amber-300 focus:outline-none cursor-pointer"
              >
                {availableColors.map((c) => (
                  <option key={c} value={c} className="bg-[#14181F]">
                    {c}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* 3. Master Frame Type Selector + ON/OFF Switch */}
          {layoutConfig.showMasterFrameSelector && (
            <div className="flex items-center justify-between gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#1C222B] border border-[#2B3441]">
              <span className="text-[11px] text-slate-400 shrink-0">Main Frame:</span>
              <select
                value={ctxFrameType === 'OFF' ? 'C' : ctxFrameType}
                disabled={ctxFrameType === 'OFF'}
                onChange={(e) => onSetCtxFrameType(e.target.value)}
                className="bg-transparent text-xs font-bold text-sky-400 focus:outline-none cursor-pointer disabled:opacity-40 truncate max-w-[115px]"
              >
                <option value="C" className="bg-[#14181F]">
                  C (DC30C / M30)
                </option>
                <option value="F" className="bg-[#14181F]">
                  F (DC30F / M30F)
                </option>
                {customSections.map((sec) => (
                  <option key={sec} value={sec} className="bg-[#14181F]">
                    {sec}
                  </option>
                ))}
              </select>
              <button
                onClick={() =>
                  onSetCtxFrameType(ctxFrameType === 'OFF' ? 'C' : 'OFF')
                }
                className={`px-2 py-0.5 rounded text-[10px] font-black transition-colors shrink-0 ${
                  ctxFrameType !== 'OFF'
                    ? 'bg-emerald-500 text-black'
                    : 'bg-rose-600 text-white'
                }`}
                title="Turn OFF to unlock separate Frame / Pair selector on every frame"
              >
                {ctxFrameType !== 'OFF' ? 'ON (All)' : 'OFF (Separate)'}
              </button>
            </div>
          )}

          {/* 4. Master Glass Selector + ON/OFF Switch */}
          {layoutConfig.showMasterGlassSelector && (
            <div className="flex items-center justify-between gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#1C222B] border border-[#2B3441]">
              <span className="text-[11px] text-slate-400 shrink-0">Main Glass:</span>
              <select
                value={`${ctxGlassGauge}|${ctxGlassColor}`}
                disabled={ctxGlassMode === 'OFF'}
                onChange={(e) => {
                  const [g, c] = e.target.value.split('|');
                  onSetCtxGlass(g, c, ctxGlassMode);
                }}
                className="bg-transparent text-xs font-bold text-amber-200 focus:outline-none cursor-pointer disabled:opacity-40 truncate max-w-[115px]"
              >
                {['5', '8'].flatMap((g) =>
                  (g === '8' ? glassColors8mm : glassColors5mm).map((gc) => (
                    <option key={`${g}|${gc}`} value={`${g}|${gc}`} className="bg-[#14181F]">
                      {g}mm · {gc}
                    </option>
                  ))
                )}
              </select>
              <button
                onClick={() =>
                  onSetCtxGlass(
                    ctxGlassGauge,
                    ctxGlassColor,
                    ctxGlassMode === 'ON' ? 'OFF' : 'ON'
                  )
                }
                className={`px-2 py-0.5 rounded text-[10px] font-black transition-colors shrink-0 ${
                  ctxGlassMode === 'ON'
                    ? 'bg-emerald-500 text-black'
                    : 'bg-rose-600 text-white'
                }`}
                title="Turn OFF to unlock separate Glass Gauge & Glass Color on every frame"
              >
                {ctxGlassMode === 'ON' ? 'ON (All)' : 'OFF (Separate)'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* =================================================================== */}
      {/* 9-TAB SCROLLABLE NAVIGATION ROW                                     */}
      {/* =================================================================== */}
      <div className="flex items-center gap-1.5 overflow-x-auto p-1.5 rounded-xl bg-[#14181F] border border-[#2B3441]">
        {TABS.map((tab) => {
          const isSelected = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
                isSelected
                  ? 'bg-[#F5B738] text-black'
                  : 'text-slate-300 hover:bg-[#1C222B] hover:text-white'
              }`}
            >
              {tab.title}
            </button>
          );
        })}
      </div>

      {/* =================================================================== */}
      {/* TAB 1: SLIDING WINDOWS SCREEN                                       */}
      {/* =================================================================== */}
      {currentTab === 'WINDOWS' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-[#F5B738]">
                Sliding Windows ({windows.length})
              </h3>
              <p className="text-xs text-slate-400">
                Unit: {unitLabel(measurementUnit)} (e.g. 36.4 = 36" 4 sutar)
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => {
                  const ft = ctxFrameType === 'F' ? 'F' : 'C';
                  const newWin: WindowItem = {
                    id: `win-${Date.now()}`,
                    width: 48,
                    height: 60,
                    qty: 1,
                    frameType: ft,
                    sectionGauge: ctxGaugeMode === 'ON' ? ctxGauge : '1.6',
                    glassGauge: ctxGlassMode === 'ON' ? ctxGlassGauge : '5',
                    glassColor: ctxGlassMode === 'ON' ? ctxGlassColor : 'CLEAR',
                    glassEnabled: true,
                    m24Qty: 4,
                    m24aQty: 0,
                    d29HeightQty: 2,
                    d29WidthQty: 2,
                    extras: [],
                    outerSection: ft === 'F' ? 'DC30F' : 'DC30C',
                    panelCount: 2,
                    lockType: 'LATCH',
                  };
                  onUpdateWindows([...windows, newWin]);
                }}
                className="px-3.5 py-2 rounded-lg bg-[#F5B738] text-black text-xs font-bold hover:bg-amber-400 flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Add Window</span>
              </button>
            </div>
          </div>

          {windows.length === 0 ? (
            <div className="p-12 rounded-xl bg-[#14181F] border border-[#2B3441] text-center text-xs text-slate-400">
              No windows added yet. Click "+ Add Window" above to start calculating.
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
              {windows.map((win, idx) => {
                const isFrameLocked = ctxFrameType !== 'OFF';
                const isGaugeLocked = ctxGaugeMode === 'ON';
                const isGlassLocked = ctxGlassMode === 'ON';

                return (
                  <div
                    key={win.id}
                    className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#F5B738]">
                        Window #{idx + 1} ({win.panelCount} Palay)
                      </span>
                      <button
                        onClick={() =>
                          onUpdateWindows(windows.filter((w) => w.id !== win.id))
                        }
                        className="text-rose-400 hover:text-rose-300 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Panels Selector (2 / 3 / 4 Palay) */}
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-semibold">Panels:</span>
                      <div className="flex items-center gap-1.5">
                        {[2, 3, 4].map((count) => (
                          <button
                            key={count}
                            onClick={() =>
                              onUpdateWindows(
                                windows.map((w) =>
                                  w.id === win.id
                                    ? {
                                        ...w,
                                        panelCount: count,
                                        m24Qty: count * 2,
                                        d29HeightQty: count >= 3 ? 4 : 2,
                                        d29WidthQty: count >= 3 ? 4 : 2,
                                      }
                                    : w
                                )
                              )
                            }
                            className={`px-3 py-1 rounded text-xs font-bold transition-colors ${
                              win.panelCount === count
                                ? 'bg-[#F5B738] text-black'
                                : 'bg-[#1C222B] text-slate-300 border border-slate-700'
                            }`}
                          >
                            {count} Palay
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Lock / Handle Selector */}
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-semibold">
                        Lock / Handle:
                      </span>
                      <div className="flex items-center gap-1.5">
                        {(['LATCH', 'PUSH_HANDLE'] as const).map((lk) => (
                          <button
                            key={lk}
                            onClick={() =>
                              onUpdateWindows(
                                windows.map((w) =>
                                  w.id === win.id ? { ...w, lockType: lk } : w
                                )
                              )
                            }
                            className={`px-3 py-1 rounded text-xs font-bold transition-colors ${
                              win.lockType === lk
                                ? lk === 'PUSH_HANDLE'
                                  ? 'bg-sky-500 text-black'
                                  : 'bg-[#F5B738] text-black'
                                : 'bg-[#1C222B] text-slate-300 border border-slate-700'
                            }`}
                          >
                            {lk === 'LATCH' ? 'Latch' : 'Push Handle'}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Width, Height, Qty Inputs */}
                    <div className="grid grid-cols-3 gap-2.5">
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Width ({unitLabel(measurementUnit)})
                        </label>
                        <input
                          type="text"
                          defaultValue={formatDimValueOnly(win.width, measurementUnit)}
                          onBlur={(e) => {
                            const parsed = parseDimToInches(e.target.value, measurementUnit);
                            if (parsed > 0) {
                              onUpdateWindows(
                                windows.map((w) =>
                                  w.id === win.id ? { ...w, width: parsed } : w
                                )
                              );
                            }
                          }}
                          className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Height ({unitLabel(measurementUnit)})
                        </label>
                        <input
                          type="text"
                          defaultValue={formatDimValueOnly(win.height, measurementUnit)}
                          onBlur={(e) => {
                            const parsed = parseDimToInches(e.target.value, measurementUnit);
                            if (parsed > 0) {
                              onUpdateWindows(
                                windows.map((w) =>
                                  w.id === win.id ? { ...w, height: parsed } : w
                                )
                              );
                            }
                          }}
                          className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">Qty</label>
                        <input
                          type="number"
                          value={win.qty}
                          onChange={(e) =>
                            onUpdateWindows(
                              windows.map((w) =>
                                w.id === win.id
                                  ? { ...w, qty: Math.max(1, parseInt(e.target.value, 10) || 1) }
                                  : w
                              )
                            )
                          }
                          className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>
                    </div>

                    {/* Single Frame Section / Drag & Drop Blueprint Option Button (Unlocks when Main Frame is OFF) */}
                    <div className="p-2 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <button
                          type="button"
                          onClick={() =>
                            onSetCtxFrameType(isFrameLocked ? 'OFF' : 'C')
                          }
                          className={`p-1 rounded transition-colors ${
                            isFrameLocked
                              ? 'bg-slate-800 text-slate-400 hover:text-[#F5B738]'
                              : 'bg-amber-500/20 text-[#F5B738]'
                          }`}
                          title={
                            isFrameLocked
                              ? 'Main Frame ON — Click to Unlock Separate Frame Section'
                              : 'Separate Frame Unlocked — Click to Lock to Main Frame'
                          }
                        >
                          {isFrameLocked ? (
                            <Lock className="w-3.5 h-3.5" />
                          ) : (
                            <Unlock className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <span className="text-xs text-slate-300 font-semibold truncate">
                          Frame Section:
                        </span>
                      </div>

                      <select
                        disabled={isFrameLocked && !win.blueprintId}
                        value={
                          win.blueprintId
                            ? `BP:${win.blueprintId}`
                            : isFrameLocked
                            ? ctxFrameType
                            : win.frameType
                        }
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val.startsWith('BP:')) {
                            const bpId = val.slice(3);
                            const bp = blueprints.find((b) => b.id === bpId);
                            onUpdateWindows(
                              windows.map((w) =>
                                w.id === win.id
                                  ? {
                                      ...w,
                                      blueprintId: bpId,
                                      blueprintName: bp?.name,
                                      frameType: bp?.outerSectionCode || w.frameType,
                                      outerSection: bp?.outerSectionCode || w.outerSection,
                                    }
                                  : w
                              )
                            );
                          } else {
                            onUpdateWindows(
                              windows.map((w) =>
                                w.id === win.id
                                  ? {
                                      ...w,
                                      blueprintId: undefined,
                                      blueprintName: undefined,
                                      frameType: val,
                                      outerSection: val,
                                    }
                                  : w
                              )
                            );
                          }
                        }}
                        className="flex-1 max-w-[230px] px-2.5 py-1.5 rounded bg-[#1C222B] border border-[#F5B738]/70 text-xs text-amber-300 font-bold disabled:opacity-55 cursor-pointer"
                      >
                        <option value="C">Frame C (DC30C / DC26C)</option>
                        <option value="F">Frame F (DC30F / DC26F)</option>
                        <optgroup label="Custom & Master Sections">
                          {Array.from(new Set([...customSections, ...DEFAULT_SECTIONS])).map(
                            (sec) => (
                              <option key={sec} value={sec}>
                                {sec}
                              </option>
                            )
                          )}
                        </optgroup>
                      </select>
                    </div>

                    {/* Per-Frame Gauge Option Button & Glass + Glass Color Option Button */}
                    {renderFrameGaugeAndGlassControls({
                      sectionGauge: win.sectionGauge,
                      onChangeGauge: (g) =>
                        onUpdateWindows(
                          windows.map((w) =>
                            w.id === win.id ? { ...w, sectionGauge: g } : w
                          )
                        ),
                      glassEnabled: win.glassEnabled,
                      onChangeGlassEnabled: (en) =>
                        onUpdateWindows(
                          windows.map((w) =>
                            w.id === win.id ? { ...w, glassEnabled: en } : w
                          )
                        ),
                      glassGauge: win.glassGauge,
                      glassColor: win.glassColor,
                      onChangeGlassSpec: (g, col) =>
                        onUpdateWindows(
                          windows.map((w) =>
                            w.id === win.id
                              ? { ...w, glassGauge: g, glassColor: col }
                              : w
                          )
                        ),
                    })}

                    {/* Piece Steppers Row: M24, M24A, D29 H, D29 W */}
                    <div className="grid grid-cols-4 gap-2 pt-1">
                      {[
                        {
                          label: 'M24 pcs',
                          val: win.m24Qty,
                          set: (v: number) =>
                            onUpdateWindows(
                              windows.map((w) => (w.id === win.id ? { ...w, m24Qty: v } : w))
                            ),
                        },
                        {
                          label: 'M24A pcs',
                          val: win.m24aQty,
                          set: (v: number) =>
                            onUpdateWindows(
                              windows.map((w) => (w.id === win.id ? { ...w, m24aQty: v } : w))
                            ),
                        },
                        {
                          label: 'D29 H',
                          val: win.d29HeightQty,
                          set: (v: number) =>
                            onUpdateWindows(
                              windows.map((w) =>
                                w.id === win.id ? { ...w, d29HeightQty: v } : w
                              )
                            ),
                        },
                        {
                          label: 'D29 W',
                          val: win.d29WidthQty,
                          set: (v: number) =>
                            onUpdateWindows(
                              windows.map((w) =>
                                w.id === win.id ? { ...w, d29WidthQty: v } : w
                              )
                            ),
                        },
                      ].map((cnt, cIdx) => (
                        <div
                          key={cIdx}
                          className="p-1.5 rounded-lg bg-[#1C222B] border border-slate-800 text-center"
                        >
                          <div className="text-[10px] text-slate-400">{cnt.label}</div>
                          <div className="flex items-center justify-center gap-2 mt-0.5 font-mono text-xs">
                            <button
                              onClick={() => cnt.set(Math.max(0, cnt.val - 1))}
                              className="text-[#F5B738] font-black px-1"
                            >
                              -
                            </button>
                            <span className="font-bold text-white">{cnt.val}</span>
                            <button
                              onClick={() => cnt.set(cnt.val + 1)}
                              className="text-[#F5B738] font-black px-1"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 2: DOORS & FRAMES SCREEN (4 SUB-TABS)                           */}
      {/* =================================================================== */}
      {currentTab === 'DOORS' && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              {[
                { id: 'DOORS', label: `Openable Doors (${doors.length})` },
                { id: 'FIX', label: `Fix Frames (${fixframes.length})` },
                { id: 'OP_WIN', label: `Openable Windows (${openableWindows.length})` },
                { id: 'SLIDING', label: `Sliding Doors (${slidingDoors.length})` },
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => setDoorSubTab(st.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                    doorSubTab === st.id
                      ? 'bg-[#F5B738] text-black'
                      : 'bg-[#14181F] text-slate-300 border border-[#2B3441]'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                if (doorSubTab === 'DOORS') {
                  onUpdateDoors([
                    ...doors,
                    {
                      id: `door-${Date.now()}`,
                      width: 36,
                      height: 84,
                      qty: 1,
                      outer: 'D54A',
                      sectionGauge: ctxGauge,
                      glassGauge: ctxGlassGauge,
                      glassColor: ctxGlassColor,
                      glassEnabled: true,
                      d59Qty: 0,
                      d59aQty: 0,
                      d52Qty: 0,
                      extras: [],
                    },
                  ]);
                } else if (doorSubTab === 'FIX') {
                  onUpdateFixFrames([
                    ...fixframes,
                    {
                      id: `fix-${Date.now()}`,
                      width: 36,
                      height: 48,
                      qty: 1,
                      outer: 'D54A',
                      sectionGauge: ctxGauge,
                      glassGauge: ctxGlassGauge,
                      glassColor: ctxGlassColor,
                      glassEnabled: true,
                      d59Qty: 0,
                      d59aQty: 0,
                      d52Qty: 0,
                      extras: [],
                    },
                  ]);
                } else if (doorSubTab === 'OP_WIN') {
                  onUpdateOpenableWindows([
                    ...openableWindows,
                    {
                      id: `opwin-${Date.now()}`,
                      width: 36,
                      height: 48,
                      qty: 1,
                      outer: 'D54A',
                      sectionGauge: ctxGauge,
                      glassGauge: ctxGlassGauge,
                      glassColor: ctxGlassColor,
                      glassEnabled: true,
                      d59Qty: 0,
                      d59aQty: 0,
                      d52Qty: 0,
                      extras: [],
                    },
                  ]);
                } else {
                  onUpdateSlidingDoors([
                    ...slidingDoors,
                    {
                      id: `sd-${Date.now()}`,
                      width: 60,
                      height: 84,
                      qty: 1,
                      outer: ctxFrameType === 'F' ? 'F' : 'NORMAL',
                      m24Qty: 4,
                      m24aQty: 0,
                      d59Qty: 0,
                      d59aQty: 0,
                      d52Qty: 0,
                      sectionGauge: ctxGauge,
                      glassGauge: ctxGlassGauge,
                      glassColor: ctxGlassColor,
                      glassEnabled: true,
                      extras: [],
                      panelCount: 2,
                      lockType: 'LATCH',
                    },
                  ]);
                }
              }}
              className="px-3.5 py-2 rounded-lg bg-[#F5B738] text-black text-xs font-bold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>+ Add Item</span>
            </button>
          </div>

          {/* Render items for active Door sub-tab */}
          {doorSubTab !== 'SLIDING' ? (
            (() => {
              const currentList =
                doorSubTab === 'DOORS'
                  ? doors
                  : doorSubTab === 'FIX'
                  ? fixframes
                  : openableWindows;
              const updateFn =
                doorSubTab === 'DOORS'
                  ? onUpdateDoors
                  : doorSubTab === 'FIX'
                  ? onUpdateFixFrames
                  : onUpdateOpenableWindows;
              const labelPrefix =
                doorSubTab === 'DOORS'
                  ? 'Door'
                  : doorSubTab === 'FIX'
                  ? 'Fix Frame'
                  : 'Openable Window';
              const outerOptions = Array.from(
                new Set([
                  'D54A',
                  'D51',
                  'D51A',
                  'D45',
                  'D45A',
                  'D42',
                  'D42F',
                  'D54F',
                  'D51F',
                  'D50',
                  'D50A',
                  'D50B',
                  'D41',
                  'D46',
                  ...customSections,
                  ...DEFAULT_SECTIONS.filter((s) => s.startsWith('D') || s.startsWith('DC')),
                ])
              );

              if (currentList.length === 0) {
                return (
                  <div className="p-10 rounded-xl bg-[#14181F] border border-[#2B3441] text-center text-xs text-slate-400">
                    No {labelPrefix.toLowerCase()}s added yet. Click "+ Add Item" above.
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
                  {currentList.map((item, idx) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-[#F5B738]">
                          {labelPrefix} #{idx + 1}
                        </span>
                        <button
                          onClick={() =>
                            updateFn(currentList.filter((i) => i.id !== item.id) as any)
                          }
                          className="text-rose-400 hover:text-rose-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-400 mb-1">
                            Width ({unitLabel(measurementUnit)})
                          </label>
                          <input
                            type="text"
                            defaultValue={formatDimValueOnly(item.width, measurementUnit)}
                            onBlur={(e) => {
                              const parsed = parseDimToInches(e.target.value, measurementUnit);
                              if (parsed > 0) {
                                updateFn(
                                  currentList.map((i) =>
                                    i.id === item.id ? { ...i, width: parsed } : i
                                  ) as any
                                );
                              }
                            }}
                            className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-400 mb-1">
                            Height ({unitLabel(measurementUnit)})
                          </label>
                          <input
                            type="text"
                            defaultValue={formatDimValueOnly(item.height, measurementUnit)}
                            onBlur={(e) => {
                              const parsed = parseDimToInches(e.target.value, measurementUnit);
                              if (parsed > 0) {
                                updateFn(
                                  currentList.map((i) =>
                                    i.id === item.id ? { ...i, height: parsed } : i
                                  ) as any
                                );
                              }
                            }}
                            className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-400 mb-1">Qty</label>
                          <input
                            type="number"
                            value={item.qty}
                            onChange={(e) =>
                              updateFn(
                                currentList.map((i) =>
                                  i.id === item.id
                                    ? { ...i, qty: Math.max(1, parseInt(e.target.value, 10) || 1) }
                                    : i
                                ) as any
                              )
                            }
                            className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                          />
                        </div>
                      </div>

                      {/* Single Outer Frame Section Option Button (Unlocked — Main F converts to F, C restores selected) */}
                      <div className="p-2 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-1.5">
                          <Unlock className="w-3.5 h-3.5 text-[#F5B738]" />
                          <span className="text-xs text-slate-300 font-semibold">
                            Outer Section:
                          </span>
                          {ctxFrameType === 'F' && (
                            <span className="px-2 py-0.5 rounded bg-sky-500/20 border border-sky-500/50 text-[10px] font-bold text-sky-300">
                              F Active: {resolveOuterFrameSection(item.outer)}
                            </span>
                          )}
                        </div>
                        <select
                          value={item.outer}
                          onChange={(e) =>
                            updateFn(
                              currentList.map((i) =>
                                i.id === item.id ? { ...i, outer: e.target.value } : i
                              ) as any
                            )
                          }
                          className="px-3 py-1.5 rounded bg-[#1C222B] border border-[#F5B738]/70 text-xs text-[#F5B738] font-bold cursor-pointer focus:outline-none"
                        >
                          {outerOptions.map((o) => {
                            const resolvedLabel =
                              ctxFrameType === 'F'
                                ? `Outer: ${o} → ${resolveOuterFrameSection(o)} (F)`
                                : `Outer: ${o}`;
                            return (
                              <option key={o} value={o} className="bg-[#14181F] text-amber-300">
                                {resolvedLabel}
                              </option>
                            );
                          })}
                        </select>
                      </div>

                      {/* Per-Frame Gauge Option Button & Glass + Glass Color Option Button */}
                      {renderFrameGaugeAndGlassControls({
                        sectionGauge: item.sectionGauge,
                        onChangeGauge: (g) =>
                          updateFn(
                            currentList.map((i) =>
                              i.id === item.id ? { ...i, sectionGauge: g } : i
                            ) as any
                          ),
                        glassEnabled: item.glassEnabled,
                        onChangeGlassEnabled: (en) =>
                          updateFn(
                            currentList.map((i) =>
                              i.id === item.id ? { ...i, glassEnabled: en } : i
                            ) as any
                          ),
                        glassGauge: item.glassGauge,
                        glassColor: item.glassColor,
                        onChangeGlassSpec: (g, col) =>
                          updateFn(
                            currentList.map((i) =>
                              i.id === item.id
                                ? { ...i, glassGauge: g, glassColor: col }
                                : i
                            ) as any
                          ),
                      })}

                      {/* D59, D59A, D52 Piece Counters */}
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          {
                            label: 'D59 pcs',
                            val: item.d59Qty,
                            set: (v: number) =>
                              updateFn(
                                currentList.map((i) =>
                                  i.id === item.id ? { ...i, d59Qty: v } : i
                                ) as any
                              ),
                          },
                          {
                            label: 'D59A pcs',
                            val: item.d59aQty,
                            set: (v: number) =>
                              updateFn(
                                currentList.map((i) =>
                                  i.id === item.id ? { ...i, d59aQty: v } : i
                                ) as any
                              ),
                          },
                          {
                            label: 'D52 pcs',
                            val: item.d52Qty,
                            set: (v: number) =>
                              updateFn(
                                currentList.map((i) =>
                                  i.id === item.id ? { ...i, d52Qty: v } : i
                                ) as any
                              ),
                          },
                        ].map((cnt, cIdx) => (
                          <div
                            key={cIdx}
                            className="p-1.5 rounded-lg bg-[#1C222B] border border-slate-800 text-center"
                          >
                            <div className="text-[10px] text-slate-400">{cnt.label}</div>
                            <div className="flex items-center justify-center gap-2 mt-0.5 font-mono text-xs">
                              <button
                                onClick={() => cnt.set(Math.max(0, cnt.val - 1))}
                                className="text-[#F5B738] font-black px-1"
                              >
                                -
                              </button>
                              <span className="font-bold text-white">{cnt.val}</span>
                              <button
                                onClick={() => cnt.set(cnt.val + 1)}
                                className="text-[#F5B738] font-black px-1"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()
          ) : slidingDoors.length === 0 ? (
            <div className="p-10 rounded-xl bg-[#14181F] border border-[#2B3441] text-center text-xs text-slate-400">
              No sliding doors added yet. Click "+ Add Item" above.
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
              {slidingDoors.map((sd, idx) => {
                const isFrameLocked = ctxFrameType !== 'OFF';
                const effOuter = isFrameLocked
                  ? ctxFrameType === 'F'
                    ? 'F'
                    : ctxFrameType === 'C'
                    ? 'NORMAL'
                    : ctxFrameType
                  : sd.outer || 'NORMAL';
                const isNormalPair =
                  effOuter === 'NORMAL' || effOuter === 'C' || effOuter === 'M30 / M26';
                const isFPair = effOuter === 'F' || effOuter === 'M30F / M26F';

                return (
                  <div
                    key={sd.id}
                    className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#F5B738]">
                        Sliding Door #{idx + 1} ({sd.panelCount || 2} Palay)
                      </span>
                      <button
                        onClick={() =>
                          onUpdateSlidingDoors(slidingDoors.filter((i) => i.id !== sd.id))
                        }
                        className="text-rose-400 hover:text-rose-300"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* 1. Panels Selector: 2 Palay, 3 Palay, 4 Palay */}
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-semibold">Panels:</span>
                      <div className="flex items-center gap-1.5">
                        {[2, 3, 4].map((count) => (
                          <button
                            key={count}
                            onClick={() =>
                              onUpdateSlidingDoors(
                                slidingDoors.map((i) =>
                                  i.id === sd.id
                                    ? {
                                        ...i,
                                        panelCount: count,
                                        m24Qty: count * 2,
                                        d29HeightQty:
                                          (i.d29HeightQty ?? 0) > 0
                                            ? count >= 3
                                              ? 4
                                              : 2
                                            : i.d29HeightQty ?? 0,
                                        d29WidthQty:
                                          (i.d29WidthQty ?? 0) > 0
                                            ? count >= 3
                                              ? 4
                                              : 2
                                            : i.d29WidthQty ?? 0,
                                      }
                                    : i
                                )
                              )
                            }
                            className={`px-3 py-1 rounded text-xs font-bold transition-colors ${
                              (sd.panelCount || 2) === count
                                ? 'bg-[#F5B738] text-black'
                                : 'bg-[#1C222B] text-slate-300 border border-slate-700'
                            }`}
                          >
                            {count} Palay
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 2. Lock / Handle Selector: Latch vs Push Handle */}
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-semibold">
                        Lock / Handle:
                      </span>
                      <div className="flex items-center gap-1.5">
                        {(['LATCH', 'PUSH_HANDLE'] as const).map((lk) => (
                          <button
                            key={lk}
                            onClick={() =>
                              onUpdateSlidingDoors(
                                slidingDoors.map((i) =>
                                  i.id === sd.id ? { ...i, lockType: lk } : i
                                )
                              )
                            }
                            className={`px-3 py-1 rounded text-xs font-bold transition-colors ${
                              (sd.lockType || 'LATCH') === lk
                                ? lk === 'PUSH_HANDLE'
                                  ? 'bg-sky-500 text-black'
                                  : 'bg-[#F5B738] text-black'
                                : 'bg-[#1C222B] text-slate-300 border border-slate-700'
                            }`}
                          >
                            {lk === 'LATCH' ? 'Latch' : 'Push Handle'}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 3. Width, Height, Qty */}
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Width ({unitLabel(measurementUnit)})
                        </label>
                        <input
                          type="text"
                          defaultValue={formatDimValueOnly(sd.width, measurementUnit)}
                          onBlur={(e) => {
                            const p = parseDimToInches(e.target.value, measurementUnit);
                            if (p > 0)
                              onUpdateSlidingDoors(
                                slidingDoors.map((i) =>
                                  i.id === sd.id ? { ...i, width: p } : i
                                )
                              );
                          }}
                          className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Height ({unitLabel(measurementUnit)})
                        </label>
                        <input
                          type="text"
                          defaultValue={formatDimValueOnly(sd.height, measurementUnit)}
                          onBlur={(e) => {
                            const p = parseDimToInches(e.target.value, measurementUnit);
                            if (p > 0)
                              onUpdateSlidingDoors(
                                slidingDoors.map((i) =>
                                  i.id === sd.id ? { ...i, height: p } : i
                                )
                              );
                          }}
                          className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-1">Qty</label>
                        <input
                          type="number"
                          value={sd.qty}
                          onChange={(e) =>
                            onUpdateSlidingDoors(
                              slidingDoors.map((i) =>
                                i.id === sd.id
                                  ? {
                                      ...i,
                                      qty: Math.max(1, parseInt(e.target.value, 10) || 1),
                                    }
                                  : i
                              )
                            )
                          }
                          className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>
                    </div>

                    {/* 4. Single Outer Frame Pair Option Button: (M30/M26) vs (M30F/M26F) + Custom Pair */}
                    <div className="p-2 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            onSetCtxFrameType(isFrameLocked ? 'OFF' : 'C')
                          }
                          className={`p-1 rounded transition-colors ${
                            isFrameLocked
                              ? 'bg-slate-800 text-slate-400 hover:text-[#F5B738]'
                              : 'bg-amber-500/20 text-[#F5B738]'
                          }`}
                          title={
                            isFrameLocked
                              ? 'Main Frame ON — Click to Unlock Separate Sliding Door Pair'
                              : 'Separate Pair Unlocked — Click to Lock to Main Frame'
                          }
                        >
                          {isFrameLocked ? (
                            <Lock className="w-3.5 h-3.5" />
                          ) : (
                            <Unlock className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <span className="text-xs text-slate-300 font-semibold">
                          Frame Pair:
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 flex-1 max-w-[270px]">
                        <select
                          disabled={isFrameLocked}
                          value={effOuter}
                          onChange={(e) =>
                            onUpdateSlidingDoors(
                              slidingDoors.map((i) =>
                                i.id === sd.id ? { ...i, outer: e.target.value } : i
                              )
                            )
                          }
                          className="flex-1 px-2.5 py-1.5 rounded bg-[#1C222B] border border-slate-700 text-xs text-slate-200 font-medium disabled:opacity-55"
                        >
                          <option value="NORMAL">Pair: M30 / M26 (Normal)</option>
                          <option value="F">Pair: M30F / M26F (F-Series)</option>
                          <option value="DC30C / DC26C">Pair: DC30C / DC26C</option>
                          <option value="DC30F / DC26F">Pair: DC30F / DC26F</option>
                          {customSections.length > 0 && (
                            <optgroup label="Custom Sections">
                              {customSections.map((sec) => (
                                <option key={sec} value={sec}>
                                  {sec} {SECTION_LABELS[sec] ? `· ${SECTION_LABELS[sec]}` : ''}
                                </option>
                              ))}
                            </optgroup>
                          )}
                        </select>
                      </div>
                    </div>

                    {/* 5. Per-Frame Gauge Option Button & Glass + Glass Color Option Button */}
                    {renderFrameGaugeAndGlassControls({
                      sectionGauge: sd.sectionGauge,
                      onChangeGauge: (g) =>
                        onUpdateSlidingDoors(
                          slidingDoors.map((i) =>
                            i.id === sd.id ? { ...i, sectionGauge: g } : i
                          )
                        ),
                      glassEnabled: sd.glassEnabled,
                      onChangeGlassEnabled: (en) =>
                        onUpdateSlidingDoors(
                          slidingDoors.map((i) =>
                            i.id === sd.id ? { ...i, glassEnabled: en } : i
                          )
                        ),
                      glassGauge: sd.glassGauge,
                      glassColor: sd.glassColor,
                      onChangeGlassSpec: (g, col) =>
                        onUpdateSlidingDoors(
                          slidingDoors.map((i) =>
                            i.id === sd.id
                              ? { ...i, glassGauge: g, glassColor: col }
                              : i
                          )
                        ),
                    })}

                    {/* 6. Piece Count Steppers: M24, M24A, D29 H, D29 W (D59, D59A, D52 removed from Sliding Doors) */}
                    <div className="grid grid-cols-4 gap-2 pt-1">
                      {[
                        {
                          label: 'M24 pcs',
                          val: sd.m24Qty,
                          set: (v: number) =>
                            onUpdateSlidingDoors(
                              slidingDoors.map((i) =>
                                i.id === sd.id ? { ...i, m24Qty: v } : i
                              )
                            ),
                        },
                        {
                          label: 'M24A pcs',
                          val: sd.m24aQty,
                          set: (v: number) =>
                            onUpdateSlidingDoors(
                              slidingDoors.map((i) =>
                                i.id === sd.id ? { ...i, m24aQty: v } : i
                              )
                            ),
                        },
                        {
                          label: 'D29 H',
                          val: sd.d29HeightQty ?? 0,
                          set: (v: number) =>
                            onUpdateSlidingDoors(
                              slidingDoors.map((i) =>
                                i.id === sd.id ? { ...i, d29HeightQty: v } : i
                              )
                            ),
                        },
                        {
                          label: 'D29 W',
                          val: sd.d29WidthQty ?? 0,
                          set: (v: number) =>
                            onUpdateSlidingDoors(
                              slidingDoors.map((i) =>
                                i.id === sd.id ? { ...i, d29WidthQty: v } : i
                              )
                            ),
                        },
                      ].map((cnt, cIdx) => (
                        <div
                          key={cIdx}
                          className="p-1.5 rounded-lg bg-[#1C222B] border border-slate-800 text-center"
                        >
                          <div className="text-[10px] text-slate-400">{cnt.label}</div>
                          <div className="flex items-center justify-center gap-2 mt-0.5 font-mono text-xs">
                            <button
                              onClick={() => cnt.set(Math.max(0, cnt.val - 1))}
                              className="text-[#F5B738] font-black px-1"
                            >
                              -
                            </button>
                            <span className="font-bold text-white">{cnt.val}</span>
                            <button
                              onClick={() => cnt.set(cnt.val + 1)}
                              className="text-[#F5B738] font-black px-1"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 3: EXTRA PIECES SCREEN                                          */}
      {/* =================================================================== */}
      {currentTab === 'EXTRA_PIECES' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          <div className="lg:col-span-5 p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
            <h3 className="text-sm font-bold text-[#F5B738]">
              Add Extra Aluminium Piece / Pipe
            </h3>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                Section Code (e.g. D54A, M23, PIPE12, ANGLE1)
              </label>
              <input
                type="text"
                value={extraSec}
                onChange={(e) => setExtraSec(e.target.value.toUpperCase())}
                className="w-full px-3 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-amber-300"
              />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Length (Feet)</label>
                <input
                  type="number"
                  value={extraLenFt}
                  onChange={(e) => setExtraLenFt(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Qty</label>
                <input
                  type="number"
                  value={extraQty}
                  onChange={(e) => setExtraQty(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Gauge</label>
                <select
                  value={extraGauge}
                  onChange={(e) => setExtraGauge(e.target.value)}
                  className="w-full px-2 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-white"
                >
                  {GAUGES.slice(0, 6).map((g) => (
                    <option key={g} value={g}>
                      {g}mm
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] text-slate-400">Quick Ft:</span>
              {['8', '10', '12', '14', '16', '18', '20'].map((ft) => (
                <button
                  key={ft}
                  onClick={() => setExtraLenFt(ft)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono ${
                    extraLenFt === ft
                      ? 'bg-[#F5B738] text-black font-bold'
                      : 'bg-[#1C222B] text-slate-300'
                  }`}
                >
                  {ft}'
                </button>
              ))}
            </div>
            <button
              onClick={() => {
                if (!extraSec.trim()) return;
                onUpdateProjectExtras([
                  ...projectExtras,
                  {
                    id: `ex-${Date.now()}`,
                    section: extraSec.trim().toUpperCase(),
                    lengthFt: Math.max(0.5, parseFloat(extraLenFt) || 10),
                    qty: Math.max(1, parseInt(extraQty, 10) || 1),
                    gauge: extraGauge,
                  },
                ]);
              }}
              className="w-full py-2 rounded-lg bg-[#F5B738] text-black font-bold"
            >
              + Add Extra Piece
            </button>
          </div>

          <div className="lg:col-span-7 p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-2.5">
            <h3 className="text-sm font-bold text-white">
              Project Extra Pieces ({projectExtras.length})
            </h3>
            {projectExtras.length === 0 ? (
              <div className="py-10 text-center text-xs text-slate-500">
                No extra pieces added yet.
              </div>
            ) : (
              projectExtras.map((ex, i) => (
                <div
                  key={ex.id}
                  className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-[#F5B738] font-mono">{ex.section}</span> ·{' '}
                    <span className="text-white font-mono">
                      {ex.lengthFt} ft × {ex.qty} pcs = {(ex.lengthFt * ex.qty).toFixed(1)} ft
                    </span>{' '}
                    <span className="text-slate-400">({ex.gauge}mm)</span>
                  </div>
                  <button
                    onClick={() =>
                      onUpdateProjectExtras(projectExtras.filter((_, idx) => idx !== i))
                    }
                    className="text-rose-400 hover:text-rose-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 4: CUTTING CHART SCREEN                                         */}
      {/* =================================================================== */}
      {currentTab === 'CUTTING' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-[#F5B738]">
                Workshop Cutting Chart & 1D Stock Bar Optimization
              </h3>
              <p className="text-xs text-slate-400">
                Each stock bar (14/16/18ft or 15/17/19ft F-section) shows exact cut sizes and waste.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 rounded-lg bg-[#F5B738] text-black text-xs font-bold flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Share / Save PDF</span>
              </button>
              <button
                onClick={() => handleShareChartAsPng('CUTTING')}
                className="px-3.5 py-2 rounded-lg bg-emerald-500 text-black text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-400 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Share / Save Pic (PNG)</span>
              </button>
            </div>
          </div>

          {Object.keys(sectionPiecesMap).length === 0 ? (
            <div className="p-12 rounded-xl bg-[#14181F] border border-[#2B3441] text-center text-xs text-slate-400">
              Add windows or doors first to generate the cutting chart.
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(sectionPiecesMap).map(([section, pieces]) => {
                const packed = packSection(pieces, barLengthsFor(section));
                return (
                  <div
                    key={section}
                    className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#F5B738]">
                        {SECTION_LABELS[section] || section} ({section})
                      </span>
                      <span className="text-xs font-mono text-slate-400">
                        {packed.bins.length} Bar(s) Required
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {packed.bins.map((bar, bIdx) => (
                        <div
                          key={bIdx}
                          className="rounded-lg bg-[#0C0F14] border border-slate-800 overflow-hidden"
                        >
                          <div className="px-3 py-1.5 bg-[#1C222B] flex items-center justify-between text-xs font-mono">
                            <span className="font-bold text-white">
                              BAR #{bIdx + 1} · {bar.lenFt} FT {bar.isCustom ? '(OFFCUT)' : 'BAR'}
                            </span>
                            <span className="text-amber-300">
                              Waste: {formatDim(Math.max(0, bar.remainInches), measurementUnit)}
                            </span>
                          </div>
                          <div className="divide-y divide-slate-800/80 text-xs">
                            {bar.pieces.map((p, pIdx) => (
                              <div
                                key={pIdx}
                                className="px-3 py-1.5 flex items-center justify-between"
                              >
                                <div>
                                  <div className="font-semibold text-slate-200">{p.source}</div>
                                  <div className="text-[11px] text-slate-400">{p.label}</div>
                                </div>
                                <span className="text-sm font-mono font-bold text-[#F5B738] tabular-nums">
                                  {formatDim(p.length, measurementUnit)}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 5: LENGTH CHART & STOCK TALLY SCREEN                            */}
      {/* =================================================================== */}
      {currentTab === 'LENGTH' && (
        <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#F5B738]">
                Bar Length Chart & Stock Order Tally
              </h3>
              <p className="text-xs text-slate-400">
                Summary of stock lengths required per profile section.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 rounded-lg bg-[#F5B738] text-black text-xs font-bold flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Share / Save PDF</span>
              </button>
              <button
                onClick={() => handleShareChartAsPng('LENGTH')}
                className="px-3.5 py-2 rounded-lg bg-emerald-500 text-black text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-400 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Share / Save Pic (PNG)</span>
              </button>
            </div>
          </div>

          <div className="border border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#1C222B] text-slate-300">
                <tr>
                  <th className="py-2 px-3">Section Profile</th>
                  <th className="py-2 px-3">Stock Length Breakdown</th>
                  <th className="py-2 px-3 text-center">Total Bars</th>
                  <th className="py-2 px-3 text-right">Total Feet</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {Object.entries(sectionPiecesMap).map(([section, pieces]) => {
                  const packed = packSection(pieces, barLengthsFor(section));
                  let totalBars = 0;
                  let totalFt = 0;
                  const breakdown = Object.entries(packed.tally)
                    .sort((a, b) => Number(b[0]) - Number(a[0]))
                    .map(([len, info]) => {
                      totalBars += info.count;
                      totalFt += Number(len) * info.count;
                      return `${len}FT × ${info.count}${info.isCustom ? ' (offcut)' : ''}`;
                    })
                    .join(' · ');

                  return (
                    <tr key={section} className="hover:bg-slate-900/50">
                      <td className="py-2 px-3 font-bold text-[#F5B738]">
                        {SECTION_LABELS[section] || section} ({section})
                      </td>
                      <td className="py-2 px-3 text-amber-200">{breakdown}</td>
                      <td className="py-2 px-3 text-center text-white font-bold">
                        {totalBars}
                      </td>
                      <td className="py-2 px-3 text-right text-emerald-400 font-bold tabular-nums">
                        {totalFt} ft
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 6: GLASS CHART SCREEN (WITH SHARE PDF/PIC & GRAND TOTAL!)       */}
      {/* =================================================================== */}
      {currentTab === 'GLASS' && (
        <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <img
                src={activeShopLogoUrl}
                alt="Shop Logo"
                className="w-10 h-10 rounded-full object-cover border border-[#F5B738] shrink-0"
              />
              <div>
                <h3 className="text-sm font-bold text-[#F5B738]">
                  Glass Cutting & Billed Sq.Ft Schedule ({companyName})
                </h3>
                <p className="text-xs text-slate-400">
                  Billed size rounds UP to next 6-inch (half-foot) step.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {(['FIX_RUBBER', 'U_PVC'] as const).map((opt) => (
                <button
                  key={opt}
                  onClick={() => onSetGlassFittingOption(opt)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold ${
                    glassFittingOption === opt
                      ? 'bg-[#F5B738] text-black'
                      : 'bg-[#1C222B] text-slate-300 border border-slate-700'
                  }`}
                >
                  {opt === 'FIX_RUBBER' ? 'Fix Rubber (Standard)' : 'U(PVC) (-2 Sutar)'}
                </button>
              ))}
              <button
                onClick={() => window.print()}
                className="px-3.5 py-1.5 rounded-lg bg-[#F5B738] text-black text-xs font-bold flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Share / Save PDF</span>
              </button>
              <button
                onClick={() => handleShareChartAsPng('GLASS')}
                className="px-3.5 py-1.5 rounded-lg bg-emerald-500 text-black text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-400 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share / Save Pic (PNG)</span>
              </button>
            </div>
          </div>

          <div className="border border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#1C222B] text-slate-300">
                <tr>
                  <th className="py-2 px-3">Frame / Spec</th>
                  <th className="py-2 px-3">Cut Size (W × H)</th>
                  <th className="py-2 px-3">Billed (Ft)</th>
                  <th className="py-2 px-3 text-center">Pcs</th>
                  <th className="py-2 px-3 text-right">Sq.Ft</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {glassCuts.map((g, i) => (
                  <tr key={i} className="hover:bg-slate-900/50">
                    <td className="py-2 px-3 font-sans">
                      <div className="font-bold text-white">{g.frameLabel}</div>
                      <div className="text-[11px] text-amber-300">
                        {g.glassGauge}mm {g.glassColor} · Frame: {g.frameDim}
                      </div>
                    </td>
                    <td className="py-2 px-3 font-bold text-[#F5B738] tabular-nums">
                      {formatDim(g.gWpanel, measurementUnit)} × {formatDim(g.gH, measurementUnit)}
                    </td>
                    <td className="py-2 px-3 text-slate-300 tabular-nums">
                      {g.billedWFt} × {g.billedHFt} ft
                    </td>
                    <td className="py-2 px-3 text-center text-sky-400 font-bold">{g.pieces}</td>
                    <td className="py-2 px-3 text-right font-bold text-emerald-400 tabular-nums">
                      {g.sqft.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
              {/* Grand Total Footer Row at the end of Glass Chart Table */}
              <tfoot className="bg-[#1C222B] border-t-2 border-[#F5B738] font-mono text-xs">
                <tr>
                  <td colSpan={3} className="py-2.5 px-3 font-bold text-[#F5B738]">
                    GRAND TOTAL GLASS ({glassCuts.length} Frame Entries)
                  </td>
                  <td className="py-2.5 px-3 text-center font-black text-sky-300">
                    {totalGlassPieces} Pcs
                  </td>
                  <td className="py-2.5 px-3 text-right font-black text-emerald-400 tabular-nums">
                    {totalGlassSqFt.toFixed(2)} Sq.Ft
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* End-of-Glass-Chart Total Bill & Spec Summary Card */}
          <div className="p-4 rounded-xl bg-[#0C0F14] border border-[#F5B738]/70 space-y-2.5 text-xs font-mono">
            <div className="text-sm font-bold text-[#F5B738] font-sans">
              Glass Chart Grand Total Summary (Total Pieces, Total Sq.Ft & Total Glass Bill)
            </div>
            {activeQuote.glassLines.map((gl, idx) => (
              <div key={idx} className="flex items-center justify-between text-slate-300">
                <span>
                  {gl.description} ({gl.sqft.toFixed(2)} Sq.Ft × Rs {gl.rate}/sq.ft):
                </span>
                <span className="font-bold text-white">
                  Rs {Math.round(gl.total).toLocaleString()}
                </span>
              </div>
            ))}
            <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-sm font-black">
              <span className="text-sky-300">
                Total Glass Pieces: {totalGlassPieces} Pcs · Total Area: {totalGlassSqFt.toFixed(2)} Sq.Ft
              </span>
              <span className="text-[#F5B738] text-base">
                TOTAL GLASS BILL: Rs {Math.round(activeQuote.glassTotal).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 7: QUOTATION SCREEN (WITH BACKGROUND SETTINGS & SHARE PIC/PDF)  */}
      {/* =================================================================== */}
      {currentTab === 'QUOTATION' && (
        <div className="space-y-4">
          {/* Customer Details & Toolbar */}
          <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Customer Name</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => onSetCustomerInfo(e.target.value, customerPhone)}
                  placeholder="e.g. Tariq Mehmood"
                  className="w-full px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => onSetCustomerInfo(customerName, e.target.value)}
                  placeholder="0300-1234567"
                  className="w-full px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs font-mono text-white"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-lg bg-[#F5B738] text-black text-xs font-bold flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Share / Export PDF</span>
              </button>

              <button
                onClick={() => handleShareChartAsPng('QUOTATION')}
                className="px-4 py-2 rounded-lg bg-emerald-500 text-black text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-400 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Share / Save Pic (PNG)</span>
              </button>

              <button
                onClick={() => {
                  const summary = `${windows.length} Win, ${doors.length} Doors, ${fixframes.length} Fix`;
                  onSaveQuotationHistory({
                    id: Date.now(),
                    timestamp: new Date().toLocaleString('en-GB'),
                    label: `Quotation - ${customerName || 'Valued Client'}`,
                    customerName,
                    customerPhone,
                    gauge: ctxGauge,
                    color: ctxColor,
                    frameType: ctxFrameType,
                    grandTotal: activeQuote.grandTotal,
                    alumTotal: activeQuote.alumWithMarkup,
                    hardwareTotal: activeQuote.hardwareTotal,
                    glassTotal: activeQuote.glassTotal,
                    transportRent: activeQuote.transportRent,
                    labourCost: activeQuote.labourCost,
                    totalUnits: activeQuote.totalUnits,
                    itemsSummary: summary,
                    windowsJson: JSON.stringify(windows),
                    doorsJson: JSON.stringify(doors),
                    fixframesJson: JSON.stringify(fixframes),
                    openableWindowsJson: JSON.stringify(openableWindows),
                    slidingDoorsJson: JSON.stringify(slidingDoors),
                    projectExtrasJson: JSON.stringify(projectExtras),
                  });
                }}
                className="px-3.5 py-2 rounded-lg bg-[#1C222B] border border-slate-700 text-xs font-bold text-slate-200 hover:border-[#F5B738] flex items-center gap-1.5"
              >
                <Bookmark className="w-4 h-4 text-[#F5B738]" />
                <span>Save to History</span>
              </button>

              {layoutConfig.showCompareCFButton && (
                <button
                  onClick={() => setShowCompareCF(!showCompareCF)}
                  className="px-3.5 py-2 rounded-lg bg-[#1C222B] border border-sky-500/60 text-xs font-bold text-sky-400 flex items-center gap-1.5"
                >
                  <ArrowLeftRight className="w-4 h-4" />
                  <span>Compare Frame C vs Frame F</span>
                </button>
              )}

              {/* Quick Discount (%) Adjuster in Quotation Toolbar */}
              {layoutConfig.showDiscountRow && (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-emerald-500/60 text-xs">
                  <span className="text-emerald-400 font-bold">Discount (%):</span>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={markupPct}
                    onChange={(e) =>
                      onUpdateDefaults(
                        hardwareRate,
                        parseFloat(e.target.value) || 0,
                        transportRent,
                        labourCost
                      )
                    }
                    className="w-16 px-2 py-0.5 rounded bg-[#14181F] border border-slate-700 font-mono font-bold text-emerald-300 text-xs"
                  />
                </div>
              )}
            </div>

            {/* Direct Quotation Background, Letterhead Fit & Shop Logo Settings Bar right on the Quotation Chart! */}
            <div className="p-3 rounded-xl bg-[#0C0F14] border border-[#F5B738]/50 space-y-2.5 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-[#F5B738]">
                  Quotation Background, Letterhead Adjustment & Shop Logo Settings:
                </span>
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() =>
                      onUpdateLayoutConfig({
                        ...layoutConfig,
                        showLetterheadBackground: !layoutConfig.showLetterheadBackground,
                      })
                    }
                    className={`px-2.5 py-1 rounded text-[11px] font-black ${
                      layoutConfig.showLetterheadBackground
                        ? 'bg-emerald-500 text-black'
                        : 'bg-rose-600 text-white'
                    }`}
                  >
                    Background: {layoutConfig.showLetterheadBackground ? 'ON' : 'OFF'}
                  </button>

                  {(['STRETCH', 'COVER', 'CONTAIN'] as const).map((fm) => (
                    <button
                      key={fm}
                      onClick={() =>
                        onUpdateLayoutConfig({
                          ...layoutConfig,
                          letterheadFitMode: fm,
                        })
                      }
                      className={`px-2.5 py-1 rounded text-[10px] font-bold ${
                        (layoutConfig.letterheadFitMode || 'STRETCH') === fm
                          ? 'bg-[#F5B738] text-black'
                          : 'bg-[#14181F] text-slate-300 border border-slate-700'
                      }`}
                    >
                      {fm === 'STRETCH'
                        ? 'Full Page Fit'
                        : fm === 'COVER'
                        ? 'Cover Fill'
                        : 'Contain'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center pt-1">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-300 whitespace-nowrap">
                    Bg Brightness ({Math.round((layoutConfig.letterheadOpacity || 0.28) * 100)}%):
                  </span>
                  <input
                    type="range"
                    min={0.12}
                    max={0.75}
                    step={0.03}
                    value={layoutConfig.letterheadOpacity || 0.28}
                    onChange={(e) =>
                      onUpdateLayoutConfig({
                        ...layoutConfig,
                        letterheadOpacity: parseFloat(e.target.value) || 0.28,
                      })
                    }
                    className="accent-[#F5B738] flex-1"
                  />
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <label className="px-2.5 py-1.5 rounded-lg bg-emerald-500 text-black font-bold cursor-pointer flex items-center gap-1.5 text-[11px]">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Set Quotation Background</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) =>
                        handleImageFileUpload(
                          e,
                          onUpdateLetterheadBgUrl,
                          'Quotation Letterhead Background'
                        )
                      }
                      className="hidden"
                    />
                  </label>

                  <label className="px-2.5 py-1.5 rounded-lg bg-[#F5B738] text-black font-bold cursor-pointer flex items-center gap-1.5 text-[11px]">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Set Shop Logo (For Quotation)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) =>
                        handleImageFileUpload(
                          e,
                          (dataUrl) =>
                            onUpdateLayoutConfig({
                              ...layoutConfig,
                              shopLogoUrl: dataUrl,
                            }),
                          'Shop Logo for Quotation & Charts'
                        )
                      }
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="flex items-center justify-end gap-2">
                  {layoutConfig.shopLogoUrl && (
                    <button
                      onClick={() =>
                        onUpdateLayoutConfig({
                          ...layoutConfig,
                          shopLogoUrl: '',
                        })
                      }
                      className="px-2.5 py-1 rounded bg-slate-800 text-amber-300 text-[10px] font-semibold"
                    >
                      Use Default Lion Logo
                    </button>
                  )}
                  <button
                    onClick={() => {
                      onRestoreDefaultBrandingAssets();
                      showSettingsToast('Restored default Letterhead Background!');
                    }}
                    className="px-2.5 py-1 rounded bg-[#14181F] border border-slate-700 text-slate-300 hover:border-[#F5B738] text-[10px] font-semibold"
                  >
                    Reset Default Letterhead
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* C vs F Comparison Box */}
          {showCompareCF && (
            <div className="p-4 rounded-xl bg-[#14181F] border border-sky-500/60 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 space-y-1">
                <div className="font-bold text-[#F5B738]">FRAME C (DC30C / DC26C)</div>
                <div className="text-slate-300 font-mono">
                  Aluminium (After Discount): Rs {Math.round(quoteC.alumWithMarkup).toLocaleString()}
                </div>
                <div className="text-slate-300 font-mono">
                  Glass + Hardware: Rs {Math.round(quoteC.glassTotal + quoteC.hardwareTotal).toLocaleString()}
                </div>
                <div className="text-sm font-bold text-white font-mono pt-1">
                  Total Frame C: Rs {Math.round(quoteC.grandTotal).toLocaleString()}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#0C0F14] border border-slate-800 space-y-1">
                <div className="font-bold text-sky-400">FRAME F (DC30F / DC26F)</div>
                <div className="text-slate-300 font-mono">
                  Aluminium (After Discount): Rs {Math.round(quoteF.alumWithMarkup).toLocaleString()}
                </div>
                <div className="text-slate-300 font-mono">
                  Glass + Hardware: Rs {Math.round(quoteF.glassTotal + quoteF.hardwareTotal).toLocaleString()}
                </div>
                <div className="text-sm font-bold text-sky-300 font-mono pt-1">
                  Total Frame F: Rs {Math.round(quoteF.grandTotal).toLocaleString()}
                </div>
              </div>
            </div>
          )}

          {/* Official Printable Quotation Sheet - LOCKED ALWAYS TO AUTHENTIC A4 PORTRAIT FORMAT (210mm x 297mm) */}
          <div className="w-full flex justify-center py-4 px-1 overflow-x-auto">
            <div
              id="boss-official-a4-quotation-sheet"
              className="relative overflow-hidden w-full max-w-[794px] min-h-[1123px] rounded-2xl bg-[#0D1118] border-2 border-[#F5B738] p-6 sm:p-10 space-y-4 shadow-2xl flex flex-col justify-between my-2 shrink-0"
              style={{
                aspectRatio: '210 / 297',
              }}
            >
              {layoutConfig.showLetterheadBackground && letterheadBgUrl && (
                <img
                  src={letterheadBgUrl}
                  alt="Official Letterhead Background"
                  style={{ opacity: layoutConfig.letterheadOpacity || 0.28 }}
                  className="pointer-events-none select-none absolute inset-0 w-full h-full z-0 object-cover object-center"
                />
              )}

              <div className="relative z-10 space-y-4 flex-1 flex flex-col justify-between">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-[#F5B738]/60 pb-4">
                <div className="flex items-center gap-3.5">
                  <img
                    src={activeShopLogoUrl}
                    alt="Shop / Company Logo"
                    className="w-16 h-16 rounded-full object-cover border-2 border-[#F5B738] shadow-md shrink-0"
                  />
                  <div>
                    <h2 className="text-lg sm:text-xl font-black text-[#F5B738] tracking-wide">
                      {companyName || 'BOSS ALUMINIUM & GLASS'}
                    </h2>
                    <p className="text-xs text-amber-100 font-semibold">{companyTagline}</p>
                    <p className="text-[11px] text-slate-200">
                      Phone: {companyPhone} · Factory: {companyAddress} · NTN: {companyNtn}
                    </p>
                  </div>
                </div>
                <div className="text-right font-mono text-xs">
                  <div className="text-[#F5B738] font-black text-sm">OFFICIAL QUOTATION</div>
                  <div className="text-slate-200">
                    Date: {new Date().toLocaleDateString('en-GB')}
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#0C0F14]/70 backdrop-blur-[1px] border border-slate-700/80 flex flex-wrap items-center justify-between text-xs">
                <div>
                  <span className="text-slate-300">Customer:</span>{' '}
                  <strong className="text-white">{customerName || 'Valued Client'}</strong>{' '}
                  {customerPhone && `(${customerPhone})`}
                </div>
                <div className="font-mono text-amber-300">
                  Color: {ctxColor} · Gauge: {ctxGauge}mm · Frame: {ctxFrameType}
                </div>
              </div>

              <div className="border border-slate-700/80 rounded-xl overflow-hidden bg-[#0C0F14]/70 backdrop-blur-[1px]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#1C222B]/85 text-amber-300">
                    <tr>
                      <th className="py-2 px-3">Section / Item</th>
                      <th className="py-2 px-3 text-center">Bars</th>
                      <th className="py-2 px-3 text-center">Feet</th>
                      <th className="py-2 px-3 text-right">Rate/ft</th>
                      <th className="py-2 px-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-mono">
                    {activeQuote.aluminiumRows.map((row, idx) => (
                      <tr key={idx}>
                        <td className="py-2 px-3 text-white font-sans">
                          {SECTION_LABELS[row.section] || row.section}{' '}
                          <span className="text-slate-300 font-mono">({row.gauge}mm)</span>
                        </td>
                        <td className="py-2 px-3 text-center text-slate-200">{row.bars}</td>
                        <td className="py-2 px-3 text-center text-slate-200">{row.totalFt}</td>
                        <td className="py-2 px-3 text-right text-slate-200 tabular-nums">
                          Rs {Math.round(row.ratePerFt).toLocaleString()}
                        </td>
                        <td className="py-2 px-3 text-right font-bold text-[#F5B738] tabular-nums">
                          Rs {Math.round(row.cost).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Summary Totals with Discount (%) instead of Markup (%) */}
              <div className="p-4 rounded-xl bg-[#0C0F14]/75 backdrop-blur-[1px] border border-slate-700/80 space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-300">Aluminium Gross Total:</span>
                  <span className="text-white font-bold">
                    Rs {Math.round(activeQuote.alumTotal).toLocaleString()}
                  </span>
                </div>
                {layoutConfig.showDiscountRow && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount ({markupPct}%):</span>
                    <span className="font-bold">
                      - Rs{' '}
                      {Math.round(
                        Math.max(0, activeQuote.alumTotal - activeQuote.alumWithMarkup)
                      ).toLocaleString()}
                    </span>
                  </div>
                )}
                <div className="flex justify-between border-t border-slate-800 pt-1">
                  <span className="text-amber-300 font-semibold">
                    Aluminium Net Total (After Discount):
                  </span>
                  <span className="text-[#F5B738] font-bold">
                    Rs {Math.round(activeQuote.alumWithMarkup).toLocaleString()}
                  </span>
                </div>
                {layoutConfig.showHardwareRow && (
                  <div className="flex justify-between">
                    <span className="text-slate-300">
                      Hardware ({activeQuote.totalUnits} units × Rs {hardwareRate}):
                    </span>
                    <span className="text-white">
                      Rs {Math.round(activeQuote.hardwareTotal).toLocaleString()}
                    </span>
                  </div>
                )}
                {activeQuote.glassLines.map((gl, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span className="text-slate-300">
                      {gl.description} ({gl.sqft.toFixed(1)} sq.ft @ Rs {gl.rate}):
                    </span>
                    <span className="text-white">
                      Rs {Math.round(gl.total).toLocaleString()}
                    </span>
                  </div>
                ))}
                {layoutConfig.showTransportRow && activeQuote.transportRent > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-300">Transport Rent:</span>
                    <span className="text-white">
                      Rs {Math.round(activeQuote.transportRent).toLocaleString()}
                    </span>
                  </div>
                )}
                {layoutConfig.showLabourRow && activeQuote.labourCost > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-300">Labour / Installation:</span>
                    <span className="text-white">
                      Rs {Math.round(activeQuote.labourCost).toLocaleString()}
                    </span>
                  </div>
                )}
                <div className="border-t border-[#F5B738]/60 pt-2.5 flex items-center justify-between text-base font-black text-[#F5B738]">
                  <span>NET GRAND TOTAL:</span>
                  <span className="tabular-nums">
                    Rs {Math.round(activeQuote.grandTotal).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Official Letterhead Footer Terms & Signature */}
              <div className="pt-3 border-t border-[#F5B738]/30 flex flex-wrap items-end justify-between gap-4 text-[11px] text-slate-300">
                <div className="max-w-lg">
                  <strong className="text-[#F5B738]">Terms & Conditions:</strong>{' '}
                  {layoutConfig.quotationFooterTerms}
                </div>
                <div className="text-right font-semibold text-amber-200 border-t border-amber-400/50 pt-1">
                  {layoutConfig.quotationSignatureLabel}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )}

      {/* =================================================================== */}
      {/* TAB 8: HISTORY SCREEN                                               */}
      {/* =================================================================== */}
      {currentTab === 'HISTORY' && (
        <div className="space-y-3">
          <div className="p-3.5 rounded-xl bg-[#14181F] border border-[#2B3441] flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#F5B738]">
              Saved Quotations History ({savedQuotations.length})
            </h3>
            <input
              type="text"
              value={historySearch}
              onChange={(e) => setHistorySearch(e.target.value)}
              placeholder="Search customer or phone..."
              className="px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs text-white"
            />
          </div>

          {savedQuotations.length === 0 ? (
            <div className="p-12 rounded-xl bg-[#14181F] border border-[#2B3441] text-center text-xs text-slate-400">
              No saved quotations in history yet. Click "Save to History" on the Quotation tab.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {savedQuotations
                .filter(
                  (q) =>
                    !historySearch.trim() ||
                    q.label.toLowerCase().includes(historySearch.toLowerCase()) ||
                    q.customerName.toLowerCase().includes(historySearch.toLowerCase())
                )
                .map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-2.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-bold text-white text-sm">{item.label}</div>
                        <div className="text-[11px] text-slate-400">
                          {item.timestamp} · {item.gauge}mm · {item.color}
                        </div>
                      </div>
                      <div className="text-base font-mono font-black text-[#F5B738]">
                        Rs {Math.round(item.grandTotal).toLocaleString()}
                      </div>
                    </div>
                    <div className="text-slate-300">{item.itemsSummary}</div>
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <button
                        onClick={() => onRestoreQuotation(item)}
                        className="px-3 py-1.5 rounded-lg bg-[#F5B738] text-black font-bold"
                      >
                        Load into Calculator
                      </button>
                      <button
                        onClick={() => handleShareHistoryItemAsPng(item)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black font-bold flex items-center gap-1.5"
                        title="Share or Download Official Quotation Picture (PNG)"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Share Pic (PNG)</span>
                      </button>
                      <button
                        onClick={() => {
                          onRestoreQuotation(item);
                          setTimeout(() => window.print(), 350);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-sky-500 text-black font-bold flex items-center gap-1.5"
                        title="Open in Quotation & Share/Save as PDF"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Share PDF</span>
                      </button>
                      <button
                        onClick={() => onDeleteQuotationHistory(item.id)}
                        className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-300 font-semibold ml-auto"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 9: CLIENT APP LAYOUT SETTINGS & RATES SCREEN                    */}
      {/* (Contains all Client Settings, Branding, Units, Glass Fitting, etc) */}
      {/* =================================================================== */}
      {currentTab === 'RATES' && (
        <div className="space-y-4">
          {settingsNotice && (
            <div className="px-4 py-2.5 rounded-lg bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{settingsNotice}</span>
            </div>
          )}

          {/* 1. Main Golden Lion Logo & Quotation Letterhead Background */}
          <div className="p-4 rounded-xl bg-[#14181F] border border-[#F5B738]/70 space-y-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-[#F5B738]">
                  1. Main Golden Lion Logo & Official Quotation Letterhead Background
                </h3>
                <p className="text-slate-400">
                  Client App aur Quotation ke liye Main Logo aur Letterhead Background yahan se customize karein.
                </p>
              </div>
              <button
                onClick={() => {
                  onRestoreDefaultBrandingAssets();
                  showSettingsToast('Restored original Golden Lion Logo & Letterhead Background!');
                }}
                className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-[#F5B738]/60 text-[#F5B738] font-bold"
              >
                Restore Original Lion Logo & Letterhead
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* 1A. Official Client App Main Icon (Golden Lion Crest) */}
              <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-[#F5B738]/60 flex items-center gap-3.5">
                <img
                  src={mainLogoUrl}
                  alt="Boss Aluminium Lion Main Icon"
                  className="w-16 h-16 rounded-full object-cover border-2 border-[#F5B738] shrink-0"
                />
                <div className="space-y-1.5 flex-1">
                  <div className="font-bold text-[#F5B738]">
                    1. Client App Main Icon (Golden Lion Logo)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Yeh official Golden Lion Logo Client App ke Main App Icon / Launcher par show ho ga.
                  </div>
                  <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#1C222B] border border-[#F5B738] text-[#F5B738] font-bold cursor-pointer text-[11px]">
                    <Upload className="w-3 h-3" />
                    <span>Change Main App Icon</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) =>
                        handleImageFileUpload(e, onUpdateMainLogoUrl, 'Main App Icon Logo')
                      }
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* 1B. User's Custom Shop Logo (Shows on Quotation & All Charts) */}
              <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-emerald-500/60 flex items-center gap-3.5">
                <img
                  src={activeShopLogoUrl}
                  alt="Shop Logo for Quotation & Charts"
                  className="w-16 h-16 rounded-full object-cover border-2 border-emerald-400 shrink-0"
                />
                <div className="space-y-1.5 flex-1">
                  <div className="font-bold text-emerald-400">
                    2. Shop Logo (For Quotation & Charts)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Andar user jo bhi apni Shop ka logo set karay, wohi Quotation aur tamam Charts par show ho ga.
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500 text-black font-bold cursor-pointer text-[11px]">
                      <Upload className="w-3 h-3" />
                      <span>Upload Shop Logo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) =>
                          handleImageFileUpload(
                            e,
                            (dataUrl) =>
                              onUpdateLayoutConfig({
                                ...layoutConfig,
                                shopLogoUrl: dataUrl,
                              }),
                            'Shop Logo for Quotation & Charts'
                          )
                        }
                        className="hidden"
                      />
                    </label>
                    {layoutConfig.shopLogoUrl && (
                      <button
                        onClick={() =>
                          onUpdateLayoutConfig({
                            ...layoutConfig,
                            shopLogoUrl: '',
                          })
                        }
                        className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[10px]"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* 1C. Quotation Letterhead Background Card */}
              <div className="p-3.5 rounded-xl bg-[#0C0F14] border border-slate-800 flex items-center gap-3.5">
                <img
                  src={letterheadBgUrl}
                  alt="Quotation Letterhead Background"
                  className="w-16 h-20 rounded-lg object-cover border-2 border-[#F5B738] shrink-0"
                />
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">3. Quotation Background</span>
                    <button
                      onClick={() =>
                        onUpdateLayoutConfig({
                          ...layoutConfig,
                          showLetterheadBackground: !layoutConfig.showLetterheadBackground,
                        })
                      }
                      className={`px-2 py-0.5 rounded text-[10px] font-black ${
                        layoutConfig.showLetterheadBackground
                          ? 'bg-emerald-500 text-black'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {layoutConfig.showLetterheadBackground ? 'ON' : 'OFF'}
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-400">Opacity:</span>
                    <input
                      type="range"
                      min={0.12}
                      max={0.75}
                      step={0.03}
                      value={layoutConfig.letterheadOpacity || 0.28}
                      onChange={(e) =>
                        onUpdateLayoutConfig({
                          ...layoutConfig,
                          letterheadOpacity: parseFloat(e.target.value) || 0.28,
                        })
                      }
                      className="accent-[#F5B738] flex-1"
                    />
                  </div>
                  <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#F5B738] text-black font-bold cursor-pointer text-[11px]">
                    <Upload className="w-3 h-3" />
                    <span>Upload Letterhead</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) =>
                        handleImageFileUpload(
                          e,
                          onUpdateLetterheadBgUrl,
                          'Quotation Letterhead Background'
                        )
                      }
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* 2. Global Measurement Unit, Glass Rubber/U-PVC Fitting & Master Context Settings */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <h3 className="text-sm font-bold text-[#F5B738]">
                2. Global Measurement Unit, Glass Fitting & Master Context Settings
              </h3>

              <div className="space-y-2.5">
                <div className="p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300 font-semibold">Measurement Unit:</span>
                  <div className="flex items-center gap-1">
                    {(
                      [
                        { id: 'INCH_SUTAR', label: 'Inch.Sutar' },
                        { id: 'CM', label: 'CM' },
                        { id: 'MM', label: 'MM' },
                      ] as const
                    ).map((u) => (
                      <button
                        key={u.id}
                        onClick={() => onSetMeasurementUnit(u.id)}
                        className={`px-2.5 py-1 rounded font-bold ${
                          measurementUnit === u.id
                            ? 'bg-[#F5B738] text-black'
                            : 'bg-[#14181F] text-slate-300 border border-slate-700'
                        }`}
                      >
                        {u.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300 font-semibold">Glass Rubber / U-PVC Fitting:</span>
                  <div className="flex items-center gap-1">
                    {(['FIX_RUBBER', 'U_PVC'] as const).map((opt) => (
                      <button
                        key={opt}
                        onClick={() => onSetGlassFittingOption(opt)}
                        className={`px-2.5 py-1 rounded font-bold ${
                          glassFittingOption === opt
                            ? 'bg-[#F5B738] text-black'
                            : 'bg-[#14181F] text-slate-300 border border-slate-700'
                        }`}
                      >
                        {opt === 'FIX_RUBBER' ? 'Fix Rubber' : 'U(PVC) (-2 Sutar)'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300 font-semibold">Main Gauge Lock:</span>
                  <div className="flex items-center gap-2">
                    <select
                      value={ctxGauge}
                      onChange={(e) => onSetCtxGauge(e.target.value, ctxGaugeMode)}
                      className="px-2.5 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-[#F5B738]"
                    >
                      {GAUGES.map((g) => (
                        <option key={g} value={g}>
                          {g}mm
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() =>
                        onSetCtxGauge(ctxGauge, ctxGaugeMode === 'ON' ? 'OFF' : 'ON')
                      }
                      className={`px-2.5 py-1 rounded font-black ${
                        ctxGaugeMode === 'ON'
                          ? 'bg-emerald-500 text-black'
                          : 'bg-rose-600 text-white'
                      }`}
                    >
                      {ctxGaugeMode === 'ON' ? 'ON (Locked)' : 'OFF (Separate Unlocked)'}
                    </button>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300 font-semibold">Main Glass Lock:</span>
                  <div className="flex items-center gap-2">
                    <select
                      value={`${ctxGlassGauge}|${ctxGlassColor}`}
                      onChange={(e) => {
                        const [g, c] = e.target.value.split('|');
                        onSetCtxGlass(g, c, ctxGlassMode);
                      }}
                      className="px-2 py-1 rounded bg-[#14181F] border border-slate-700 text-amber-200 font-bold"
                    >
                      {['5', '8'].flatMap((g) =>
                        (g === '8' ? glassColors8mm : glassColors5mm).map(
                          (gc) => (
                            <option key={`${g}|${gc}`} value={`${g}|${gc}`}>
                              {g}mm · {gc}
                            </option>
                          )
                        )
                      )}
                    </select>
                    <button
                      onClick={() =>
                        onSetCtxGlass(
                          ctxGlassGauge,
                          ctxGlassColor,
                          ctxGlassMode === 'ON' ? 'OFF' : 'ON'
                        )
                      }
                      className={`px-2.5 py-1 rounded font-black ${
                        ctxGlassMode === 'ON'
                          ? 'bg-emerald-500 text-black'
                          : 'bg-rose-600 text-white'
                      }`}
                    >
                      {ctxGlassMode === 'ON' ? 'ON (Locked)' : 'OFF (Separate Unlocked)'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 3. Separate 5mm & 8mm Glass Colors (Add, Edit Rate & Delete Separately!) */}
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    3. Separate 5mm & 8mm Glass Colors & Sq.Ft Rates (Add & Delete Separately)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    5mm aur 8mm Glass mein alag-alag koi bhi نیا color Add karein ya kisi bhi color ko Delete (✕) karein.
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={onExportFullBackup}
                    className="px-2.5 py-1 rounded-lg bg-[#F5B738] text-black font-bold flex items-center gap-1"
                  >
                    <Download className="w-3 h-3" />
                    <span>Backup JSON</span>
                  </button>
                  <label className="px-2.5 py-1 rounded-lg bg-emerald-500 text-black font-bold cursor-pointer flex items-center gap-1">
                    <Upload className="w-3 h-3" />
                    <span>Restore JSON</span>
                    <input
                      type="file"
                      accept="application/json,.json"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (!f) return;
                        const reader = new FileReader();
                        reader.onload = () => {
                          const ok = onImportFullBackup(String(reader.result || ''));
                          showSettingsToast(
                            ok ? 'Backup restored!' : 'Invalid backup JSON file.'
                          );
                        };
                        reader.readAsText(f);
                        e.target.value = '';
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* 3A: 5mm Glass Colors Box */}
                <div className="p-3 rounded-xl bg-[#0C0F14] border border-sky-500/40 space-y-2.5">
                  <div className="font-bold text-sky-400 flex items-center justify-between">
                    <span>5mm Glass Colors ({glassColors5mm.length})</span>
                    <span className="text-[10px] font-mono text-slate-400">5mm Only</span>
                  </div>

                  {/* Add to 5mm Only */}
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={newGlass5Color}
                      onChange={(e) => setNewGlass5Color(e.target.value.toUpperCase())}
                      placeholder="5mm Color (e.g. GREEN)"
                      className="flex-1 min-w-0 px-2 py-1 rounded bg-[#14181F] border border-slate-700 text-white"
                    />
                    <input
                      type="number"
                      value={newGlass5Rate}
                      onChange={(e) => setNewGlass5Rate(e.target.value)}
                      placeholder="Rate"
                      className="w-16 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-amber-300"
                    />
                    <button
                      onClick={() => {
                        const col = newGlass5Color.trim().toUpperCase();
                        if (!col) return;
                        onAddGlassColor('5', col, parseFloat(newGlass5Rate) || 200);
                        setNewGlass5Color('');
                        showSettingsToast(`Added "${col}" to 5mm Glass!`);
                      }}
                      className="px-2.5 py-1 rounded bg-sky-400 text-black font-bold shrink-0"
                    >
                      + 5mm
                    </button>
                  </div>

                  <div className="space-y-1.5 max-h-44 overflow-y-auto">
                    {Object.entries(glassRates['5'] || {}).map(([col, r]) => (
                      <div
                        key={`5-${col}`}
                        className="p-2 rounded-lg bg-[#14181F] border border-slate-800 flex items-center justify-between gap-2"
                      >
                        <span className="font-bold text-sky-300 truncate">{col}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-slate-400">Rs</span>
                          <input
                            type="number"
                            value={r}
                            onChange={(e) =>
                              onUpdateGlassRate('5', col, parseFloat(e.target.value) || 0)
                            }
                            className="w-16 px-1.5 py-0.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white text-right"
                          />
                          <button
                            onClick={() => {
                              onDeleteGlassColor('5', col);
                              showSettingsToast(`Deleted "${col}" from 5mm Glass (Saved to Backup)`);
                            }}
                            className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-600 hover:text-white font-bold"
                            title="Delete this color from 5mm Glass"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3B: 8mm Glass Colors Box */}
                <div className="p-3 rounded-xl bg-[#0C0F14] border border-amber-500/40 space-y-2.5">
                  <div className="font-bold text-[#F5B738] flex items-center justify-between">
                    <span>8mm Glass Colors ({glassColors8mm.length})</span>
                    <span className="text-[10px] font-mono text-slate-400">8mm Only</span>
                  </div>

                  {/* Add to 8mm Only */}
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={newGlass8Color}
                      onChange={(e) => setNewGlass8Color(e.target.value.toUpperCase())}
                      placeholder="8mm Color (e.g. BRONZE)"
                      className="flex-1 min-w-0 px-2 py-1 rounded bg-[#14181F] border border-slate-700 text-white"
                    />
                    <input
                      type="number"
                      value={newGlass8Rate}
                      onChange={(e) => setNewGlass8Rate(e.target.value)}
                      placeholder="Rate"
                      className="w-16 px-2 py-1 rounded bg-[#14181F] border border-slate-700 font-mono text-amber-300"
                    />
                    <button
                      onClick={() => {
                        const col = newGlass8Color.trim().toUpperCase();
                        if (!col) return;
                        onAddGlassColor('8', col, parseFloat(newGlass8Rate) || 320);
                        setNewGlass8Color('');
                        showSettingsToast(`Added "${col}" to 8mm Glass!`);
                      }}
                      className="px-2.5 py-1 rounded bg-[#F5B738] text-black font-bold shrink-0"
                    >
                      + 8mm
                    </button>
                  </div>

                  <div className="space-y-1.5 max-h-44 overflow-y-auto">
                    {Object.entries(glassRates['8'] || {}).map(([col, r]) => (
                      <div
                        key={`8-${col}`}
                        className="p-2 rounded-lg bg-[#14181F] border border-slate-800 flex items-center justify-between gap-2"
                      >
                        <span className="font-bold text-amber-300 truncate">{col}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-slate-400">Rs</span>
                          <input
                            type="number"
                            value={r}
                            onChange={(e) =>
                              onUpdateGlassRate('8', col, parseFloat(e.target.value) || 0)
                            }
                            className="w-16 px-1.5 py-0.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white text-right"
                          />
                          <button
                            onClick={() => {
                              onDeleteGlassColor('8', col);
                              showSettingsToast(`Deleted "${col}" from 8mm Glass (Saved to Backup)`);
                            }}
                            className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-600 hover:text-white font-bold"
                            title="Delete this color from 8mm Glass"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 4. Aluminium Finish Colors & Sections Add / Edit / Delete Manager */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 4A. Add, Edit or Delete Profile Finish Colors */}
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#F5B738]">
                    4A. Aluminium Finish Colors — Add, Edit & Delete ({availableColors.length})
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Kisi bhi Color ko Edit ya Delete (✕) karein (Delete kiya hua color Backup mein save rehta hai).
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newColorInput}
                  onChange={(e) => setNewColorInput(e.target.value.toUpperCase())}
                  placeholder="New Finish Color (e.g. CHAMPAGNE)"
                  className="flex-1 px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-white"
                />
                <button
                  onClick={() => {
                    if (!newColorInput.trim()) return;
                    onAddColor(newColorInput.trim());
                    setNewColorInput('');
                    showSettingsToast('Color added!');
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-[#F5B738] text-black font-bold"
                >
                  + Add Color
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {availableColors.map((col) => (
                  <div
                    key={col}
                    className="px-2.5 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-800 flex items-center gap-2"
                  >
                    {editingColorName === col ? (
                      <>
                        <input
                          type="text"
                          value={editingColorVal}
                          onChange={(e) => setEditingColorVal(e.target.value.toUpperCase())}
                          className="w-24 px-1.5 py-0.5 rounded bg-[#14181F] border border-amber-400 text-white font-mono text-xs"
                        />
                        <button
                          onClick={() => {
                            if (editingColorVal.trim()) {
                              onEditColor(col, editingColorVal.trim().toUpperCase());
                              showSettingsToast(`Renamed color ${col} → ${editingColorVal.trim().toUpperCase()}`);
                            }
                            setEditingColorName(null);
                          }}
                          className="px-2 py-0.5 rounded bg-emerald-500 text-black font-bold text-[10px]"
                        >
                          Save
                        </button>
                      </>
                    ) : (
                      <>
                        <span className="font-mono font-bold text-amber-300">{col}</span>
                        <button
                          onClick={() => {
                            setEditingColorName(col);
                            setEditingColorVal(col);
                          }}
                          className="text-[10px] text-sky-400 hover:underline font-bold"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => {
                            onDeleteColor(col);
                            showSettingsToast(`Deleted color "${col}" (Saved in Backup Vault)`);
                          }}
                          className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-600 hover:text-white font-bold"
                          title="Delete Color"
                        >
                          ✕
                        </button>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 4B. Add New Aluminium Section or Restore from Deleted Backup Vault */}
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <div>
                <h3 className="text-sm font-bold text-[#F5B738]">
                  4B. Add New Aluminium Section + Deleted Items Backup Vault ({deletedBackupVault.length})
                </h3>
                <p className="text-[11px] text-slate-400">
                  Naya Section add karein, ya jo Section / Color / Glass delete kiya ho usay 1-Click mein Backup se wapas layein.
                </p>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newSecCodeInput}
                  onChange={(e) => setNewSecCodeInput(e.target.value.toUpperCase())}
                  placeholder="Section Code (e.g. CW50, D60)"
                  className="flex-1 px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 font-mono text-white"
                />
                <input
                  type="number"
                  value={newSecRateInput}
                  onChange={(e) => setNewSecRateInput(e.target.value)}
                  placeholder="Rate/ft"
                  className="w-24 px-2.5 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 font-mono text-amber-300"
                />
                <button
                  onClick={() => {
                    if (!newSecCodeInput.trim()) return;
                    onAddCustomSection(
                      newSecCodeInput.trim(),
                      parseFloat(newSecRateInput) || 750
                    );
                    setNewSecCodeInput('');
                    showSettingsToast(`Added section "${newSecCodeInput.trim().toUpperCase()}"!`);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-500 text-black font-bold shrink-0"
                >
                  + Add Section
                </button>
              </div>

              {deletedBackupVault.length > 0 && (
                <div className="p-3 rounded-xl bg-[#0C0F14] border border-amber-500/50 space-y-2 max-h-40 overflow-y-auto">
                  <div className="text-[11px] font-bold text-[#F5B738]">
                    ♻️ Deleted Items Backup Vault (Click Restore to Add Back):
                  </div>
                  {deletedBackupVault.map((bItem) => (
                    <div
                      key={bItem.id}
                      className="p-2 rounded bg-[#14181F] border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div>
                        <span className="text-[10px] font-mono text-amber-300">
                          [{bItem.category}]
                        </span>{' '}
                        <span className="font-bold text-white">{bItem.title}</span>
                      </div>
                      <button
                        onClick={() => {
                          onRestoreBackupItem(bItem.id);
                          showSettingsToast(`Restored "${bItem.title}" from Backup!`);
                        }}
                        className="px-2.5 py-1 rounded bg-emerald-500 text-black font-bold text-[10px]"
                      >
                        ♻️ Restore
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Section Rates, Visibility (Hide/Unhide) & Direct Delete Control Grid */}
          <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-[#F5B738]">
                  5. Section Rates, Hide/Unhide & Delete Section Control
                </h3>
                <p className="text-xs text-slate-400">
                  Har section ka Rate edit karein, Eye icon se Hide karein, ya Trash (✕) button se Section Delete karein (Backup mein save ho ga).
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {hiddenSections.length > 0 && (
                  <button
                    onClick={onUnhideAllSections}
                    className="px-3 py-1.5 rounded-lg bg-amber-500/20 border border-[#F5B738] text-xs font-bold text-[#F5B738]"
                  >
                    Unhide All ({hiddenSections.length})
                  </button>
                )}
                <button
                  onClick={() => setConfirmClearRates(true)}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All Rate List Data</span>
                </button>
                <button
                  onClick={onRestoreDefaultRates}
                  className="px-3 py-1.5 rounded-lg bg-[#1C222B] border border-slate-700 text-slate-200 hover:border-[#F5B738] text-xs font-semibold"
                >
                  Restore Default Rates
                </button>
              </div>
            </div>

            {confirmClearRates && (
              <div className="p-3.5 rounded-xl bg-rose-950 border-2 border-rose-500 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="font-bold text-white">
                  Confirm: Kya aap Rate List ka sara data Clear (0) karna chahtay hain?
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onClearAllRates();
                      setConfirmClearRates(false);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
                  >
                    Yes, Clear All Rates to 0
                  </button>
                  <button
                    onClick={() => setConfirmClearRates(false)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-200"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={rateGaugeTab}
                onChange={(e) => setRateGaugeTab(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs font-bold text-white"
              >
                {GAUGES.map((g) => (
                  <option key={g} value={g}>
                    Gauge: {g}mm
                  </option>
                ))}
              </select>

              <select
                value={rateColorTab}
                onChange={(e) => setRateColorTab(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs font-bold text-amber-300"
              >
                {availableColors.map((c) => (
                  <option key={c} value={c}>
                    Color: {c}
                  </option>
                ))}
              </select>

              <input
                type="text"
                value={rateSearch}
                onChange={(e) => setRateSearch(e.target.value)}
                placeholder="Search section code (e.g. DC30C, M24, D54A)..."
                className="flex-1 min-w-[180px] px-3 py-1.5 rounded-lg bg-[#0C0F14] border border-slate-700 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-[380px] overflow-y-auto pr-1">
              {Array.from(
                new Set([
                  ...Object.keys(
                    rates[rateGaugeTab]?.[rateColorTab] || rates['1.2']?.['DULL'] || {}
                  ),
                  ...customSections,
                ])
              )
                .filter((sec) => !deletedSecs.includes(sec))
                .filter(
                  (sec) =>
                    !rateSearch.trim() ||
                    sec.toLowerCase().includes(rateSearch.trim().toLowerCase())
                )
                .map((sec) => {
                  const isHidden = hiddenSections.includes(sec);
                  const val = rates[rateGaugeTab]?.[rateColorTab]?.[sec] ?? 0;
                  return (
                    <div
                      key={sec}
                      className={`p-2 rounded-lg border space-y-1.5 ${
                        isHidden
                          ? 'bg-[#0C0F14]/50 border-rose-900/50 opacity-60'
                          : 'bg-[#0C0F14] border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-bold text-[#F5B738] font-mono truncate">
                          {sec}
                        </span>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => onToggleHideSection(sec)}
                            className="text-slate-400 hover:text-white p-0.5"
                            title={isHidden ? 'Unhide Section' : 'Hide Section'}
                          >
                            {isHidden ? (
                              <EyeOff className="w-3.5 h-3.5 text-amber-400" />
                            ) : (
                              <Eye className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            onClick={() => {
                              onDeleteSection(sec);
                              showSettingsToast(`Deleted section "${sec}" (Saved in Backup Vault)`);
                            }}
                            className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-600 hover:text-white text-[10px] font-bold"
                            title="Delete Section (Moves to Backup Vault)"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 bg-[#14181F] px-2 py-1 rounded border border-slate-700">
                        <span className="text-[10px] text-slate-400">Rs</span>
                        <input
                          type="number"
                          value={val}
                          onChange={(e) =>
                            onUpdateSectionRate(
                              rateGaugeTab,
                              rateColorTab,
                              sec,
                              parseFloat(e.target.value) || 0
                            )
                          }
                          className="w-full bg-transparent text-xs font-mono font-bold text-white focus:outline-none"
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Hardware, Markup, Transport, Labour & Company Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <h4 className="text-sm font-bold text-[#F5B738]">
                Hardware, Discount (%) & Quotation Defaults
              </h4>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Hardware / Unit (Rs)
                  </label>
                  <input
                    type="number"
                    value={hardwareRate}
                    onChange={(e) =>
                      onUpdateDefaults(
                        parseFloat(e.target.value) || 0,
                        markupPct,
                        transportRent,
                        labourCost
                      )
                    }
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-emerald-400 font-bold mb-1">
                    Discount (%)
                  </label>
                  <input
                    type="number"
                    value={markupPct}
                    onChange={(e) =>
                      onUpdateDefaults(
                        hardwareRate,
                        parseFloat(e.target.value) || 0,
                        transportRent,
                        labourCost
                      )
                    }
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-emerald-500/60 font-mono font-bold text-emerald-300"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Transport Rent (Rs)
                  </label>
                  <input
                    type="number"
                    value={transportRent}
                    onChange={(e) =>
                      onUpdateDefaults(
                        hardwareRate,
                        markupPct,
                        parseFloat(e.target.value) || 0,
                        labourCost
                      )
                    }
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Labour Cost (Rs)
                  </label>
                  <input
                    type="number"
                    value={labourCost}
                    onChange={(e) =>
                      onUpdateDefaults(
                        hardwareRate,
                        markupPct,
                        transportRent,
                        parseFloat(e.target.value) || 0
                      )
                    }
                    className="w-full px-2.5 py-1.5 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#14181F] border border-[#2B3441] space-y-3 text-xs">
              <h4 className="text-sm font-bold text-[#F5B738]">
                Company Letterhead & Branding Info
              </h4>
              <div className="space-y-2">
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) =>
                    onUpdateCompanyInfo({
                      name: e.target.value,
                      tagline: companyTagline,
                      address: companyAddress,
                      phone: companyPhone,
                      ntn: companyNtn,
                    })
                  }
                  placeholder="Company Name"
                  className="w-full px-3 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-white"
                />
                <input
                  type="text"
                  value={companyPhone}
                  onChange={(e) =>
                    onUpdateCompanyInfo({
                      name: companyName,
                      tagline: companyTagline,
                      address: companyAddress,
                      phone: e.target.value,
                      ntn: companyNtn,
                    })
                  }
                  placeholder="Company Phone"
                  className="w-full px-3 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-white"
                />
                <input
                  type="text"
                  value={companyAddress}
                  onChange={(e) =>
                    onUpdateCompanyInfo({
                      name: companyName,
                      tagline: companyTagline,
                      address: e.target.value,
                      phone: companyPhone,
                      ntn: companyNtn,
                    })
                  }
                  placeholder="Factory / Shop Address"
                  className="w-full px-3 py-1.5 rounded bg-[#0C0F14] border border-slate-700 text-white"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Section Pair Modal (2 in 1: 2H+1W & 1W) */}
      {showAddPairModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#14181F] border border-[#F5B738] p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#F5B738]">
                Add Frame Section Pair (2 in 1: 2H+1W & 1W)
              </h3>
              <button
                onClick={() => setShowAddPairModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <p className="text-slate-400">
              Section 1 counts as 2 Heights + 1 Top Width. Section 2 counts as 1 Bottom Track Width (like DC30C / DC26C).
            </p>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={pairSec1}
                onChange={(e) => setPairSec1(e.target.value.toUpperCase())}
                placeholder="Sec 1 (e.g. DC30C)"
                className="px-3 py-2 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
              />
              <input
                type="number"
                value={pairRate1}
                onChange={(e) => setPairRate1(e.target.value)}
                placeholder="Sec 1 Rate/ft"
                className="px-3 py-2 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
              />
              <input
                type="text"
                value={pairSec2}
                onChange={(e) => setPairSec2(e.target.value.toUpperCase())}
                placeholder="Sec 2 (e.g. DC26C)"
                className="px-3 py-2 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
              />
              <input
                type="number"
                value={pairRate2}
                onChange={(e) => setPairRate2(e.target.value)}
                placeholder="Sec 2 Rate/ft"
                className="px-3 py-2 rounded bg-[#0C0F14] border border-slate-700 font-mono text-white"
              />
            </div>
            <button
              onClick={() => {
                if (!pairSec1.trim()) return;
                onAddCustomSectionPair(
                  pairSec1.trim(),
                  parseFloat(pairRate1) || 0,
                  pairSec2.trim(),
                  parseFloat(pairRate2) || 0
                );
                setShowAddPairModal(false);
                setPairSec1('');
                setPairSec2('');
              }}
              className="w-full py-2.5 rounded-lg bg-[#F5B738] text-black font-bold"
            >
              Save Section Pair
            </button>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL: CLIENT PACKAGES, ACTIVE OFFERS & BANK TRANSFER INSTRUCTIONS  */}
      {/* =================================================================== */}
      {showPackagesModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-[#0C1017] border-2 border-amber-500/80 rounded-2xl max-w-4xl w-full p-4 sm:p-6 space-y-5 shadow-2xl my-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-black flex items-center justify-center font-black shrink-0">
                  <Zap className="w-5 h-5 text-black" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black text-[#F5B738] tracking-wide">
                    BOSS Mobile App Subscription Packages & Special Offers
                  </h3>
                  <div className="text-[11px] text-slate-400">
                    Official verified plans & direct bank transfer activation
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPackagesModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800/60"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
              {/* Active Offer Callout */}
              {activeOffer && activeOffer.isActive && (
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-amber-500/20 border border-amber-500/60 flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-600 text-white font-black uppercase">
                        {activeOffer.badgeText || 'OFFER'}
                      </span>
                      <span className="text-xs font-black text-white">{activeOffer.title}</span>
                      {activeOffer.discountPct && activeOffer.discountPct > 0 && (
                        <span className="text-[11px] font-black text-amber-300 bg-amber-950/70 px-2 py-0.5 rounded border border-amber-500/40">
                          {activeOffer.discountPct}% DISCOUNT ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1">{activeOffer.message}</p>
                  </div>
                </div>
              )}

              {/* Packages Cards Grid */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                    Available Packages ({packages.length})
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Direct instant activation upon TID receipt verification
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  {packages.map((pkg, idx) => {
                    const hasDiscount =
                      (pkg.discountPct && pkg.discountPct > 0) ||
                      (pkg.originalPriceRs && pkg.originalPriceRs > (pkg.priceRs ?? pkg.price ?? 0));
                    const origPrice = pkg.originalPriceRs ?? pkg.priceRs ?? pkg.price ?? 0;
                    const curPrice = pkg.priceRs ?? pkg.price ?? origPrice;
                    const discPct = pkg.discountPct ?? (origPrice > curPrice ? Math.round(((origPrice - curPrice) / origPrice) * 100) : 0);

                    return (
                      <div
                        key={pkg.id || idx}
                        className={`p-4 rounded-xl bg-[#141A24] border ${
                          hasDiscount
                            ? 'border-amber-500/80 shadow-lg shadow-amber-950/30'
                            : 'border-slate-800'
                        } flex flex-col justify-between space-y-3 relative`}
                      >
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-1.5">
                            <div>
                              <div className="font-black text-white text-sm">{pkg.name}</div>
                              <span className="text-[10px] text-slate-400 font-mono uppercase">
                                {pkg.planCode}
                              </span>
                            </div>
                            {(pkg.badge || pkg.badgeText) && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500 text-black font-extrabold shadow-sm">
                                {pkg.badge || pkg.badgeText}
                              </span>
                            )}
                          </div>

                          <div className="pt-1">
                            {hasDiscount ? (
                              <div>
                                <div className="flex items-baseline gap-2 flex-wrap">
                                  <span className="text-2xl font-black text-emerald-400">
                                    Rs. {curPrice.toLocaleString()}
                                  </span>
                                  <span className="text-xs line-through text-slate-400">
                                    Rs. {origPrice.toLocaleString()}
                                  </span>
                                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-600 text-white font-black animate-pulse">
                                    {discPct}% OFF
                                  </span>
                                </div>
                                {pkg.discountOfferText && (
                                  <div className="text-[11px] text-amber-300 font-semibold italic mt-0.5">
                                    ⚡ {pkg.discountOfferText}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="text-2xl font-black text-amber-400">
                                Rs. {curPrice.toLocaleString()}
                              </div>
                            )}
                            <div className="text-slate-400 text-[11px] mt-0.5">
                              Duration: {pkg.durationLabel || `${pkg.durationMonths} Month(s)`}
                            </div>
                          </div>

                          <ul className="space-y-1.5 text-slate-300 border-t border-slate-800 pt-2">
                            {(pkg.features || []).map((f, fi) => (
                              <li key={fi} className="flex items-start gap-1.5 text-[11px] leading-tight">
                                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                                <span>{f}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <a
                          href={`https://wa.me/923105524225?text=${encodeURIComponent(
                            `Assalam-o-Alaikum Syed Saboor Nawab Sahib, I want to activate the "${pkg.name}" (Price: Rs. ${curPrice.toLocaleString()}) for BOSS Aluminium App. Kindly share payment details.`
                          )}`}
                          target="_blank"
                          rel="noreferrer"
                          className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950/40 transition-colors"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Pay Rs. {curPrice.toLocaleString()} & Activate</span>
                        </a>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Official Bank Accounts for Payment Transfer */}
              <div className="p-4 rounded-xl bg-[#141A24] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#F5B738] uppercase tracking-wide">
                      Official Bank Accounts & Wallets ({bankAccounts.length})
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Click copy button to copy account number / IBAN
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {bankAccounts.map((acc, aidx) => (
                    <div
                      key={acc.id || aidx}
                      className="p-3.5 rounded-xl bg-[#0C1017] border border-slate-700/80 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-400 text-sm">{acc.bankName}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono uppercase">
                          {acc.accountType || 'BANK'}
                        </span>
                      </div>

                      <div className="space-y-1 text-slate-300 text-[11px]">
                        <div>Account Title: <strong className="text-white">{acc.accountTitle}</strong></div>
                        <div className="flex items-center justify-between gap-2 bg-[#141A24] p-1.5 rounded-lg border border-slate-800 font-mono">
                          <span className="text-emerald-400 font-bold">{acc.accountNumber}</span>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(acc.accountNumber);
                              setCopiedBankId(acc.id || String(aidx));
                              showSettingsToast(`Copied ${acc.bankName} Account Number!`);
                              setTimeout(() => setCopiedBankId(null), 2500);
                            }}
                            className="px-2 py-0.5 rounded bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-black flex items-center gap-1 transition-colors"
                          >
                            <Copy className="w-3 h-3" />
                            <span>{copiedBankId === (acc.id || String(aidx)) ? 'Copied!' : 'Copy'}</span>
                          </button>
                        </div>
                        {acc.ibanOrRaast && (
                          <div className="text-[10px] text-slate-400 font-mono truncate">
                            IBAN / Raast: {acc.ibanOrRaast}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* WhatsApp Support Callout */}
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div className="text-xs text-emerald-200">
                    Payment bhejne ke baad screenshot <strong>0310-5524225</strong> par WhatsApp karein. Aap ka account foran unlock/activate ho jaye ga!
                  </div>
                </div>
                <a
                  href="https://wa.me/923105524225?text=Assalam-o-Alaikum%20Syed%20Saboor%20Nawab%20Sahib,%20I%20have%20sent%20payment%20for%20BOSS%20Aluminium%20App%20subscription.%20Kindly%20find%20attached%20receipt."
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950/60"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Send Receipt on WhatsApp</span>
                </a>
              </div>
            </div>

            <div className="flex justify-end border-t border-slate-800 pt-3">
              <button
                type="button"
                onClick={() => setShowPackagesModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
