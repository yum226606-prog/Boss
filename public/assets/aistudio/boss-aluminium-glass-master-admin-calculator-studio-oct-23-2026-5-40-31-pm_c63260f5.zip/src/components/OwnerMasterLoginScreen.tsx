import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Lock,
  KeyRound,
  Mail,
  ArrowRight,
  Eye,
  EyeOff,
  Sparkles,
  Fingerprint,
} from 'lucide-react';
import {
  OWNER_VIP_EMAILS,
  SECURITY_MASTER_PIN,
  MASTER_PASSCODES,
  OWNER_NAME,
} from '../utils/bossDefaultRates';
import bossLionLogoImg from '../assets/images/boss_lion_logo_1791741005749.jpg';

interface OwnerMasterLoginScreenProps {
  onLoginSuccess: (email: string) => void;
}

export const OwnerMasterLoginScreen: React.FC<OwnerMasterLoginScreenProps> = ({
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState<string>(OWNER_VIP_EMAILS[0]);
  const [pin, setPin] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsVerifying(true);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPin = pin.trim().toUpperCase();

    setTimeout(() => {
      // 1. Verify Email is an authorized Owner VIP Email
      const isAuthorizedEmail = OWNER_VIP_EMAILS.some(
        (vip) => vip.toLowerCase() === cleanEmail
      );

      if (!isAuthorizedEmail) {
        setIsVerifying(false);
        setErrorMessage(
          'ACCESS DENIED: Email is not authorized. Only Owner VIP accounts can access the Master Vault.'
        );
        return;
      }

      // 2. Verify Secret Master Passcode (2796 removed per owner request - only 2 strong passcodes accepted)
      const isAuthorizedPin = MASTER_PASSCODES.some((p) => p.toUpperCase() === cleanPin);

      if (!isAuthorizedPin) {
        setIsVerifying(false);
        setErrorMessage(
          'ACCESS DENIED: Incorrect Master Passcode. Entry prohibited.'
        );
        return;
      }

      // 3. Authenticate and create persistent session
      const sessionData = {
        email: cleanEmail,
        name: OWNER_NAME,
        authenticatedAt: Date.now(),
        vaultToken: `BOSS_VIP_AUTH_${Date.now()}`,
      };
      try {
        localStorage.setItem('boss_owner_master_session', JSON.stringify(sessionData));
      } catch {
        // ignore storage error
      }

      setIsVerifying(false);
      onLoginSuccess(cleanEmail);
    }, 400);
  };

  return (
    <div className="min-h-screen w-full bg-[#070A0F] text-slate-100 flex flex-col justify-between items-center p-4 relative overflow-hidden select-none">
      {/* Background Decorative Glow Elements */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-2xl h-96 bg-[#F5B738]/5 rounded-full blur-3xl pointer-events-none" />

      {/* Top Security Header */}
      <div className="w-full max-w-md pt-4 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-1.5 font-mono text-[11px] text-amber-400">
          <ShieldCheck className="w-3.5 h-3.5 text-[#F5B738]" />
          <span>AES-256 ENCRYPTED VAULT</span>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-slate-400">
          <Fingerprint className="w-3.5 h-3.5 text-slate-500" />
          <span>Cloud Protected Gate</span>
        </div>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md my-auto z-10">
        <div className="bg-[#0F141C]/90 backdrop-blur-xl border border-amber-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl shadow-black/80 relative">
          {/* Golden Corner Badges */}
          <div className="absolute -top-px left-8 right-8 h-px bg-gradient-to-r from-transparent via-[#F5B738] to-transparent" />
          <div className="absolute -bottom-px left-8 right-8 h-px bg-gradient-to-r from-transparent via-amber-500/40 to-transparent" />

          {/* Golden Lion Badge */}
          <div className="flex flex-col items-center text-center space-y-3 mb-6">
            <div className="relative">
              <img
                src={bossLionLogoImg}
                alt="Boss Aluminium Official Golden Lion"
                className="w-20 h-20 rounded-full object-cover border-2 border-[#F5B738] shadow-lg shadow-amber-500/20"
              />
              <div className="absolute -bottom-1 -right-1 bg-amber-500 text-black p-1 rounded-full shadow">
                <Lock className="w-3.5 h-3.5" />
              </div>
            </div>

            <div>
              <h1 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#F5B738] via-amber-200 to-[#F5B738] tracking-wider uppercase">
                Boss Master Vault
              </h1>
              <p className="text-xs text-slate-400 font-medium mt-1">
                Owner Cloud Command & Control Hub
              </p>
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="mb-5 p-3 rounded-xl bg-red-950/60 border border-red-500/50 flex items-start gap-2.5 text-red-200 text-xs animate-shake">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="leading-snug">{errorMessage}</div>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* 1. Authorized Email Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Authorized Owner Email:</span>
                <span className="text-[10px] text-amber-400/80 font-mono">CONFIDENTIAL</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter authorized email"
                  autoComplete="email"
                  className="w-full pl-10 pr-4 py-2.5 bg-[#171F2C] border border-slate-700 focus:border-[#F5B738] focus:ring-1 focus:ring-[#F5B738] rounded-xl text-sm font-medium text-white placeholder-slate-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* 2. Master PIN / Secret Password Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Master Passcode:</span>
                <span className="text-[10px] text-slate-500 font-mono">SECURE ENTRY</span>
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Enter Master Passcode"
                  autoFocus
                  autoComplete="current-password"
                  className="w-full pl-10 pr-11 py-2.5 bg-[#171F2C] border border-slate-700 focus:border-[#F5B738] focus:ring-1 focus:ring-[#F5B738] rounded-xl text-sm font-mono text-white placeholder-slate-500 outline-none transition-all tracking-wider"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 p-1 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Unlock Button */}
            <button
              type="submit"
              disabled={isVerifying || !email || !pin}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#F5B738] to-amber-500 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-[0.99] transition-all disabled:opacity-50 cursor-pointer"
            >
              {isVerifying ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Unlock Master Admin Vault</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Security Note */}
          <div className="mt-6 pt-4 border-t border-slate-800 text-center">
            <p className="text-[11px] text-slate-400 leading-relaxed">
              This terminal has direct master administrative control over live mobile apps, rates, cutting formulas, and client licenses. Unauthorized access attempts are logged.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="w-full max-w-md pb-4 text-center text-[11px] text-slate-400">
        BOSS ALUMINIUM & GLASS · MASTER ADMIN SYSTEM · 2026
      </div>
    </div>
  );
};
