import React, { useState, useRef } from 'react';
import {
  Layers,
  Plus,
  Trash2,
  Copy,
  Eye,
  EyeOff,
  ArrowRight,
  Search,
  CheckCircle2,
  FileSpreadsheet,
  GripVertical,
  Settings2,
  CloudUpload,
  Smartphone,
  Save,
  Check,
  Edit2,
  Ruler,
} from 'lucide-react';
import {
  BuilderCanvasItem,
  BuilderWidgetType,
  DragDropBlueprint,
  DynamicMasterSection,
  MeasurementUnit,
  WindowFormulaSettings,
} from '../types/bossModels';
import {
  DEFAULT_GLASS_COLORS_5MM,
  DEFAULT_GLASS_COLORS_8MM,
  DEFAULT_SECTIONS,
  SECTION_LABELS,
} from '../utils/bossDefaultRates';

interface DragDropStudioScreenProps {
  blueprints: DragDropBlueprint[];
  onSaveBlueprint: (bp: DragDropBlueprint, dynSec?: DynamicMasterSection) => void;
  onDeleteBlueprint: (id: string) => void;
  onSendToCalculator: (bp: DragDropBlueprint, w: number, h: number, q: number) => void;
  rates: Record<string, Record<string, Record<string, number>>>;
  customSections: string[];
  ctxGauge: string;
  ctxColor: string;
  measurementUnit: MeasurementUnit;
  windowFormula: WindowFormulaSettings;
  onPushFullConfigToCloud?: () => Promise<{ ok: boolean; message: string }>;
}

interface ToolboxWidgetDef {
  id: string;
  type: BuilderWidgetType;
  category: 'PROFILES' | 'GLASS' | 'UI_TABLES' | 'BUTTONS';
  title: string;
  subtitle: string;
  formulaTag: string;
  sectionCode: string;
  formulaExpression: string;
  qty: number;
  qtyFormula: string;
  applyTo: 'H' | 'W' | 'both' | 'UI';
  defaultGauge: string;
  options?: string[];
}

export const DragDropStudioScreen: React.FC<DragDropStudioScreenProps> = ({
  blueprints = [],
  onSaveBlueprint,
  onDeleteBlueprint,
  onSendToCalculator,
  rates = {},
  customSections = [],
  ctxGauge = '1.6',
  ctxColor = 'DULL',
  measurementUnit = 'INCH_SUTAR',
  windowFormula,
  onPushFullConfigToCloud,
}) => {
  const rateKeys = Object.keys(rates || {}).flatMap((g) =>
    Object.keys(rates[g] || {}).flatMap((c) => Object.keys(rates[g][c] || {}))
  );
  const allAvailableSections = Array.from(
    new Set([
      ...DEFAULT_SECTIONS,
      ...customSections,
      ...rateKeys,
      'GLASS',
      'GLASS_FIX',
      'GLASS_DOOR',
    ])
  )
    .filter(Boolean)
    .sort();

  const [selectedBpId, setSelectedBpId] = useState<string>(
    blueprints[0]?.id || 'bp-sliding-standard-2p'
  );

  const activeBp: DragDropBlueprint =
    blueprints.find((b) => b.id === selectedBpId) ||
    blueprints[0] || {
      id: 'bp-default-fallback',
      name: 'Custom Window / Door Blueprint',
      category: 'Windows',
      panelCount: 2,
      hasNetJali: false,
      hasArchTop: false,
      outerSectionCode: 'DC30C',
      sashSectionCode: 'M24',
      interlockSectionCode: 'M23',
      items: [],
      createdAt: Date.now(),
      isActive: true,
      isHidden: false,
    };

  const [viewMode, setViewMode] = useState<'BUILDER' | 'PREVIEW'>('BUILDER');
  const [toolboxTab, setToolboxTab] = useState<'ALL' | 'PROFILES' | 'GLASS' | 'UI_TABLES' | 'BUTTONS'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sendWidth, setSendWidth] = useState<number>(48);
  const [sendHeight, setSendHeight] = useState<number>(48);
  const [sendQty, setSendQty] = useState<number>(1);
  const [studioToast, setStudioToast] = useState<string | null>(null);
  const [isSyncingCloud, setIsSyncingCloud] = useState(false);
  const [isDraggingOverCanvas, setIsDraggingOverCanvas] = useState(false);

  const [previewPanels, setPreviewPanels] = useState<number>(activeBp.panelCount || 2);
  const [previewLock, setPreviewLock] = useState<'Latch' | 'Push Handle'>('Latch');
  const [previewWidth, setPreviewWidth] = useState<number>(48);
  const [previewHeight, setPreviewHeight] = useState<number>(60);
  const [previewQty, setPreviewQty] = useState<number>(1);
  const [previewFramePair, setPreviewFramePair] = useState<string>(activeBp.outerSectionCode || 'DC30C');

  const toolboxScrollRef = useRef<HTMLDivElement>(null);
  const isMouseDownRef = useRef(false);
  const startYRef = useRef(0);
  const scrollTopRef = useRef(0);
  const [isMouseDragging, setIsMouseDragging] = useState(false);

  const handleToolboxMouseDown = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('input') || target.closest('select')) {
      return;
    }
    if (!toolboxScrollRef.current) return;
    isMouseDownRef.current = true;
    setIsMouseDragging(false);
    startYRef.current = e.pageY - toolboxScrollRef.current.offsetTop;
    scrollTopRef.current = toolboxScrollRef.current.scrollTop;
  };

  const handleToolboxMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !toolboxScrollRef.current) return;
    const y = e.pageY - toolboxScrollRef.current.offsetTop;
    const walk = (y - startYRef.current) * 1.5;
    if (Math.abs(walk) > 4) {
      setIsMouseDragging(true);
    }
    toolboxScrollRef.current.scrollTop = scrollTopRef.current - walk;
  };

  const handleToolboxMouseUpOrLeave = () => {
    isMouseDownRef.current = false;
    setTimeout(() => setIsMouseDragging(false), 50);
  };

  const showToast = (msg: string) => {
    setStudioToast(msg);
    setTimeout(() => setStudioToast(null), 3500);
  };

  const getSectionLiveRate = (secCode: string): number => {
    const gaugeRates = rates[ctxGauge] || rates['1.6'] || {};
    const colorRates = gaugeRates[ctxColor] || gaugeRates['DULL'] || {};
    return colorRates[secCode] || 0;
  };

  const masterToolboxWidgets: ToolboxWidgetDef[] = [
    {
      id: 'tb-outer-frame',
      type: 'OUTER_FRAME',
      category: 'PROFILES',
      title: 'Outer Frame (2H + 2W)',
      subtitle: 'DC30C/DC26C, DC30F/DC26F, D54A, M30/M26',
      formulaTag: 'DC30C · H (2 pcs) & W (2 pcs)',
      sectionCode: 'DC30C',
      formulaExpression: '2H (DC30C) + 1W (DC30C) + 1W (DC26C)',
      qty: 4,
      qtyFormula: '4',
      applyTo: 'both',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-sliding-sash',
      type: 'SLIDING_SASH',
      category: 'PROFILES',
      title: 'Sliding Sash Verticals (M23 / M28)',
      subtitle: 'Sash height deduction (H - 1.75")',
      formulaTag: 'M23 · H - 1.75',
      sectionCode: 'M23',
      formulaExpression: 'H - 1.75',
      qty: 4,
      qtyFormula: '4',
      applyTo: 'H',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-m24-sash-width',
      type: 'PARAMETRIC_FORMULA_BOX',
      category: 'PROFILES',
      title: 'M24 / M24A Sash Width Formula',
      subtitle: '2P: (W - 6.25)/2 | 3P: W/2 & (W-2)/4 | 4P: (W-11.5)/4',
      formulaTag: 'M24 · (W - 6.25) / P',
      sectionCode: 'M24',
      formulaExpression: '(W - 6.25) / 2',
      qty: 4,
      qtyFormula: '4',
      applyTo: 'W',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-interlock-m28',
      type: 'INTERLOCK_M28',
      category: 'PROFILES',
      title: 'M28 Heavy Interlock Sash Vertical',
      subtitle: 'Heavy interlocking profile for 3-Palay & 4-Palay windows',
      formulaTag: 'M28 · H - 1.75',
      sectionCode: 'M28',
      formulaExpression: 'H - 1.75',
      qty: 2,
      qtyFormula: '2',
      applyTo: 'H',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-d29-net-jali',
      type: 'D29_NET_JALI',
      category: 'PROFILES',
      title: 'D29 Net / Jali Screen (1.2mm)',
      subtitle: 'Height = Sash H | Width = M24 + 3" 2 sutar',
      formulaTag: 'D29 · M24 + 3.25',
      sectionCode: 'D29',
      formulaExpression: 'H: (H - 1.75) | W: M24 + 3.25',
      qty: 4,
      qtyFormula: '2H + 2W',
      applyTo: 'both',
      defaultGauge: '1.2',
    },
    {
      id: 'tb-openable-leaf',
      type: 'OPENABLE_SASH',
      category: 'PROFILES',
      title: 'Openable Leaf / Door Sash (D50 / D50A / D42)',
      subtitle: 'Casement window or openable door leaf section',
      formulaTag: 'D50A · H - 2.5',
      sectionCode: 'D50A',
      formulaExpression: 'H - 2.5',
      qty: 4,
      qtyFormula: '2H + 2W',
      applyTo: 'both',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-vertical-mullion',
      type: 'MULLION_VERTICAL',
      category: 'PROFILES',
      title: 'Vertical Mullion / Interlock (D48 / D31 / M28)',
      subtitle: 'Center divider bar or 4-Palay D31 interlock',
      formulaTag: 'D48 · H - 2.5',
      sectionCode: 'D48',
      formulaExpression: 'H - 2.5',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'H',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-horizontal-lock-rail',
      type: 'TRANSOM_HORIZONTAL',
      category: 'PROFILES',
      title: 'Horizontal Lock Rail / Partition (D59 / D59A)',
      subtitle: 'Intermediate door mid-rail or divider partition',
      formulaTag: 'D59 · W - 5',
      sectionCode: 'D59',
      formulaExpression: 'W - 5',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'W',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-fixed-glass-bead',
      type: 'FIXED_GLASS_PANEL',
      category: 'PROFILES',
      title: 'Fixed Glass Panel / Glazing Bead (D41 / D41A)',
      subtitle: 'Glazing clip for glass fixation',
      formulaTag: 'D41 · Perimeter',
      sectionCode: 'D41',
      formulaExpression: 'Perimeter snap bead',
      qty: 4,
      qtyFormula: '2H + 2W',
      applyTo: 'both',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-glass-sliding',
      type: 'GLASS_PANEL',
      category: 'GLASS',
      title: 'Glass Panel & Cutting Formula (Sliding Window / Door)',
      subtitle: 'Height: (H - 5" 5 sutar) | Width: (M24 + 5 sutar) · Auto Sq.Ft',
      formulaTag: 'Glass · (H - 5.625") × (M24 + 0.625")',
      sectionCode: 'GLASS',
      formulaExpression: 'H: H - 5.625 | W: M24 + 0.625',
      qty: 2,
      qtyFormula: 'Panels Qty',
      applyTo: 'both',
      defaultGauge: '5mm',
      options: ['CLEAR', 'GREEN', 'BLUE', 'BRONZE', 'GREY', 'REFLECTIVE'],
    },
    {
      id: 'tb-glass-fix',
      type: 'GLASS_PANEL',
      category: 'GLASS',
      title: 'Fix Partition Glass Panel & Formula',
      subtitle: 'Height: (H - 1") | Width: (W - 1") · Full Sheet Formula',
      formulaTag: 'Glass · (H - 1.0) × (W - 1.0)',
      sectionCode: 'GLASS_FIX',
      formulaExpression: 'H: H - 1.0 | W: W - 1.0',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'both',
      defaultGauge: '5mm',
      options: ['CLEAR', 'GREEN', 'BLUE', 'BRONZE', 'GREY', 'FROSTED'],
    },
    {
      id: 'tb-glass-door',
      type: 'GLASS_PANEL',
      category: 'GLASS',
      title: 'Openable Door Leaf Glass Formula',
      subtitle: 'Height: (H - 2.5") | Width: (W - 2.5") · Leaf Deduction',
      formulaTag: 'Glass · (H - 2.5) × (W - 2.5)',
      sectionCode: 'GLASS_DOOR',
      formulaExpression: 'H: H - 2.5 | W: W - 2.5',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'both',
      defaultGauge: '5mm',
      options: ['CLEAR', 'GREEN', 'BLUE', 'BRONZE', 'GREY', 'FROSTED'],
    },
    {
      id: 'tb-arch-ventilator',
      type: 'ARCH_VENTILATOR',
      category: 'PROFILES',
      title: 'Arch Top / Ventilator Curved Profile',
      subtitle: 'Semi-circle or curved arch top segment',
      formulaTag: 'ARCH · Arc R=W/2',
      sectionCode: 'D54A',
      formulaExpression: '3.1416 * W / 2',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'both',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-ui-panels',
      type: 'PANEL_SELECTOR_CHIPS',
      category: 'UI_TABLES',
      title: 'Panel Selector Chips (2, 3, 4 Palay)',
      subtitle: 'Switch window between 2-Palay, 3-Palay, 4-Palay',
      formulaTag: 'Interactive UI Table',
      sectionCode: 'UI_PANELS',
      formulaExpression: 'Panel Count Selector',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
      options: ['2-Palay', '3-Palay', '4-Palay'],
    },
    {
      id: 'tb-ui-lock',
      type: 'LOCK_HANDLE_CHIPS',
      category: 'UI_TABLES',
      title: 'Lock / Handle Selector (Latch / Push Handle)',
      subtitle: 'Push Handle auto-adjusts D29 Net width deduction',
      formulaTag: 'Interactive UI Table',
      sectionCode: 'UI_LOCK',
      formulaExpression: 'Lock Mechanism Selector',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
      options: ['Latch', 'Push Handle'],
    },
    {
      id: 'tb-ui-dims',
      type: 'DIMENSION_INPUTS_ROW',
      category: 'UI_TABLES',
      title: 'Dimension Inputs Row (W × H × Qty)',
      subtitle: 'Support Inch.Sutar, CM, and MM measurement modes',
      formulaTag: 'Measurement Table Controls',
      sectionCode: 'UI_DIMS',
      formulaExpression: 'W × H × Qty Inputs',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-ui-frame-dropdown',
      type: 'SECTION_FRAME_DROPDOWN',
      category: 'UI_TABLES',
      title: 'Section & Frame Pair Dropdown (C / F)',
      subtitle: 'Switch outer section pair dynamically',
      formulaTag: 'Dropdown Selection Table',
      sectionCode: 'UI_FRAME_DROPDOWN',
      formulaExpression: 'Outer Frame Selector',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-ui-gauge-glass',
      type: 'GAUGE_GLASS_CHIPS',
      category: 'UI_TABLES',
      title: 'Gauge & Glass Selector Chips (1.2mm - 2.0mm)',
      subtitle: 'Select aluminium gauge and 5mm / 8mm glass color',
      formulaTag: 'Selector Matrix',
      sectionCode: 'UI_GAUGE_GLASS',
      formulaExpression: 'Gauge & Glass Selector',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-ui-cutting-table',
      type: 'CUTTING_TABLE_WIDGET',
      category: 'UI_TABLES',
      title: 'Cutting Table Widget (Cutting Chart Integration)',
      subtitle: 'Real-time cutting deduction table for this blueprint',
      formulaTag: 'Live Calculation Table',
      sectionCode: 'UI_CUTTING_TABLE',
      formulaExpression: 'Live Cutting Schedule',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-btn-done-calc',
      type: 'ACTION_BUTTON',
      category: 'BUTTONS',
      title: 'Calculate & Add to Quotation Button',
      subtitle: 'Primary action button to compute cuts and add to quote',
      formulaTag: 'Primary Action Button',
      sectionCode: 'BTN_CALCULATE',
      formulaExpression: 'Execute Calculation',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-btn-save-publish',
      type: 'SAVE_BUTTON',
      category: 'BUTTONS',
      title: 'Save & Publish Blueprint Button',
      subtitle: 'Instantly save and publish setup directly to client apps',
      formulaTag: 'Save & Cloud Push Button',
      sectionCode: 'BTN_SAVE_PUBLISH',
      formulaExpression: 'Cloud Sync',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-btn-print-slip',
      type: 'PRINT_BUTTON',
      category: 'BUTTONS',
      title: 'Print Cutting Slip Button',
      subtitle: 'Send cutting size breakdown directly to printer',
      formulaTag: 'Print Document Button',
      sectionCode: 'BTN_PRINT_SLIP',
      formulaExpression: 'Print Cutting Sheet',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
    {
      id: 'tb-btn-whatsapp',
      type: 'WHATSAPP_BUTTON',
      category: 'BUTTONS',
      title: 'Share Quotation on WhatsApp Button',
      subtitle: 'Generate client summary text and open direct WhatsApp message',
      formulaTag: 'WhatsApp Share Button',
      sectionCode: 'BTN_WHATSAPP',
      formulaExpression: 'WhatsApp Client Share',
      qty: 1,
      qtyFormula: '1',
      applyTo: 'UI',
      defaultGauge: '1.6',
    },
  ];

  const profileCount = masterToolboxWidgets.filter((w) => w.category === 'PROFILES').length;
  const glassCount = masterToolboxWidgets.filter((w) => w.category === 'GLASS').length;
  const uiCount = masterToolboxWidgets.filter((w) => w.category === 'UI_TABLES').length;
  const buttonsCount = masterToolboxWidgets.filter((w) => w.category === 'BUTTONS').length;
  const totalCount = masterToolboxWidgets.length;

  const filteredToolboxWidgets = masterToolboxWidgets.filter((w) => {
    if (toolboxTab === 'PROFILES' && w.category !== 'PROFILES') return false;
    if (toolboxTab === 'GLASS' && w.category !== 'GLASS') return false;
    if (toolboxTab === 'UI_TABLES' && w.category !== 'UI_TABLES') return false;
    if (toolboxTab === 'BUTTONS' && w.category !== 'BUTTONS') return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        w.title.toLowerCase().includes(q) ||
        w.subtitle.toLowerCase().includes(q) ||
        w.sectionCode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateNewBlueprint = () => {
    const newId = `bp-custom-${Date.now()}`;
    const newBp: DragDropBlueprint = {
      id: newId,
      name: `New Custom Setup #${blueprints.length + 1}`,
      category: 'Windows',
      panelCount: 2,
      hasNetJali: false,
      hasArchTop: false,
      outerSectionCode: 'DC30C',
      sashSectionCode: 'M24',
      interlockSectionCode: 'M23',
      isActive: true,
      isHidden: false,
      items: [
        {
          id: `item-${Date.now()}-1`,
          type: 'OUTER_FRAME',
          sectionCode: 'DC30C',
          label: 'Outer Frame (Track)',
          role: 'FRAME',
          qty: 4,
          formulaType: 'FULL_PERIMETER',
          formulaExpression: '2H + 2W',
          qtyFormula: '4',
          applyTo: 'both',
          defaultGauge: '1.6',
          pricePerFoot: getSectionLiveRate('DC30C'),
          isEnabled: true,
        },
        {
          id: `item-${Date.now()}-2`,
          type: 'SLIDING_SASH',
          sectionCode: 'M23',
          label: 'Sliding Sash Verticals (M23)',
          role: 'SASH',
          qty: 4,
          formulaType: 'EXACT_HEIGHT',
          formulaExpression: 'H - 1.75',
          qtyFormula: '4',
          applyTo: 'H',
          defaultGauge: '1.6',
          pricePerFoot: getSectionLiveRate('M23'),
          isEnabled: true,
        },
        {
          id: `item-${Date.now()}-3`,
          type: 'PARAMETRIC_FORMULA_BOX',
          sectionCode: 'M24',
          label: 'M24 Sash Width',
          role: 'SASH',
          qty: 4,
          formulaType: 'SASH_WIDTH',
          formulaExpression: '(W - 6.25) / 2',
          qtyFormula: '4',
          applyTo: 'W',
          defaultGauge: '1.6',
          pricePerFoot: getSectionLiveRate('M24'),
          isEnabled: true,
        },
        {
          id: `item-${Date.now()}-4`,
          type: 'GLASS_PANEL',
          sectionCode: 'GLASS',
          label: 'Glass Panel & Cutting Formula',
          role: 'GLASS',
          qty: 2,
          formulaType: 'GLASS_SLIDING',
          formulaExpression: 'H: H - 5.625 | W: M24 + 0.625',
          qtyFormula: '2',
          applyTo: 'both',
          defaultGauge: '5mm',
          glassGauge: '5mm',
          glassColor: 'CLEAR',
          isEnabled: true,
        },
      ],
      createdAt: Date.now(),
    };
    onSaveBlueprint(newBp);
    setSelectedBpId(newId);
    showToast(`Created new setup page: "${newBp.name}" with Glass Formula!`);
  };

  const handleCloneBlueprint = (bp: DragDropBlueprint) => {
    const newId = `bp-clone-${Date.now()}`;
    const cloned: DragDropBlueprint = {
      ...bp,
      id: newId,
      name: `${bp.name} (Copy)`,
      createdAt: Date.now(),
    };
    onSaveBlueprint(cloned);
    setSelectedBpId(newId);
    showToast(`Cloned setup to "${cloned.name}"`);
  };

  const handleToggleHideBlueprint = (bp: DragDropBlueprint) => {
    const updated: DragDropBlueprint = {
      ...bp,
      isHidden: !bp.isHidden,
      isActive: bp.isHidden,
    };
    onSaveBlueprint(updated);
    showToast(
      updated.isHidden
        ? `Setup "${bp.name}" hidden from client mobile app`
        : `Setup "${bp.name}" visible on client mobile app`
    );
  };

  const handleDeleteSetup = (bpId: string, name: string) => {
    onDeleteBlueprint(bpId);
    const remaining = blueprints.filter((b) => b.id !== bpId);
    if (remaining.length > 0) {
      setSelectedBpId(remaining[0].id);
    } else {
      handleCreateNewBlueprint();
    }
    showToast(`Setup "${name}" deleted permanently.`);
  };

  const handleUpdateActiveBp = (updates: Partial<DragDropBlueprint>) => {
    const updated = { ...activeBp, ...updates };
    onSaveBlueprint(updated);
  };

  const handleAddWidgetToBlueprint = (wDef: ToolboxWidgetDef) => {
    const rate = getSectionLiveRate(wDef.sectionCode);
    const newItem: BuilderCanvasItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      type: wDef.type,
      sectionCode: wDef.sectionCode,
      label: wDef.title,
      role:
        wDef.category === 'PROFILES'
          ? 'PROFILE'
          : wDef.category === 'GLASS'
          ? 'GLASS'
          : wDef.category === 'BUTTONS'
          ? 'ACTION_BUTTON'
          : 'UI_COMPONENT',
      qty: wDef.qty || 2,
      formulaType: wDef.formulaExpression,
      formulaExpression: wDef.formulaExpression,
      qtyFormula: wDef.qtyFormula,
      applyTo: wDef.applyTo,
      defaultGauge: wDef.defaultGauge,
      glassGauge: wDef.category === 'GLASS' ? '5mm' : undefined,
      glassColor: wDef.category === 'GLASS' ? 'CLEAR' : undefined,
      pricePerFoot: rate,
      isEnabled: true,
      options: wDef.options,
    };
    handleUpdateActiveBp({
      items: [...(activeBp.items || []), newItem],
    });
    showToast(`+ Added "${wDef.title}" to page canvas!`);
  };

  const handleRemoveItem = (itemId: string) => {
    handleUpdateActiveBp({
      items: (activeBp.items || []).filter((i) => i.id !== itemId),
    });
    showToast('Component removed from canvas.');
  };

  const handleSaveAndPublishCloud = async () => {
    onSaveBlueprint(activeBp);
    if (onPushFullConfigToCloud) {
      setIsSyncingCloud(true);
      try {
        const res = await onPushFullConfigToCloud();
        showToast(res.message || `Saved & Published "${activeBp.name}" to Cloud!`);
      } catch (e: any) {
        showToast(e?.message || 'Sync error while saving to cloud');
      } finally {
        setIsSyncingCloud(false);
      }
    } else {
      showToast(`Saved "${activeBp.name}" locally & ready for client app!`);
    }
  };

  return (
    <div className="space-y-4">
      {studioToast && (
        <div className="fixed top-20 right-6 z-50 p-3.5 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-semibold shadow-2xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{studioToast}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="p-4 rounded-2xl bg-[#0F141C] border border-[#2B3441] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-[#F5B738] text-[#F5B738]">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-black text-[#F5B738] tracking-wide flex items-center gap-2">
              <span>2. Drag & Drop Visual Window/Door Studio</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold">
                PAGE CANVAS ENGINE
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Drag profiles, tables & action buttons onto the sheet canvas, configure formulas, and publish live to Client Apps
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="p-1 rounded-xl bg-[#141A24] border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => setViewMode('BUILDER')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'BUILDER'
                  ? 'bg-[#F5B738] text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>🛠️ Canvas Builder Page</span>
            </button>
            <button
              onClick={() => setViewMode('PREVIEW')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'PREVIEW'
                  ? 'bg-sky-500 text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>📱 Live Mobile Preview</span>
            </button>
          </div>

          <button
            onClick={handleCreateNewBlueprint}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>+ Add Setup</span>
          </button>

          <button
            onClick={handleSaveAndPublishCloud}
            disabled={isSyncingCloud}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer active:scale-95 transition-transform"
          >
            {isSyncingCloud ? (
              <>
                <CloudUpload className="w-4 h-4 animate-bounce" />
                <span>Publishing to Cloud...</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>💾 Save & Publish to Client App</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Saved Setups Bar */}
      <div className="p-3.5 rounded-2xl bg-[#0F141C] border border-[#2B3441] space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
            <span>Saved Client App Setups ({blueprints.length}):</span>
          </span>
          <span className="text-slate-400 text-[11px]">
            Click to switch page · 👁️ Hide/Unhide · 📋 Clone · 🗑️ Delete setup
          </span>
        </div>

        <div className="flex items-center gap-2.5 overflow-x-auto pb-1 custom-scrollbar">
          {blueprints.map((b) => {
            const isSelected = selectedBpId === b.id;
            const isHidden = !!b.isHidden;
            return (
              <div
                key={b.id}
                className={`p-2 px-3 rounded-xl border flex items-center gap-2 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-[#1C2534] border-[#F5B738] shadow-md shadow-amber-500/10 ring-1 ring-[#F5B738]/40'
                    : 'bg-[#141A24] border-slate-800 hover:border-slate-700'
                }`}
              >
                <button
                  type="button"
                  onClick={() => setSelectedBpId(b.id)}
                  className="text-left cursor-pointer"
                >
                  <div
                    className={`text-xs font-bold ${
                      isSelected
                        ? 'text-[#F5B738]'
                        : isHidden
                        ? 'text-slate-500 line-through'
                        : 'text-slate-200'
                    }`}
                  >
                    {b.name}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {b.category} · {b.items?.length || 0} items {isHidden && '(Hidden)'}
                  </div>
                </button>

                <div className="flex items-center gap-1 pl-2 border-l border-slate-700/80">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleHideBlueprint(b);
                    }}
                    className={`p-1 rounded hover:bg-slate-800 cursor-pointer ${
                      isHidden ? 'text-amber-500' : 'text-slate-400 hover:text-white'
                    }`}
                    title={isHidden ? 'Click to Unhide on Client App' : 'Click to Hide from Client App'}
                  >
                    {isHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCloneBlueprint(b);
                    }}
                    className="p-1 rounded text-slate-400 hover:text-sky-300 hover:bg-slate-800 cursor-pointer"
                    title="Duplicate / Clone this Setup"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteSetup(b.id, b.name);
                    }}
                    className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800 cursor-pointer"
                    title="Delete this Setup"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Studio View */}
      {viewMode === 'PREVIEW' ? (
        <div className="p-6 rounded-2xl bg-[#0B0F17] border border-[#2B3441] flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center justify-between w-full max-w-md">
            <div>
              <span className="text-xs font-bold text-sky-400 uppercase tracking-wide">
                📱 Client Android App Live Preview
              </span>
              <p className="text-[11px] text-slate-400">
                Setup: <strong className="text-amber-300">{activeBp.name}</strong>
              </p>
            </div>
            <button
              onClick={() => setViewMode('BUILDER')}
              className="px-3 py-1 rounded-lg bg-slate-800 text-xs font-bold text-slate-300 hover:text-white cursor-pointer"
            >
              Back to Canvas
            </button>
          </div>

          <div className="w-full max-w-sm rounded-[36px] bg-[#0A0D14] border-4 border-slate-700 shadow-2xl p-4 space-y-4 text-white font-sans relative overflow-hidden">
            <div className="flex items-center justify-between px-2 pt-1 pb-2 border-b border-slate-800 text-[10px] text-slate-400">
              <span className="font-bold text-amber-400">Boss Aluminium Client</span>
              <span className="font-mono">5G · 100%</span>
            </div>

            <div className="p-3 rounded-2xl bg-[#141A24] border border-[#F5B738]/50 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#F5B738]">{activeBp.name}</span>
                <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                  LIVE SETUP
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                Category: {activeBp.category} · Track: {previewFramePair}
              </div>
            </div>

            <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1 custom-scrollbar text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase font-bold">Panels (Palay):</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[2, 3, 4].map((p) => (
                    <button
                      key={p}
                      onClick={() => setPreviewPanels(p)}
                      className={`py-1.5 rounded-xl font-bold text-xs transition-all ${
                        previewPanels === p
                          ? 'bg-[#F5B738] text-black shadow-md'
                          : 'bg-[#171F2C] text-slate-300 border border-slate-800'
                      }`}
                    >
                      {p}-Palay
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase font-bold">Lock / Handle:</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {(['Latch', 'Push Handle'] as const).map((lk) => (
                    <button
                      key={lk}
                      onClick={() => setPreviewLock(lk)}
                      className={`py-1.5 rounded-xl font-bold text-xs transition-all ${
                        previewLock === lk
                          ? 'bg-amber-400 text-black font-black'
                          : 'bg-[#171F2C] text-slate-300 border border-slate-800'
                      }`}
                    >
                      {lk}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase font-bold">Dimensions:</label>
                <div className="grid grid-cols-3 gap-1.5 text-xs">
                  <div>
                    <span className="block text-[9px] text-slate-400">Width (in)</span>
                    <input
                      type="number"
                      value={previewWidth}
                      onChange={(e) => setPreviewWidth(Number(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-[#171F2C] border border-slate-700 rounded-lg text-white font-mono text-xs"
                    />
                  </div>
                  <div>
                    <span className="block text-[9px] text-slate-400">Height (in)</span>
                    <input
                      type="number"
                      value={previewHeight}
                      onChange={(e) => setPreviewHeight(Number(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-[#171F2C] border border-slate-700 rounded-lg text-white font-mono text-xs"
                    />
                  </div>
                  <div>
                    <span className="block text-[9px] text-slate-400">Qty</span>
                    <input
                      type="number"
                      value={previewQty}
                      onChange={(e) => setPreviewQty(Number(e.target.value) || 1)}
                      className="w-full px-2 py-1 bg-[#171F2C] border border-slate-700 rounded-lg text-white font-mono text-xs"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase font-bold">Outer Frame Section:</label>
                <select
                  value={previewFramePair}
                  onChange={(e) => setPreviewFramePair(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#171F2C] border border-slate-700 rounded-xl text-xs text-amber-300 font-bold"
                >
                  {allAvailableSections.map((sec) => (
                    <option key={sec} value={sec}>
                      {sec}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 rounded-xl bg-[#141A24] border border-slate-800 space-y-2">
                <span className="text-[10px] font-bold text-amber-300 uppercase">
                  Auto-Calculated Cutting Pieces:
                </span>
                <div className="space-y-1">
                  {(activeBp.items || []).map((it, i) => (
                    <div key={i} className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-white font-bold">{it.sectionCode}:</span>
                      <span className="text-slate-400">
                        {it.qty || 2} pcs ({it.formulaExpression || 'Exact'})
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={() => onSendToCalculator(activeBp, previewWidth, previewHeight, previewQty)}
                className="w-full py-2.5 rounded-xl bg-[#F5B738] text-black font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <span>Done & Add to Quotation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* LEFT COLUMN: TOOLBOX */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-4 rounded-2xl bg-[#0F141C] border border-[#2B3441] space-y-3.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <span>1. DRAG & DROP TOOLBOX ({totalCount})</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Drag or click + Add</span>
              </div>

              <div className="p-1 rounded-xl bg-[#141A24] border border-slate-800 grid grid-cols-5 gap-1">
                <button
                  type="button"
                  onClick={() => setToolboxTab('ALL')}
                  className={`py-1 rounded-lg text-[10.5px] font-bold transition-all text-center cursor-pointer ${
                    toolboxTab === 'ALL'
                      ? 'bg-[#F5B738] text-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All ({totalCount})
                </button>
                <button
                  type="button"
                  onClick={() => setToolboxTab('PROFILES')}
                  className={`py-1 rounded-lg text-[10.5px] font-bold transition-all text-center cursor-pointer ${
                    toolboxTab === 'PROFILES'
                      ? 'bg-[#F5B738] text-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Profiles ({profileCount})
                </button>
                <button
                  type="button"
                  onClick={() => setToolboxTab('GLASS')}
                  className={`py-1 rounded-lg text-[10.5px] font-bold transition-all text-center cursor-pointer ${
                    toolboxTab === 'GLASS'
                      ? 'bg-sky-400 text-black shadow-md font-black'
                      : 'text-sky-300/80 hover:text-sky-200 hover:bg-sky-950/40'
                  }`}
                >
                  Glass ({glassCount})
                </button>
                <button
                  type="button"
                  onClick={() => setToolboxTab('UI_TABLES')}
                  className={`py-1 rounded-lg text-[10.5px] font-bold transition-all text-center cursor-pointer ${
                    toolboxTab === 'UI_TABLES'
                      ? 'bg-[#F5B738] text-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Tables ({uiCount})
                </button>
                <button
                  type="button"
                  onClick={() => setToolboxTab('BUTTONS')}
                  className={`py-1 rounded-lg text-[10.5px] font-bold transition-all text-center cursor-pointer ${
                    toolboxTab === 'BUTTONS'
                      ? 'bg-[#F5B738] text-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Buttons ({buttonsCount})
                </button>
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search profiles, glass, formulas, buttons (Glass, M24, D50A, Print...)"
                  className="w-full pl-9 pr-3 py-2 bg-[#171F2C] border border-slate-700 focus:border-[#F5B738] rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                />
              </div>

              {/* Scroll Controls Bar for Mouse Wheel & 1-Click Smooth Scrolling */}
              <div className="flex items-center justify-between text-[11px] px-2 py-1 bg-[#141A24] rounded-lg border border-slate-800 text-slate-400 select-none">
                <button
                  type="button"
                  onClick={() => toolboxScrollRef.current?.scrollBy({ top: -180, behavior: 'smooth' })}
                  className="px-2.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
                  title="Scroll Up"
                >
                  ▲ Scroll Up
                </button>
                <span className="text-[10px] text-slate-400 font-medium">
                  {isMouseDragging ? 'Dragging...' : 'Mouse drag / Wheel scroll'}
                </span>
                <button
                  type="button"
                  onClick={() => toolboxScrollRef.current?.scrollBy({ top: 180, behavior: 'smooth' })}
                  className="px-2.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
                  title="Scroll Down"
                >
                  ▼ Scroll Down
                </button>
              </div>

              <div
                ref={toolboxScrollRef}
                onMouseDown={handleToolboxMouseDown}
                onMouseMove={handleToolboxMouseMove}
                onMouseUp={handleToolboxMouseUpOrLeave}
                onMouseLeave={handleToolboxMouseUpOrLeave}
                onWheel={(e) => {
                  if (toolboxScrollRef.current) {
                    toolboxScrollRef.current.scrollTop += e.deltaY;
                  }
                }}
                className={`max-h-[640px] overflow-y-auto overscroll-contain pr-1.5 space-y-2.5 scroll-smooth custom-scrollbar ${
                  isMouseDragging ? 'cursor-grabbing select-none' : 'cursor-default'
                }`}
                style={{
                  scrollbarWidth: 'thin',
                  scrollbarColor: '#F5B738 #171F2C',
                }}
              >
                {filteredToolboxWidgets.map((wDef) => {
                  const isGlass = wDef.category === 'GLASS';
                  return (
                    <div
                      key={wDef.id}
                      className={`p-3 rounded-xl border transition-all flex items-start justify-between gap-2.5 group ${
                        isGlass
                          ? 'bg-gradient-to-r from-[#141A24] via-[#101E2E] to-sky-950/30 border-sky-500/50 hover:border-sky-400 shadow-sm shadow-sky-950/30'
                          : 'bg-[#141A24] border-slate-800/90 hover:border-[#F5B738]/60 shadow-sm'
                      }`}
                    >
                      <div className="flex items-start gap-2.5 min-w-0 flex-1">
                        <div
                          draggable
                          onDragStart={(e) => {
                            e.dataTransfer.setData('application/json', JSON.stringify(wDef));
                            e.dataTransfer.effectAllowed = 'copy';
                          }}
                          className={`p-1.5 rounded cursor-grab active:cursor-grabbing shrink-0 mt-0.5 transition-colors ${
                            isGlass
                              ? 'bg-sky-950/50 hover:bg-sky-500/20 text-sky-400'
                              : 'bg-slate-800/70 hover:bg-amber-500/20 text-slate-400 hover:text-amber-400'
                          }`}
                          title="Click & Drag handle onto canvas, or click + Add"
                        >
                          <GripVertical className="w-4 h-4" />
                        </div>

                        <div className="min-w-0 space-y-1 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`text-xs font-bold transition-colors leading-snug ${
                                isGlass
                                  ? 'text-sky-200 group-hover:text-sky-100'
                                  : 'text-white group-hover:text-[#F5B738]'
                              }`}
                            >
                              {wDef.title}
                            </span>
                            {isGlass && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-sky-500/20 border border-sky-400/40 text-sky-300 font-bold font-mono">
                                🟦 GLASS & FORMULA
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 leading-snug">
                            {wDef.subtitle}
                          </div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-[10px] font-mono font-semibold ${
                                isGlass ? 'text-sky-300 font-bold' : 'text-amber-400'
                              }`}
                            >
                              {wDef.formulaTag}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleAddWidgetToBlueprint(wDef)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all flex items-center gap-1 cursor-pointer shadow-sm ${
                          isGlass
                            ? 'bg-sky-500/20 hover:bg-sky-400 hover:text-black border border-sky-400/60 text-sky-300 font-black'
                            : 'bg-amber-500/10 hover:bg-[#F5B738] hover:text-black border border-[#F5B738]/50 text-[#F5B738]'
                        }`}
                        title="Click to add to page canvas"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: PAGE CANVAS */}
          <div className="lg:col-span-7 space-y-4">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'copy';
                if (!isDraggingOverCanvas) setIsDraggingOverCanvas(true);
              }}
              onDragLeave={() => setIsDraggingOverCanvas(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDraggingOverCanvas(false);
                try {
                  const raw = e.dataTransfer.getData('application/json');
                  if (raw) {
                    const itemDef = JSON.parse(raw);
                    handleAddWidgetToBlueprint(itemDef);
                  }
                } catch {
                  // ignore
                }
              }}
              className={`p-5 rounded-2xl bg-[#0C1017] border-2 transition-all space-y-4 shadow-2xl relative ${
                isDraggingOverCanvas
                  ? 'border-[#F5B738] ring-2 ring-[#F5B738]/50 bg-[#121824]'
                  : 'border-slate-800'
              }`}
            >
              {isDraggingOverCanvas && (
                <div className="absolute inset-0 bg-amber-500/10 backdrop-blur-xs rounded-2xl border-2 border-dashed border-[#F5B738] z-30 flex items-center justify-center pointer-events-none">
                  <div className="p-4 rounded-xl bg-black/80 border border-amber-400 text-amber-300 font-bold text-sm flex items-center gap-2 shadow-2xl">
                    <Plus className="w-5 h-5 animate-spin" />
                    <span>Drop Widget Here to Add to Page Canvas!</span>
                  </div>
                </div>
              )}

              {/* Page Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={activeBp.name}
                      onChange={(e) => handleUpdateActiveBp({ name: e.target.value })}
                      className="bg-transparent text-base font-black text-[#F5B738] focus:border-b focus:border-[#F5B738] outline-none flex-1 placeholder-amber-500/50"
                      placeholder="Enter Setup / Blueprint Name..."
                    />
                    <Edit2 className="w-3.5 h-3.5 text-slate-500" />
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 flex-wrap">
                    <span className="text-slate-500">Category:</span>
                    <select
                      value={activeBp.category}
                      onChange={(e) =>
                        handleUpdateActiveBp({ category: e.target.value as any })
                      }
                      className="bg-[#141A24] text-white px-2 py-0.5 rounded border border-slate-700"
                    >
                      {[
                        'Windows',
                        'Doors',
                        'Sliding',
                        'Fix Partition',
                        'Curtain Wall',
                        'Kitchen',
                        'Custom',
                      ].map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>

                    <span className="text-slate-500">Panels:</span>
                    <select
                      value={activeBp.panelCount}
                      onChange={(e) =>
                        handleUpdateActiveBp({ panelCount: Number(e.target.value) || 2 })
                      }
                      className="bg-[#141A24] text-white px-2 py-0.5 rounded border border-slate-700"
                    >
                      {[1, 2, 3, 4, 6].map((p) => (
                        <option key={p} value={p}>
                          {p}-Palay
                        </option>
                      ))}
                    </select>

                    <span className="text-slate-500">Outer Frame:</span>
                    <input
                      list="all-outer-sections-list"
                      type="text"
                      value={activeBp.outerSectionCode}
                      onChange={(e) =>
                        handleUpdateActiveBp({ outerSectionCode: e.target.value.toUpperCase() })
                      }
                      placeholder="DC30C"
                      className="w-28 px-2 py-0.5 bg-[#141A24] border border-slate-700 rounded text-amber-300 font-mono font-bold text-xs focus:border-[#F5B738] outline-none"
                    />
                    <datalist id="all-outer-sections-list">
                      {allAvailableSections.map((sec) => (
                        <option key={sec} value={sec}>
                          {sec}
                        </option>
                      ))}
                    </datalist>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start flex-wrap">
                  <button
                    onClick={() => handleToggleHideBlueprint(activeBp)}
                    className="p-1.5 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 border border-slate-700 cursor-pointer"
                  >
                    {activeBp.isHidden ? (
                      <EyeOff className="w-3.5 h-3.5 text-amber-400" />
                    ) : (
                      <Eye className="w-3.5 h-3.5" />
                    )}
                    <span>{activeBp.isHidden ? 'Hidden' : 'Visible'}</span>
                  </button>

                  <button
                    onClick={() => handleDeleteSetup(activeBp.id, activeBp.name)}
                    className="p-1.5 px-2.5 rounded-lg bg-red-950/50 text-red-400 hover:bg-red-900 border border-red-500/30 text-xs flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Setup</span>
                  </button>

                  <button
                    onClick={handleSaveAndPublishCloud}
                    className="p-1.5 px-3 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1 shadow cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save</span>
                  </button>
                </div>
              </div>

              {/* 2D Window Layout Canvas */}
              <div className="p-3.5 rounded-xl bg-[#101622] border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-300 uppercase flex items-center gap-1">
                    <Ruler className="w-3.5 h-3.5 text-[#F5B738]" />
                    <span>2D Architectural Layout Canvas</span>
                  </span>
                  <span className="text-amber-400/90 font-mono font-bold">
                    Outer: {activeBp.outerSectionCode} · {activeBp.panelCount}-Palay Window
                  </span>
                </div>

                <div className="w-full h-32 rounded-lg border-2 border-amber-500/60 bg-[#070A0F] relative flex items-center justify-center overflow-hidden">
                  <div className="absolute top-0 inset-x-0 h-3 bg-slate-800 border-b border-amber-500/40 flex items-center justify-center text-[8px] font-mono text-slate-400">
                    TOP TRACK: {activeBp.outerSectionCode} (W)
                  </div>
                  <div className="absolute bottom-0 inset-x-0 h-3 bg-slate-800 border-t border-amber-500/40 flex items-center justify-center text-[8px] font-mono text-slate-400">
                    BOTTOM TRACK: {activeBp.outerSectionCode === 'DC30C' ? 'DC26C' : activeBp.outerSectionCode} (W)
                  </div>
                  <div className="absolute inset-y-3 left-0 w-3 bg-slate-800 border-r border-amber-500/40" />
                  <div className="absolute inset-y-3 right-0 w-3 bg-slate-800 border-l border-amber-500/40" />

                  <div className="flex items-center justify-around w-full h-full px-6 py-4 gap-2">
                    {Array.from({ length: activeBp.panelCount || 2 }).map((_, pIdx) => {
                      const pCount = activeBp.panelCount || 2;
                      const panelM24 = (sendWidth - 6.25) / pCount;
                      const gH = Math.max(0, sendHeight - 5.625);
                      const gW = Math.max(0, panelM24 + 0.625);
                      const gSqft = ((gH * gW) / 144).toFixed(2);
                      return (
                        <div
                          key={pIdx}
                          className="flex-1 h-full rounded border border-sky-500/50 bg-sky-950/20 flex flex-col items-center justify-center text-[9px] font-mono text-sky-200 relative group p-1"
                        >
                          <span className="font-bold">Panel #{pIdx + 1}</span>
                          <span className="text-[8px] text-slate-300 font-mono">
                            M24: {panelM24 > 0 ? panelM24.toFixed(2) : '0'}"
                          </span>
                          <span className="text-[8px] text-amber-300 font-bold bg-black/60 px-1 rounded mt-0.5">
                            🟦 Glass: {gH > 0 ? gH.toFixed(2) : '0'}" × {gW > 0 ? gW.toFixed(2) : '0'}"
                          </span>
                          <span className="text-[7.5px] text-emerald-400">({gSqft} sq.ft)</span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="absolute bottom-1 right-2 text-[9px] font-mono text-amber-400 bg-black/60 px-1.5 rounded">
                    W: 48" · H: 48"
                  </div>
                </div>
              </div>

              {/* Configured Components on Canvas */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">
                    Configured Canvas Components:
                  </span>
                  <span className="text-[11px] font-mono text-amber-400 font-bold">
                    {activeBp.items?.length || 0} Elements
                  </span>
                </div>

                {(!activeBp.items || activeBp.items.length === 0) && (
                  <div className="p-8 text-center text-xs text-slate-400 border-2 border-dashed border-slate-800 rounded-xl space-y-2 bg-[#0A0E15]">
                    <div className="text-amber-300 font-bold">Page Canvas is Empty</div>
                    <div>Drag any profile, table, or button from the left toolbox onto this sheet, or click "+ Add"!</div>
                  </div>
                )}

                {(activeBp.items || []).map((item, idx) => {
                  const liveRate = getSectionLiveRate(item.sectionCode);
                  return (
                    <div
                      key={item.id || idx}
                      className="p-3.5 rounded-xl bg-[#141A24] border border-slate-800 space-y-2.5 text-xs transition-all hover:border-slate-700 group shadow-sm"
                    >
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <GripVertical className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 shrink-0 cursor-grab" />
                          <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center font-bold text-amber-400 text-[10px] shrink-0">
                            {idx + 1}
                          </span>
                          <div className="font-bold text-white truncate">{item.label}</div>
                        </div>

                        <div className="flex items-center gap-2">
                          {liveRate > 0 && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono font-bold border border-emerald-500/30">
                              Rs. {liveRate}/ft
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1 px-2 rounded-lg bg-red-950/40 hover:bg-red-900 text-red-400 hover:text-white border border-red-500/30 transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-bold">Delete</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 pt-1 border-t border-slate-800/80">
                        <div>
                          <label className="block text-[10px] text-slate-400 mb-0.5">
                            Section / Profile Code:
                          </label>
                          <select
                            value={item.sectionCode}
                            onChange={(e) => {
                              const newSec = e.target.value;
                              const nextItems = [...(activeBp.items || [])];
                              nextItems[idx] = {
                                ...item,
                                sectionCode: newSec,
                                pricePerFoot: getSectionLiveRate(newSec),
                              };
                              handleUpdateActiveBp({ items: nextItems });
                            }}
                            className="w-full px-2 py-1.5 bg-[#0C0F14] border border-[#F5B738]/60 focus:border-[#F5B738] rounded-lg text-xs font-mono text-amber-300 font-bold"
                          >
                            {allAvailableSections.map((sec) => (
                              <option key={sec} value={sec} className="bg-[#14181F] text-white">
                                {sec}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] text-slate-400 mb-0.5">
                            Cutting / Length Formula:
                          </label>
                          <input
                            type="text"
                            value={item.formulaExpression || item.formulaType || ''}
                            onChange={(e) => {
                              const nextItems = [...(activeBp.items || [])];
                              nextItems[idx] = {
                                ...item,
                                formulaExpression: e.target.value,
                                customLengthExpr: e.target.value,
                              };
                              handleUpdateActiveBp({ items: nextItems });
                            }}
                            className="w-full px-2.5 py-1.5 bg-[#0C0F14] border border-slate-700 rounded-lg text-xs font-mono text-white"
                            placeholder="e.g. H - 1.75, (W - 6.25)/2"
                          />
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="flex-1">
                            <label className="block text-[10px] text-slate-400 mb-0.5">Pieces / Qty:</label>
                            <input
                              type="number"
                              min={1}
                              value={item.qty || 1}
                              onChange={(e) => {
                                const nextItems = [...(activeBp.items || [])];
                                nextItems[idx] = {
                                  ...item,
                                  qty: Math.max(1, parseInt(e.target.value, 10) || 1),
                                };
                                handleUpdateActiveBp({ items: nextItems });
                              }}
                              className="w-full px-2 py-1.5 bg-[#0C0F14] border border-slate-700 rounded text-center text-white text-xs font-mono"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] text-slate-400 mb-0.5">Apply To:</label>
                            <select
                              value={item.applyTo || 'both'}
                              onChange={(e) => {
                                const nextItems = [...(activeBp.items || [])];
                                nextItems[idx] = {
                                  ...item,
                                  applyTo: e.target.value as any,
                                };
                                handleUpdateActiveBp({ items: nextItems });
                              }}
                              className="px-2 py-1.5 bg-[#0C0F14] border border-slate-700 rounded-lg text-xs font-mono text-slate-300"
                            >
                              <option value="both">H + W</option>
                              <option value="H">Height Only</option>
                              <option value="W">Width Only</option>
                              <option value="UI">UI / Action</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      {/* If it's a glass element, show glass gauge, color and live formula dimensions */}
                      {(item.sectionCode === 'GLASS' ||
                        item.sectionCode?.startsWith('GLASS') ||
                        item.type === 'GLASS_PANEL' ||
                        item.role === 'GLASS') && (
                        <div className="p-2.5 rounded-lg bg-sky-950/30 border border-sky-500/40 space-y-2 mt-2">
                          <div className="flex items-center justify-between text-[11px] flex-wrap gap-1">
                            <span className="font-bold text-sky-300 flex items-center gap-1">
                              <span>🟦 Glass Panel & Formula Live Configuration</span>
                            </span>
                            <span className="text-amber-300 font-mono text-[10px] font-bold">
                              Formula: {item.formulaExpression || 'H - 5.625" × (M24 + 0.625")'}
                            </span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                            <div>
                              <span className="block text-[10px] text-slate-400 mb-0.5 font-semibold">Glass Gauge</span>
                              <select
                                value={item.glassGauge || item.defaultGauge || '5mm'}
                                onChange={(e) => {
                                  const nextItems = [...(activeBp.items || [])];
                                  nextItems[idx] = {
                                    ...item,
                                    glassGauge: e.target.value,
                                    defaultGauge: e.target.value,
                                  };
                                  handleUpdateActiveBp({ items: nextItems });
                                }}
                                className="w-full px-2 py-1 bg-[#0C0F14] border border-sky-500/50 rounded text-xs text-sky-200 font-bold"
                              >
                                <option value="5mm">5mm Standard</option>
                                <option value="8mm">8mm Heavy</option>
                                <option value="12mm">12mm Double Glaze</option>
                              </select>
                            </div>
                            <div>
                              <span className="block text-[10px] text-slate-400 mb-0.5 font-semibold">Glass Color</span>
                              <select
                                value={item.glassColor || 'CLEAR'}
                                onChange={(e) => {
                                  const nextItems = [...(activeBp.items || [])];
                                  nextItems[idx] = {
                                    ...item,
                                    glassColor: e.target.value,
                                  };
                                  handleUpdateActiveBp({ items: nextItems });
                                }}
                                className="w-full px-2 py-1 bg-[#0C0F14] border border-sky-500/50 rounded text-xs text-sky-200 font-bold"
                              >
                                {['CLEAR', 'GREEN', 'BLUE', 'BRONZE', 'GREY', 'FROSTED', 'REFLECTIVE'].map((col) => (
                                  <option key={col} value={col}>
                                    {col}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="col-span-2">
                              <span className="block text-[10px] text-slate-400 mb-0.5 font-semibold">Live Glass Cut Dimensions</span>
                              <div className="px-2 py-1 bg-black/50 border border-slate-700 rounded text-[11px] font-mono text-emerald-300 flex items-center justify-between">
                                {(() => {
                                  const pCount = activeBp.panelCount || 2;
                                  const m24 = (sendWidth - 6.25) / pCount;
                                  const gH = Math.max(0, sendHeight - 5.625);
                                  const gW = Math.max(0, m24 + 0.625);
                                  const totalSqft = ((gH * gW * pCount) / 144).toFixed(2);
                                  return (
                                    <>
                                      <span>{pCount} Pcs: {gH.toFixed(2)}" × {gW.toFixed(2)}"</span>
                                      <span className="font-bold text-amber-300">{totalSqft} Sq.Ft</span>
                                    </>
                                  );
                                })()}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Bottom Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const newItem: BuilderCanvasItem = {
                      id: `item-${Date.now()}`,
                      sectionCode: 'M24',
                      label: `Custom Element #${(activeBp.items?.length || 0) + 1}`,
                      qty: 2,
                      formulaExpression: 'W - 3',
                      applyTo: 'both',
                      role: 'CUSTOM',
                      pricePerFoot: getSectionLiveRate('M24'),
                    };
                    handleUpdateActiveBp({ items: [...(activeBp.items || []), newItem] });
                    showToast('+ Added Blank Element to Canvas');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-amber-400" />
                  <span>+ Add Custom Blank Element</span>
                </button>
              </div>

              {/* Send to live calculator */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Test & Send to 9-Screen Cutting Calculator</span>
                </span>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Width (Inches):</label>
                    <input
                      type="number"
                      value={sendWidth}
                      onChange={(e) => setSendWidth(Number(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 bg-[#171F2C] border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Height (Inches):</label>
                    <input
                      type="number"
                      value={sendHeight}
                      onChange={(e) => setSendHeight(Number(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 bg-[#171F2C] border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Quantity:</label>
                    <input
                      type="number"
                      value={sendQty}
                      onChange={(e) => setSendQty(Number(e.target.value) || 1)}
                      className="w-full px-3 py-1.5 bg-[#171F2C] border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onSendToCalculator(activeBp, sendWidth, sendHeight, sendQty)}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#F5B738] to-amber-500 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
                >
                  <span>Calculate & Send to Cutting Chart & Quotation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
