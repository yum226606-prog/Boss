import React, { useState } from 'react';
import { Palette, Check, X, Download, Sparkles, Sliders, Smartphone, Eye } from 'lucide-react';

export interface AppThemeConfig {
  id: string;
  name: string;
  preset: string;
  buttonStyle: 'PILL_3D' | 'ROUNDED' | 'MODERN_FLAT' | 'METALLIC';
  templateLayout: 'CLASSIC_GOLD' | 'INDUSTRIAL_DARK' | 'PLATINUM_SLATE' | 'EMERALD_PRO';
  isLight?: boolean;
  bg: string;
  panel: string;
  panel2: string;
  border: string;
  primary: string;
  accent: string;
  textPrimary: string;
  textSecondary: string;
  fontScale?: number;
}

export function enforceReadableContrast(thm: Partial<AppThemeConfig>): AppThemeConfig {
  const isLight = !!thm.isLight;
  return {
    id: thm.id || 'theme-classic-gold',
    name: thm.name || 'Classic Gold Pro',
    preset: thm.preset || 'GOLD',
    buttonStyle: thm.buttonStyle || 'PILL_3D',
    templateLayout: thm.templateLayout || 'CLASSIC_GOLD',
    isLight,
    bg: thm.bg || (isLight ? '#F8FAFC' : '#0F172A'),
    panel: thm.panel || (isLight ? '#FFFFFF' : '#1E293B'),
    panel2: thm.panel2 || (isLight ? '#F1F5F9' : '#334155'),
    border: thm.border || (isLight ? '#CBD5E1' : '#475569'),
    primary: thm.primary || '#F5B738',
    accent: thm.accent || '#38BDF8',
    textPrimary: thm.textPrimary || (isLight ? '#0F172A' : '#F8FAFC'),
    textSecondary: thm.textSecondary || (isLight ? '#475569' : '#94A3B8'),
    fontScale: thm.fontScale || 1,
  };
}

export const BUILT_IN_THEMES: AppThemeConfig[] = [
  enforceReadableContrast({
    id: 'theme-classic-gold',
    name: 'Classic Gold Pro',
    preset: 'GOLD',
    buttonStyle: 'PILL_3D',
    templateLayout: 'CLASSIC_GOLD',
    bg: '#0F172A',
    panel: '#1E293B',
    panel2: '#334155',
    border: '#475569',
    primary: '#F5B738',
    accent: '#38BDF8',
    textPrimary: '#FFFFFF',
    textSecondary: '#94A3B8',
  }),
  enforceReadableContrast({
    id: 'theme-industrial-dark',
    name: 'Industrial Dark Titanium',
    preset: 'TITANIUM',
    buttonStyle: 'MODERN_FLAT',
    templateLayout: 'INDUSTRIAL_DARK',
    bg: '#090D14',
    panel: '#121824',
    panel2: '#1C2433',
    border: '#283344',
    primary: '#38BDF8',
    accent: '#F5B738',
    textPrimary: '#F1F5F9',
    textSecondary: '#64748B',
  }),
  enforceReadableContrast({
    id: 'theme-emerald-pro',
    name: 'Emerald Executive',
    preset: 'EMERALD',
    buttonStyle: 'METALLIC',
    templateLayout: 'EMERALD_PRO',
    bg: '#061412',
    panel: '#0E2420',
    panel2: '#143832',
    border: '#1E4E45',
    primary: '#10B981',
    accent: '#F59E0B',
    textPrimary: '#ECFDF5',
    textSecondary: '#6EE7B7',
  }),
  enforceReadableContrast({
    id: 'theme-platinum-slate',
    name: 'Platinum Light Slate',
    preset: 'LIGHT',
    buttonStyle: 'ROUNDED',
    templateLayout: 'PLATINUM_SLATE',
    isLight: true,
    bg: '#F8FAFC',
    panel: '#FFFFFF',
    panel2: '#F1F5F9',
    border: '#CBD5E1',
    primary: '#D97706',
    accent: '#0284C7',
    textPrimary: '#0F172A',
    textSecondary: '#475569',
  }),
];

interface ThemeStudioModalProps {
  currentTheme: AppThemeConfig;
  downloadedThemes: AppThemeConfig[];
  onApplyTheme: (thm: AppThemeConfig) => void;
  onDownloadTheme: (thm: AppThemeConfig) => void;
  onClose: () => void;
}

export const ThemeStudioModal: React.FC<ThemeStudioModalProps> = ({
  currentTheme,
  downloadedThemes,
  onApplyTheme,
  onDownloadTheme,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'BUILT_IN' | 'ONLINE' | 'CUSTOM'>('BUILT_IN');
  const allThemes = [...BUILT_IN_THEMES, ...downloadedThemes];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#0F172A] border border-amber-500/40 rounded-2xl shadow-2xl p-6 text-white space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-700 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-[#F5B738] text-[#F5B738]">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#F5B738]">Mobile Theme Studio</h3>
              <p className="text-xs text-slate-400">Customize Client Mobile App Look & Feel</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {allThemes.map((thm) => {
            const isSelected = currentTheme.id === thm.id;
            return (
              <div
                key={thm.id}
                style={{ backgroundColor: thm.panel, borderColor: thm.border }}
                className={`p-4 rounded-xl border-2 transition-all space-y-3 ${
                  isSelected ? 'ring-2 ring-[#F5B738] shadow-lg' : 'hover:border-slate-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm" style={{ color: thm.textPrimary }}>
                    {thm.name}
                  </span>
                  {isSelected && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500 text-black text-[10px] font-bold flex items-center gap-1">
                      <Check className="w-3 h-3" /> Active
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className="w-5 h-5 rounded-full border border-white/20"
                    style={{ backgroundColor: thm.primary }}
                    title="Primary"
                  />
                  <span
                    className="w-5 h-5 rounded-full border border-white/20"
                    style={{ backgroundColor: thm.bg }}
                    title="Background"
                  />
                  <span
                    className="w-5 h-5 rounded-full border border-white/20"
                    style={{ backgroundColor: thm.accent }}
                    title="Accent"
                  />
                  <span className="text-[10px] text-slate-400 font-mono ml-auto">
                    {thm.buttonStyle}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => onApplyTheme(thm)}
                  disabled={isSelected}
                  className={`w-full py-1.5 rounded-lg text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-slate-700/50 text-slate-400 cursor-default'
                      : 'bg-amber-500 hover:bg-amber-400 text-black cursor-pointer shadow'
                  }`}
                >
                  {isSelected ? 'Applied' : 'Apply Theme'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
